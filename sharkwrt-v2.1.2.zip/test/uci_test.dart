import 'package:flutter_test/flutter_test.dart';
import 'package:sharkwrt/core/oui.dart';
import 'package:sharkwrt/core/uci.dart';

void main() {
  group('shq / validators', () {
    test('quotes single quotes safely', () {
      expect(shq("a'b"), "'a'\\''b'");
      expect(shq('plain'), "'plain'");
      expect(shQuote(r'$(reboot)'), r"'$(reboot)'");
    });
    test('isIpv4', () {
      expect(isIpv4('192.168.1.1'), isTrue);
      expect(isIpv4('256.1.1.1'), isFalse);
      expect(isIpv4('1.2.3'), isFalse);
      expect(isIpv4('1.2.3.4; reboot'), isFalse);
    });
    test('isMac and isSafeName', () {
      expect(isMac('aa:bb:cc:dd:ee:ff'), isTrue);
      expect(isMac('aa:bb:cc:dd:ee'), isFalse);
      expect(isSafeName('lan'), isTrue);
      expect(isSafeName('@rule[3]'), isTrue);
      expect(isSafeName('lan; rm -rf /'), isFalse);
    });
  });

  group('parseUciShow', () {
    const out = '''
network.lan=interface
network.lan.proto='static'
network.lan.ipaddr='192.168.1.1'
network.wan6=interface
firewall.@rule[0]=rule
firewall.@rule[0].name='Allow ping'
dhcp.lan.dns='1.1.1.1' '8.8.8.8'
''';
    test('sections and options', () {
      final c = parseUciShow(out);
      expect(c['lan']?.type, 'interface');
      expect(c['lan']?.o('ipaddr'), '192.168.1.1');
      expect(c['@rule[0]']?.o('name'), 'Allow ping');
      expect(c.ofType('interface').length, 2);
    });
  });

  group('oui', () {
    test('vendor and private address', () {
      expect(vendorOf('b8:27:eb:11:22:33'), 'Raspberry Pi');
      expect(vendorOf('da:11:22:33:44:55'), 'Private address');
      expect(vendorOf('00:11:22:33:44:55'), '');
      expect(isPrivateMac('da:00:00:00:00:00'), isTrue);
      expect(isPrivateMac('b8:00:00:00:00:00'), isFalse);
    });
  });
}
