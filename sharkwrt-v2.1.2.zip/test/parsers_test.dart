import 'package:flutter_test/flutter_test.dart';
import 'package:sharkwrt/core/uci.dart';
import 'package:sharkwrt/data/router_api.dart';

void main() {
  group('parseStats', () {
    const out = '0.15 0.10 0.05 1/100 1234\n'
        '@@\n'
        'cpu  100 0 100 800 0 0 0 0 0 0\n'
        '@@\n'
        'MemTotal:        1000 kB\n'
        'MemAvailable:     400 kB\n'
        '@@\n'
        '1000.5 2000.0\n'
        '@@\n'
        '/dev/x 1000 250 750 25% /overlay\n'
        '@@\n'
        '  eth0: 1000 10 0 0 0 0 0 0 2000 10 0 0 0 0 0 0\n'
        '@@\n'
        '45000\n';
    test('cpu delta, memory, flash, net, temperature', () {
      final r = parseStats(out, 500, 400);
      final st = r.$1;
      expect(st.cpu, closeTo(20, 0.01));
      expect(st.load, closeTo(0.15, 0.001));
      expect(st.memTotal, 1000);
      expect(st.memUsed, 600);
      expect(st.flashTotal, 1000);
      expect(st.flashUsed, 250);
      expect(st.net['eth0'], [1000, 2000]);
      expect(st.tempC, closeTo(45, 0.01));
      expect(r.$2, 1000);
      expect(r.$3, 800);
    });
    test('garbage throws', () {
      expect(() => parseStats('nope', null, null), throwsA(isA<Object>()));
    });
  });

  group('pending changes', () {
    test('parsePending', () {
      final l = parsePending("network.lan.ipaddr='192.168.2.1'\n"
          '-wireless.wifi0.disabled\n'
          'firewall.swdmz=redirect\n');
      expect(l.length, 3);
      expect(l[0].pkg, 'network');
      expect(l[0].op, 'set');
      expect(l[0].value, '192.168.2.1');
      expect(l[1].op, 'del');
      expect(l[1].pkg, 'wireless');
      expect(l[2].op, 'add');
      expect(l[2].pkg, 'firewall');
    });
    test('describeChange masks secrets', () {
      const c = PendingChange('wireless', 'wireless.a.key', 'set', 'hunter22');
      final d = describeChange(c);
      expect(d.contains('hunter22'), isFalse);
      expect(d.contains('••••••'), isTrue);
    });
  });

  group('wifi', () {
    const out = '''
wireless.radio0=wifi-device
wireless.radio0.channel='36'
wireless.radio0.htmode='VHT80'
wireless.radio0.country='IN'
wireless.default_radio0=wifi-iface
wireless.default_radio0.device='radio0'
wireless.default_radio0.mode='ap'
wireless.default_radio0.ssid='Home'
wireless.default_radio0.encryption='psk2'
wireless.default_radio0.key='secret123'
wireless.default_radio0.network='lan'
wireless.sw_guest_radio0=wifi-iface
wireless.sw_guest_radio0.device='radio0'
wireless.sw_guest_radio0.mode='ap'
wireless.sw_guest_radio0.ssid='Home-Guest'
wireless.sw_guest_radio0.encryption='psk2'
wireless.sw_guest_radio0.key='guestpass'
wireless.sw_guest_radio0.network='swguest'
''';
    test('parseWifi and findGuest', () {
      final w = parseWifi(out);
      expect(w.radios.length, 1);
      expect(w.radios.first.band, '5G');
      expect(w.radios.first.country, 'IN');
      expect(w.ifaces.length, 2);
      final g = findGuest(w, 'guest');
      expect(g.exists, isTrue);
      expect(g.ssid, 'Home-Guest');
      expect(g.enabled, isTrue);
      expect(findGuest(w, 'iot').exists, isFalse);
    });
    test('wifiQrPayload', () {
      expect(wifiQrPayload('Home', 'pass', 'psk2'), 'WIFI:T:WPA;S:Home;P:pass;;');
      expect(wifiQrPayload('a;b', 'p', 'psk2'), contains(r'S:a\;b;'));
      expect(wifiQrPayload('Open', '', 'none'), 'WIFI:T:nopass;S:Open;;');
    });
  });

  group('clients', () {
    const out = '''
@@LEASES
1700000000 aa:bb:cc:dd:ee:01 192.168.1.50 phone *
@@NEIGH
192.168.1.50 dev br-lan lladdr aa:bb:cc:dd:ee:01 REACHABLE
192.168.1.60 dev br-lan lladdr aa:bb:cc:dd:ee:02 STALE
fe80::1 dev br-lan lladdr aa:bb:cc:dd:ee:03 STALE
@@WIFI
IFACE wlan0
	ssid Home
	channel 36 (5180 MHz), width: 80 MHz, center1: 5210 MHz
Station aa:bb:cc:dd:ee:01 (on wlan0)
	signal: 	-52 dBm
@@DHCP
dhcp.swlease_x=host
dhcp.swlease_x.mac='aa:bb:cc:dd:ee:01'
dhcp.swlease_x.ip='192.168.1.50'
@@FW
firewall.swblk_aabbccddee02=rule
firewall.swblk_aabbccddee02.src_mac='aa:bb:cc:dd:ee:02'
''';
    test('parseClients merges wifi, neighbours, blocks and leases', () {
      final d = parseClients(out);
      expect(d.clients.length, 2);
      final a = d.clients.firstWhere((c) => c.mac == 'aa:bb:cc:dd:ee:01');
      expect(a.band, '5G');
      expect(a.ssid, 'Home');
      expect(a.ip, '192.168.1.50');
      expect(a.hostname, 'phone');
      expect(a.signal, -52);
      final b = d.clients.firstWhere((c) => c.mac == 'aa:bb:cc:dd:ee:02');
      expect(b.band, 'LAN');
      expect(d.blocked.containsKey('aa:bb:cc:dd:ee:02'), isTrue);
      expect(d.reserved['aa:bb:cc:dd:ee:01'], '192.168.1.50');
    });
    test('parseNlbw sums per mac', () {
      final m = parseNlbw('family;mac;rx_bytes;tx_bytes\n'
          '4;aa:bb:cc:dd:ee:01;1000;500\n'
          '4;aa:bb:cc:dd:ee:01;200;100\n');
      expect(m['aa:bb:cc:dd:ee:01'], [1200, 600]);
    });
  });

  group('network', () {
    test('parseLan with CIDR address', () {
      final d = NetworkData(
        parseUciShow("network.lan=interface\nnetwork.lan.ipaddr='192.168.5.1/24'\n"),
        parseUciShow("dhcp.lan=dhcp\ndhcp.lan.start='50'\ndhcp.lan.limit='100'\n"),
      );
      final l = parseLan(d);
      expect(l.ip, '192.168.5.1');
      expect(l.netmask, '255.255.255.0');
      expect(l.start, '50');
      expect(l.dhcpEnabled, isTrue);
    });
    test('parseSqm', () {
      expect(parseSqm('NOSQM').installed, isFalse);
      final c = parseSqm("sqm.swsqm=queue\nsqm.swsqm.enabled='1'\n"
          "sqm.swsqm.interface='eth1'\nsqm.swsqm.download='50000'\n");
      expect(c.installed, isTrue);
      expect(c.enabled, isTrue);
      expect(c.down, '50000');
    });
    test('parseConnTest', () {
      final r = parseConnTest('GW=1\nGWMS=1.2\nNET=1\nNETMS=12.5\nDNS=0\n');
      expect(r.gatewayOk, isTrue);
      expect(r.internetOk, isTrue);
      expect(r.dnsOk, isFalse);
      expect(r.internetMs, '12.5');
    });
  });

  group('firewall', () {
    test('parseFirewall', () {
      final v = parseFirewall(parseUciShow('''
firewall.@defaults[0]=defaults
firewall.@defaults[0].syn_flood='1'
firewall.@zone[0]=zone
firewall.@zone[0].name='lan'
firewall.@zone[0].input='ACCEPT'
firewall.swdmz=redirect
firewall.swdmz.dest_ip='192.168.1.9'
firewall.swrule_a=rule
firewall.swrule_a.name='Allow SSH'
firewall.swrule_a.enabled='0'
'''));
      expect(v.defaults.synFlood, isTrue);
      expect(v.zones.first.name, 'lan');
      expect(v.redirects.first.isDmz, isTrue);
      expect(v.rules.first.enabled, isFalse);
      expect(v.rules.first.mine, isTrue);
    });
  });

  group('system', () {
    test('parseServices', () {
      final l = parseServices('network 1 1\nfoo 0 0\n');
      expect(l.map((e) => e.name).toList(), ['foo', 'network']);
      expect(l.last.enabled, isTrue);
    });
    test('package lists', () {
      final o = parseOpkgList('luci - 1.0 - LuCI web\nbusybox - 1.36.1-1\n');
      expect(o.length, 2);
      expect(o.first.desc, 'LuCI web');
      final a = parseApkList('curl-8.5.0-r0 aarch64 {curl} (MIT) [installed]\n');
      expect(a.single.name, 'curl');
      expect(a.single.version, '8.5.0-r0');
      expect(a.single.installed, isTrue);
    });
    test('authorized keys', () {
      final k = parseAuthorizedKeys(
          'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIabcdefghijklmnopqrstuvwxyz user@pc\n');
      expect(k.single.line, 1);
      expect(k.single.comment, 'user@pc');
    });
    test('vnstat json', () {
      final u = parseVnstat('{"interfaces":[{"name":"eth1","traffic":{'
          '"day":[{"date":{"year":2026,"month":10,"day":17},"rx":1000,"tx":500}],'
          '"month":[{"date":{"year":2026,"month":10},"rx":5000,"tx":2000}]}}]}');
      expect(u.single.iface, 'eth1');
      expect(u.single.days.single.label, '10-17');
      expect(u.single.months.single.label, '2026-10');
      expect(u.single.months.single.rx, 5000);
    });
    test('speed parsers', () {
      final q = parseQuickSpeed('6 packets transmitted, 6 received, 0% packet loss, time 5008ms\n'
          'round-trip min/avg/max = 10.0/12.0/16.0 ms\n'
          'DL 100.00 108.00\nUL 200.0 204.0\n');
      expect(q.pingMs, 12.0);
      expect(q.jitterMs, 3.0);
      expect(q.lossPct, 0);
      expect(q.downMbps, closeTo(12.0, 0.01));
      expect(q.upMbps, closeTo(8.0, 0.01));
      final o = parseOokla('{"ping":{"jitter":1.5,"latency":10.0},'
          '"download":{"bandwidth":12500000},"upload":{"bandwidth":2500000},"packetLoss":0}');
      expect(o!.downMbps, closeTo(100, 0.01));
      expect(o.upMbps, closeTo(20, 0.01));
    });
  });
}
