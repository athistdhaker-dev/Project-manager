import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/strings.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';
import 'apply_flow.dart';
import 'settings.dart';
import 'sys_tools.dart';

const int _cap = 60;

class DashboardTab extends StatefulWidget {
  const DashboardTab({super.key});

  @override
  State<DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<DashboardTab> {
  Timer? _timer;
  bool _busy = false;
  String? _error;
  Stats? _stats;
  Stats? _prev;
  RouterInfo? _info;
  ClientsData? _clients;
  WifiData? _wifi;
  double _down = 0;
  double _up = 0;
  double _peakDown = 0;
  double _peakUp = 0;
  double _sessDown = 0;
  double _sessUp = 0;
  int _tick = 0;
  final List<double> _dl = [];
  final List<double> _ul = [];

  @override
  void initState() {
    super.initState();
    _poll();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _poll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _wanDevice(Stats st, String wanDev) {
    if (wanDev.isNotEmpty && st.net.containsKey(wanDev)) return wanDev;
    if (st.net.containsKey('eth1')) return 'eth1';
    return 'eth0';
  }

  Future<void> _slow(RouterApi api) async {
    try {
      final c = await api.loadClients();
      if (mounted) setState(() => _clients = c);
    } catch (_) {}
    try {
      final w = await api.loadWifi();
      if (mounted) setState(() => _wifi = w);
    } catch (_) {}
  }

  Future<void> _poll() async {
    if (_busy) return;
    final api = context.read<AppState>().api;
    if (api == null) return;
    _busy = true;
    try {
      if (_info == null || _tick % 10 == 0) {
        final i = await api.loadInfo();
        if (mounted) setState(() => _info = i);
      }
      if (_tick % 7 == 0) await _slow(api);
      _tick++;
      final st = await api.loadStats();
      final dev = _wanDevice(st, api.wanDev);
      final cur = st.net[dev];
      final prev = _prev;
      if (prev != null && cur != null) {
        final p = prev.net[dev];
        final dt = st.at.difference(prev.at).inMilliseconds / 1000.0;
        if (p != null && dt > 0) {
          final dRx = cur[0] - p[0];
          final dTx = cur[1] - p[1];
          if (dRx >= 0 && dTx >= 0) {
            _down = dRx / dt;
            _up = dTx / dt;
            _sessDown += dRx;
            _sessUp += dTx;
            _peakDown = math.max(_peakDown, _down);
            _peakUp = math.max(_peakUp, _up);
            _dl.add(_down);
            _ul.add(_up);
            if (_dl.length > _cap) _dl.removeAt(0);
            if (_ul.length > _cap) _ul.removeAt(0);
          }
        }
      }
      _prev = st;
      if (mounted) {
        setState(() {
          _stats = st;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      _busy = false;
    }
  }

  Future<void> _action(Future<void> Function() fn, String done) async {
    try {
      await fn();
      if (mounted) showMsg(context, done);
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  Future<void> _toggleRadio(RouterApi api, RadioInfo r, bool on) async {
    await editConfig(context, (a) => a.stageRadio(r.name, disabled: !on));
    try {
      final w = await api.loadWifi();
      if (mounted) setState(() => _wifi = w);
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    final api = s.api;
    final st = _stats;
    final info = _info ?? s.info;
    final header = TabHeader(
      title: s.active?.name ?? 'Router',
      subtitle: [
        if (info.model.isNotEmpty) info.model,
        if (st != null) 'up ${fmtUptime(st.uptime)}',
      ].join('  •  '),
      actions: [
        CircleBtn(
          icon: Icons.tune_rounded,
          tooltip: S.settings,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
          ),
        ),
        const SizedBox(width: 8),
        CircleBtn(
          icon: Icons.swap_horiz_rounded,
          tooltip: S.switchRouter,
          onTap: () => Navigator.of(context).maybePop(),
        ),
      ],
    );
    if (st == null) {
      return Column(
        children: [
          header,
          Expanded(
            child: _error != null
                ? ErrorBox(_error!, onRetry: _poll)
                : const Loading(),
          ),
        ],
      );
    }

    final memFrac = st.memTotal > 0 ? st.memUsed / st.memTotal : 0.0;
    final flashFrac = st.flashTotal > 0 ? st.flashUsed / st.flashTotal : 0.0;
    final dn = rateParts(_down);
    final upr = rateParts(_up);

    // clients by band
    final cl = _clients?.clients ?? const <NetClient>[];
    final n5 = cl.where((c) => c.band == '5G' || c.band == '6G').length;
    final n24 = cl.where((c) => c.band == '2.4G').length;
    final nLan = cl.where((c) => c.band == 'LAN').length;

    final radios = _wifi?.radios ?? const <RadioInfo>[];

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 120),
      children: [
        header,
        if (_error != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Tile(
              tint: kBad,
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  const Icon(Icons.wifi_off_rounded, color: kBad),
                  const SizedBox(width: 10),
                  Expanded(child: Text(_error!)),
                ],
              ),
            ),
          ),

        // ---- throughput hero
        Tile(
          accent: true,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Caption(S.download),
                        const SizedBox(height: 4),
                        BigNumber(dn.$1, unit: dn.$2, color: s.accent, size: 34),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Caption(S.upload),
                        const SizedBox(height: 4),
                        BigNumber(upr.$1, unit: upr.$2, color: kWarm, size: 34),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              AreaChart(a: _dl, b: _ul, ca: s.accent, cb: kWarm, cap: _cap),
              const SizedBox(height: 10),
              Wrap(
                spacing: 16,
                runSpacing: 4,
                children: [
                  Text('${S.peak} ↓ ${fmtRate(_peakDown)}',
                      style: TextStyle(color: t.sub, fontSize: 12)),
                  Text('${S.peak} ↑ ${fmtRate(_peakUp)}',
                      style: TextStyle(color: t.sub, fontSize: 12)),
                  Text('${S.sinceOpen}: ↓ ${fmtBytes(_sessDown)}  ↑ ${fmtBytes(_sessUp)}',
                      style: TextStyle(color: t.sub, fontSize: 12)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),

        // ---- dials
        Row(
          children: [
            Expanded(
              child: _dialTile(
                S.cpu,
                st.cpu / 100,
                '${st.cpu.toStringAsFixed(0)}%',
                'load ${st.load.toStringAsFixed(2)}',
                s.accent,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _dialTile(
                S.ram,
                memFrac.toDouble(),
                '${(memFrac * 100).toStringAsFixed(0)}%',
                '${fmtKb(st.memUsed)} / ${fmtKb(st.memTotal)}',
                kGood,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _dialTile(
                S.flash,
                flashFrac.toDouble(),
                '${(flashFrac * 100).toStringAsFixed(0)}%',
                '${fmtKb(st.flashUsed)} / ${fmtKb(st.flashTotal)}',
                const Color(0xFF8B7CFF),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),

        // ---- bento: devices + small stats
        IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                flex: 5,
                child: Tile(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Caption(S.devices),
                      const SizedBox(height: 4),
                      BigNumber('${cl.length}', size: 40),
                      const Spacer(),
                      _bandBar(n5, n24, nLan, s.accent),
                      const SizedBox(height: 8),
                      Text('5G $n5  •  2.4G $n24  •  LAN $nLan',
                          style: TextStyle(color: t.sub, fontSize: 11.5)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 4,
                child: Column(
                  children: [
                    Expanded(
                      child: Tile(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Caption(S.uptime),
                            const SizedBox(height: 2),
                            Text(fmtUptime(st.uptime),
                                style: const TextStyle(
                                    fontFamily: kMono,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 18)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Expanded(
                      child: Tile(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Caption(S.temperature),
                            const SizedBox(height: 2),
                            Text(
                              st.tempC == null
                                  ? '--'
                                  : '${st.tempC!.toStringAsFixed(0)}°C',
                              style: TextStyle(
                                fontFamily: kMono,
                                fontWeight: FontWeight.w700,
                                fontSize: 18,
                                color: (st.tempC ?? 0) > 75 ? kBad : t.text,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),

        // ---- WAN
        Tile(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  StatusDot(up: info.wanUp),
                  const SizedBox(width: 10),
                  const Text('WAN',
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  const Spacer(),
                  if (info.wanProto.isNotEmpty) Pill(info.wanProto, s.accent),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: _kv('IP', info.wanIp)),
                  Expanded(child: _kv('DNS', info.dns)),
                ],
              ),
            ],
          ),
        ),

        // ---- quick toggles
        if (radios.isNotEmpty) ...[
          const SectionTitle(S.quickToggles),
          for (var i = 0; i < radios.length; i += 2)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                children: [
                  Expanded(child: _radioToggle(api, radios[i])),
                  const SizedBox(width: 10),
                  Expanded(
                    child: i + 1 < radios.length
                        ? _radioToggle(api, radios[i + 1])
                        : const SizedBox.shrink(),
                  ),
                ],
              ),
            ),
        ],

        // ---- guest / IoT quick toggles
        if (_wifi != null && api != null) ...[
          for (final kind in const ['guest', 'iot'])
            if (findGuest(_wifi!, kind).exists)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: ToggleTile(
                  icon: kind == 'iot' ? Icons.sensors_rounded : Icons.people_alt_rounded,
                  title: kind == 'iot' ? S.iotWifi : S.guestWifi,
                  subtitle: findGuest(_wifi!, kind).ssid,
                  value: findGuest(_wifi!, kind).enabled,
                  onChanged: (v) async {
                    await editConfig(context, (a) => a.stageGuestEnabled(findGuest(_wifi!, kind), v));
                    try {
                      final w = await api.loadWifi();
                      if (mounted) setState(() => _wifi = w);
                    } catch (_) {}
                  },
                ),
              ),
        ],

        // ---- speed and usage
        Row(
          children: [
            Expanded(
              child: Tile(
                padding: const EdgeInsets.all(16),
                onTap: () => Navigator.push(
                    context, MaterialPageRoute<void>(builder: (_) => const SpeedScreen())),
                child: const Row(children: [
                  Icon(Icons.speed_rounded),
                  SizedBox(width: 10),
                  Expanded(child: Text(S.speedTest, style: TextStyle(fontWeight: FontWeight.w800))),
                ]),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Tile(
                padding: const EdgeInsets.all(16),
                onTap: () => Navigator.push(
                    context, MaterialPageRoute<void>(builder: (_) => const UsageScreen())),
                child: const Row(children: [
                  Icon(Icons.data_usage_rounded),
                  SizedBox(width: 10),
                  Expanded(child: Text(S.dataUsage, style: TextStyle(fontWeight: FontWeight.w800))),
                ]),
              ),
            ),
          ],
        ),

        // ---- actions
        const SectionTitle(S.actions),
        Row(
          children: [
            Expanded(
              child: FilledButton.tonalIcon(
                onPressed: api == null
                    ? null
                    : () => _action(api.restartWifi, S.wifiReloading),
                icon: const Icon(Icons.wifi_rounded),
                label: const Text(S.restartWifi),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton.tonalIcon(
                onPressed: api == null
                    ? null
                    : () async {
                        final ok = await confirmDialog(
                            context, S.restartNetwork, S.restartNetworkMsg);
                        if (ok) {
                          await _action(api.restartNetwork, S.networkRestarting);
                        }
                      },
                icon: const Icon(Icons.refresh_rounded),
                label: const Text(S.restartNetwork),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        HoldButton(
          label: S.holdToReboot,
          icon: Icons.power_settings_new_rounded,
          color: kBad,
          onConfirmed: () {
            if (api != null) _action(api.reboot, S.rebooting);
          },
        ),
      ],
    );
  }

  Widget _dialTile(String label, double v, String center, String sub, Color c) {
    final t = context.watch<AppState>().theme;
    return Tile(
      padding: const EdgeInsets.fromLTRB(8, 14, 8, 12),
      child: Column(
        children: [
          Dial(value: v, center: center, color: c, size: 78),
          const SizedBox(height: 8),
          Caption(label),
          const SizedBox(height: 2),
          Text(sub,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: t.sub, fontSize: 10.5)),
        ],
      ),
    );
  }

  Widget _kv(String k, String v) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Caption(k),
        const SizedBox(height: 3),
        Text(v.isEmpty ? '-' : v,
            style: const TextStyle(fontFamily: kMono, fontSize: 13),
            maxLines: 2,
            overflow: TextOverflow.ellipsis),
      ],
    );
  }

  Widget _bandBar(int a, int b, int c, Color accent) {
    Widget seg(int n, Color col) => Expanded(
          flex: math.max(n, 0),
          child: Container(height: 8, color: col),
        );
    if (a + b + c == 0) {
      return Container(
        height: 8,
        decoration: BoxDecoration(
          color: context.watch<AppState>().theme.outline,
          borderRadius: BorderRadius.circular(4),
        ),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(4),
      child: SizedBox(
        height: 8,
        child: Row(
          children: [
            if (a > 0) seg(a, accent),
            if (b > 0) seg(b, kGood),
            if (c > 0) seg(c, kWarm),
          ],
        ),
      ),
    );
  }

  Widget _radioToggle(RouterApi? api, RadioInfo r) {
    return ToggleTile(
      icon: Icons.wifi_rounded,
      title: '${r.band} Wi-Fi',
      subtitle: 'Channel ${r.channel}',
      value: !r.disabled,
      color: r.band == '5G' ? const Color(0xFF8B7CFF) : kGood,
      onChanged: api == null ? null : (v) => _toggleRadio(api, r, v),
    );
  }
}
