import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/forms.dart';
import '../core/oui.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';
import 'apply_flow.dart';

const List<String> _filters = ['All', '5G', '2.4G', 'LAN', 'IoT', 'Guest', 'Blocked'];

class ClientsTab extends StatefulWidget {
  const ClientsTab({super.key});

  @override
  State<ClientsTab> createState() => _ClientsTabState();
}

class _ClientsTabState extends State<ClientsTab> {
  ClientsData? _data;
  String? _guestSsid;
  String? _iotSsid;
  Map<String, List<int>>? _usage;
  bool _usageMissing = false;
  String? _error;
  String _filter = 'All';
  String _query = '';
  Timer? _timer;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    if (_busy) return;
    final api = context.read<AppState>().api;
    if (api == null) return;
    _busy = true;
    try {
      final d = await api.loadClients();
      String? g;
      String? i;
      try {
        final w = await api.loadWifi();
        final gn = findGuest(w, 'guest');
        final inn = findGuest(w, 'iot');
        g = gn.exists ? gn.ssid : null;
        i = inn.exists ? inn.ssid : null;
      } catch (_) {}
      Map<String, List<int>>? u;
      var missing = false;
      try {
        u = await api.deviceUsage();
        missing = u == null;
      } catch (_) {}
      if (mounted) {
        setState(() {
          _data = d;
          _guestSsid = g;
          _iotSsid = i;
          _usage = u;
          _usageMissing = missing;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      _busy = false;
    }
  }

  String _name(NetClient c) {
    final a = context.read<AppState>().alias(c.mac);
    if (a != null && a.isNotEmpty) return a;
    if (c.hostname.isNotEmpty) return c.hostname;
    return S.unknownDevice;
  }

  String _kind(NetClient c) {
    if (c.ssid.isNotEmpty && c.ssid == _guestSsid) return 'Guest';
    if (c.ssid.isNotEmpty && c.ssid == _iotSsid) return 'IoT';
    return c.band;
  }

  bool _match(NetClient c) {
    final d = _data;
    final blocked = d != null && d.blocked.containsKey(c.mac);
    switch (_filter) {
      case 'All':
        break;
      case 'Blocked':
        if (!blocked) return false;
        break;
      default:
        if (_kind(c) != _filter) return false;
    }
    if (_query.isEmpty) return true;
    final q = _query.toLowerCase();
    return _name(c).toLowerCase().contains(q) ||
        c.ip.contains(q) ||
        c.mac.contains(q) ||
        vendorOf(c.mac).toLowerCase().contains(q);
  }

  Color _bandColor(String k) {
    switch (k) {
      case '5G':
        return const Color(0xFF4D8DFF);
      case '2.4G':
        return const Color(0xFF22C3EE);
      case '6G':
        return const Color(0xFF8B7CFF);
      case 'Guest':
        return kWarm;
      case 'IoT':
        return const Color(0xFFFF6B5B);
      default:
        return kGood;
    }
  }

  Future<void> _rename(NetClient c) async {
    final s = context.read<AppState>();
    final v = await askText(context, S.devRename, initial: s.alias(c.mac) ?? c.hostname);
    if (v == null) return;
    await s.setAlias(c.mac, v);
  }

  Future<void> _block(NetClient c, bool block) async {
    final ok = await editConfig(context, (a) async {
      if (block) {
        await a.stageBlock(c.mac);
      } else {
        await a.stageUnblock(c.mac);
      }
    });
    if (ok && block && c.ip.isNotEmpty) {
      final a = context.read<AppState>().api;
      await a?.killConnections(c.ip);
    }
    if (ok) _load();
  }

  Future<void> _lease(NetClient c) async {
    final r = await showForm(
      context,
      S.devLease,
      [
        const FNote(S.devLeaseNote),
        FText('name', S.fieldName, initial: _name(c) == S.unknownDevice ? '' : _name(c)),
        FText('ip', S.fieldIp, initial: c.ip, keyboard: TextInputType.number),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    await editConfig(context, (a) => a.stageStaticLease(r.s('name'), c.mac, r.s('ip')));
    if (mounted) _load();
  }

  Future<void> _removeLease(NetClient c) async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    final ok = await editConfig(context, (a) async {
      final d = await a.loadNetwork();
      for (final h in d.dhcp.ofType('host')) {
        if ((h.o('mac') ?? '').toLowerCase() == c.mac) {
          await a.stageDeleteLease(h.name);
        }
      }
    });
    if (ok) _load();
  }

  Future<void> _wol(NetClient c) async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final hint = await api.wakeOnLan(c.mac);
      if (!mounted) return;
      showMsg(context, hint == null ? S.devWolSent : '${S.devWolMissing}  $hint');
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  void _sheet(NetClient c) {
    final d = _data;
    final blocked = d?.blocked.containsKey(c.mac) ?? false;
    final reserved = d?.reserved[c.mac];
    final use = _usage?[c.mac];
    final vendor = vendorOf(c.mac);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        void run(VoidCallback f) {
          Navigator.pop(ctx);
          f();
        }

        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(_name(c),
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(
                  [
                    if (c.ip.isNotEmpty) c.ip,
                    c.mac,
                    if (vendor.isNotEmpty) vendor,
                  ].join('  •  '),
                  style: const TextStyle(fontFamily: kMono, fontSize: 12),
                ),
                const SizedBox(height: 14),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  Pill(_kind(c), _bandColor(_kind(c))),
                  if (c.ssid.isNotEmpty) Pill(c.ssid, const Color(0xFF8B7CFF)),
                  if (c.signal != null) Pill('${c.signal} dBm', kGood),
                  if (reserved != null) Pill('${S.devReserved} $reserved', kWarm),
                  if (blocked) const Pill(S.devBlocked, kBad),
                ]),
                const SizedBox(height: 14),
                if (use != null)
                  Tile(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Expanded(child: _usageCell(S.download, fmtBytes(use[0]))),
                        Expanded(child: _usageCell(S.upload, fmtBytes(use[1]))),
                      ],
                    ),
                  )
                else if (_usageMissing)
                  Text(S.devUsageHint, style: const TextStyle(fontSize: 12.5)),
                const SizedBox(height: 10),
                InsetGroup(children: [
                  SettingRow(
                    icon: Icons.edit_rounded,
                    title: S.devRename,
                    onTap: () => run(() => _rename(c)),
                  ),
                  SettingRow(
                    icon: blocked ? Icons.lock_open_rounded : Icons.block_rounded,
                    color: blocked ? kGood : kBad,
                    title: blocked ? S.devUnblock : S.devBlock,
                    subtitle: blocked ? null : S.devBlockSub,
                    onTap: () => run(() => _block(c, !blocked)),
                  ),
                  if (reserved == null)
                    SettingRow(
                      icon: Icons.push_pin_rounded,
                      title: S.devLease,
                      subtitle: S.devLeaseSub,
                      onTap: () => run(() => _lease(c)),
                    )
                  else
                    SettingRow(
                      icon: Icons.push_pin_outlined,
                      title: S.devLeaseRemove,
                      subtitle: reserved,
                      onTap: () => run(() => _removeLease(c)),
                    ),
                  SettingRow(
                    icon: Icons.power_settings_new_rounded,
                    color: kWarm,
                    title: S.devWol,
                    subtitle: S.devWolSub,
                    onTap: () => run(() => _wol(c)),
                  ),
                ]),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _usageCell(String label, String v) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Caption(label),
          const SizedBox(height: 4),
          Text(v, style: const TextStyle(fontFamily: kMono, fontSize: 18, fontWeight: FontWeight.w800)),
        ],
      );

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    final d = _data;
    if (d == null) {
      return _error != null ? ErrorBox(_error!, onRetry: _load) : const Loading();
    }
    final list = d.clients.where(_match).toList();
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 140),
        children: [
          Row(
            children: [
              Expanded(
                child: Tile(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      BigNumber('${d.clients.length}', size: 34),
                      const SizedBox(width: 10),
                      const Expanded(child: Caption(S.devOnline)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Tile(
                  padding: const EdgeInsets.all(16),
                  tint: d.blocked.isEmpty ? null : kBad,
                  child: Row(
                    children: [
                      BigNumber('${d.blocked.length}', size: 34),
                      const SizedBox(width: 10),
                      const Expanded(child: Caption(S.devBlockedCount)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            onChanged: (v) => setState(() => _query = v.trim()),
            decoration: InputDecoration(
              hintText: S.devSearch,
              prefixIcon: const Icon(Icons.search_rounded),
              filled: true,
              fillColor: t.surface,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(22),
                borderSide: BorderSide(color: t.outline),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(22),
                borderSide: BorderSide(color: t.outline),
              ),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 38,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                for (final f in _filters)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(f == 'All' ? S.fAll : f),
                      selected: _filter == f,
                      onSelected: (_) => setState(() => _filter = f),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          if (list.isEmpty)
            const Padding(
              padding: EdgeInsets.all(32),
              child: Center(child: Text(S.devNone)),
            ),
          for (final c in list)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Tile(
                padding: const EdgeInsets.all(14),
                tint: d.blocked.containsKey(c.mac) ? kBad : null,
                onTap: () => _sheet(c),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: _bandColor(_kind(c)).withAlpha(40),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Icon(
                        _kind(c) == 'LAN' ? Icons.settings_ethernet_rounded : Icons.smartphone_rounded,
                        color: _bandColor(_kind(c)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_name(c),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          const SizedBox(height: 2),
                          Text(
                            [
                              if (c.ip.isNotEmpty) c.ip,
                              if (vendorOf(c.mac).isNotEmpty) vendorOf(c.mac),
                            ].join('  •  '),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: t.sub, fontSize: 12, fontFamily: kMono),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Pill(_kind(c), _bandColor(_kind(c))),
                        if (c.signal != null) ...[
                          const SizedBox(height: 4),
                          Text('${c.signal} dBm',
                              style: TextStyle(color: t.sub, fontSize: 11, fontFamily: kMono)),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ),
          // devices blocked but not currently connected
          for (final e in d.blocked.entries)
            if (_filter == 'Blocked' && !d.clients.any((c) => c.mac == e.key))
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Tile(
                  tint: kBad,
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          context.read<AppState>().alias(e.key) ??
                              (e.value.isEmpty ? e.key : e.value),
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                      TextButton(
                        onPressed: () => editConfig(context, (a) => a.stageUnblock(e.key))
                            .then((_) => _load()),
                        child: const Text(S.devUnblock),
                      ),
                    ],
                  ),
                ),
              ),
        ],
      ),
    );
  }
}
