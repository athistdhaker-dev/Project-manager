import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/forms.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';
import 'apply_flow.dart';
import 'firewall.dart';

class NetworkTab extends StatefulWidget {
  const NetworkTab({super.key});

  @override
  State<NetworkTab> createState() => _NetworkTabState();
}

class _NetworkTabState extends State<NetworkTab> {
  NetworkData? _data;
  RouterInfo? _info;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final d = await api.loadNetwork();
      RouterInfo? i;
      try {
        i = await api.loadInfo();
      } catch (_) {}
      if (mounted) {
        setState(() {
          _data = d;
          _info = i;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _stage(Future<void> Function(RouterApi a) f) async {
    await editConfig(context, f);
    if (mounted) _load();
  }

  void _push(Widget w) => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => w));

  Future<void> _editLan(LanConfig c) async {
    final r = await showForm(
      context,
      S.lanSettings,
      [
        FText('ip', S.routerIp, initial: c.ip, keyboard: TextInputType.number),
        FText('mask', S.netmask, initial: c.netmask, keyboard: TextInputType.number),
        FSwitch('dhcp', S.dhcpServer, initial: c.dhcpEnabled),
        FText('start', S.dhcpStart, initial: c.start, keyboard: TextInputType.number),
        FText('limit', S.dhcpLimit, initial: c.limit, keyboard: TextInputType.number),
        FText('lease', S.leaseTime, initial: c.leasetime, hint: '12h'),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    await _stage((a) => a.stageLan(LanConfig(
          ip: r.s('ip'),
          netmask: r.s('mask'),
          dhcpEnabled: r.b('dhcp'),
          start: r.s('start'),
          limit: r.s('limit'),
          leasetime: r.s('lease'),
        )));
  }

  Future<void> _editWan(WanConfig c) async {
    final r = await showForm(
      context,
      S.wanSettings,
      [
        FPick('proto', S.protocol, const [('dhcp', 'DHCP client'), ('pppoe', 'PPPoE'), ('static', 'Static IP')],
            initial: c.proto),
        const FNote(S.wanFieldsNote),
        FText('user', S.pppoeUser, initial: c.username),
        FText('pass', S.pppoePass, obscure: true),
        FText('ip', S.staticIp, initial: c.ip, keyboard: TextInputType.number),
        FText('mask', S.netmask, initial: c.netmask.isEmpty ? '255.255.255.0' : c.netmask),
        FText('gw', S.gateway, initial: c.gateway, keyboard: TextInputType.number),
        FText('mtu', S.mtu, initial: c.mtu, hint: S.optional, keyboard: TextInputType.number),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    await _stage((a) => a.stageWan(
          proto: r.s('proto'),
          username: r.s('user'),
          password: r.s('pass'),
          ip: r.s('ip'),
          netmask: r.s('mask'),
          gateway: r.s('gw'),
          mtu: r.s('mtu'),
          metric: c.metric,
        ));
  }

  Future<void> _dns(WanConfig c) async {
    final r = await showForm(
      context,
      S.dnsOverride,
      [
        const FNote(S.dnsNote),
        FPick('preset', S.preset, const [
          ('', 'ISP default'),
          ('1.1.1.1 1.0.0.1', 'Cloudflare'),
          ('8.8.8.8 8.8.4.4', 'Google'),
          ('9.9.9.9 149.112.112.112', 'Quad9'),
          ('custom', 'Custom'),
        ], initial: c.dns.isEmpty ? '' : 'custom'),
        FText('custom', S.customDns, initial: c.dns, hint: '1.1.1.1 8.8.8.8'),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    final raw = r.s('preset') == 'custom' ? r.s('custom') : r.s('preset');
    final list = raw.split(RegExp(r'[\s,]+')).where((e) => e.isNotEmpty).toList();
    await _stage((a) => a.stageDnsOverride(list));
  }

  Future<void> _mac(WanConfig c) async {
    final v = await askText(context, S.macClone, initial: c.macaddr, hint: 'aa:bb:cc:dd:ee:ff');
    if (v == null || !mounted) return;
    await _stage((a) => a.stageMacClone(v));
  }

  Future<void> _ipv6(WanConfig c) async {
    final r = await showForm(
      context,
      S.ipv6,
      [
        const FNote(S.ipv6Note),
        FSwitch('on', S.ipv6Enable, initial: c.ipv6Enabled),
        FText('pd', S.prefixLen, initial: c.reqPrefix, hint: 'auto'),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    await _stage((a) => a.stageIpv6(enabled: r.b('on'), reqPrefix: r.s('pd').isEmpty ? 'auto' : r.s('pd')));
  }

  Future<void> _failover(NetworkData d) async {
    final wan = d.network['wan'];
    final wan6 = d.network['wan6'];
    final r = await showForm(
      context,
      S.failover,
      [
        const FNote(S.failoverNote),
        FText('m', S.wanMetric, initial: wan?.o('metric') ?? '10', keyboard: TextInputType.number),
        if (d.network['wanb'] != null)
          FText('mb', S.backupMetric, initial: d.network['wanb']?.o('metric') ?? '20', keyboard: TextInputType.number),
        if (wan6 != null) FText('m6', S.wan6Metric, initial: wan6.o('metric') ?? '', keyboard: TextInputType.number),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    await _stage((a) async {
      await a.stageMetric('wan', r.s('m'));
      if (r.s('mb').isNotEmpty) await a.stageMetric('wanb', r.s('mb'));
      if (r.s('m6').isNotEmpty) await a.stageMetric('wan6', r.s('m6'));
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    final d = _data;
    if (d == null) return _error != null ? ErrorBox(_error!, onRetry: _load) : const Loading();
    final lan = parseLan(d);
    final wan = parseWan(d);
    final info = _info;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 140),
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Tile(
                  onTap: () => _editLan(lan),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.lan_rounded, color: kGood),
                      const SizedBox(height: 12),
                      const Caption('LAN'),
                      const SizedBox(height: 4),
                      Text(lan.ip, style: const TextStyle(fontFamily: kMono, fontSize: 17, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text(
                        lan.dhcpEnabled ? 'DHCP .${lan.start} +${lan.limit}' : S.dhcpOff,
                        style: TextStyle(color: t.sub, fontSize: 12, fontFamily: kMono),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Tile(
                  accent: true,
                  onTap: () => _editWan(wan),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.public_rounded),
                          const Spacer(),
                          StatusDot(up: info?.wanUp ?? false),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Caption('WAN  ${wan.proto.toUpperCase()}'),
                      const SizedBox(height: 4),
                      Text(
                        (info?.wanIp ?? '').isEmpty ? '—' : info!.wanIp,
                        style: const TextStyle(fontFamily: kMono, fontSize: 17, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 4),
                      Text(info?.wanGateway ?? '',
                          style: TextStyle(color: t.sub, fontSize: 12, fontFamily: kMono)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          InsetGroup(title: S.internet, children: [
            SettingRow(
              icon: Icons.dns_rounded,
              title: S.dnsOverride,
              subtitle: wan.dns.isEmpty ? S.ispDefault : wan.dns,
              onTap: () => _dns(wan),
            ),
            SettingRow(
              icon: Icons.fingerprint_rounded,
              title: S.macClone,
              subtitle: wan.macaddr.isEmpty ? S.off : wan.macaddr,
              onTap: () => _mac(wan),
            ),
            SettingRow(
              icon: Icons.language_rounded,
              title: S.ipv6,
              subtitle: wan.ipv6Enabled ? 'DHCPv6-PD /${wan.reqPrefix}' : S.off,
              onTap: () => _ipv6(wan),
            ),
            SettingRow(
              icon: Icons.swap_vert_circle_rounded,
              title: S.failover,
              subtitle: S.failoverSub,
              onTap: () => _failover(d),
            ),
            SettingRow(
              icon: Icons.speed_rounded,
              title: S.sqm,
              subtitle: S.sqmSub,
              onTap: () => _push(const SqmScreen()),
            ),
          ]),
          InsetGroup(title: S.routing, children: [
            SettingRow(
              icon: Icons.call_split_rounded,
              title: S.vlans,
              subtitle: context.read<AppState>().env.swconfig ? 'swconfig' : 'DSA',
              onTap: () => _push(const VlanScreen()),
            ),
            SettingRow(
              icon: Icons.alt_route_rounded,
              title: S.staticRoutes,
              onTap: () => _push(const RoutesScreen()),
            ),
            SettingRow(
              icon: Icons.route_rounded,
              title: S.kernelRoutes,
              onTap: () => _push(const KernelRoutesScreen()),
            ),
          ]),
          InsetGroup(title: S.diagnostics, children: [
            SettingRow(
              icon: Icons.network_check_rounded,
              title: S.connTest,
              subtitle: S.connTestSub,
              onTap: () => _push(const DiagScreen()),
            ),
            SettingRow(
              icon: Icons.shield_rounded,
              color: const Color(0xFFFF6B5B),
              title: S.firewall,
              subtitle: S.toolFirewallSub,
              onTap: () => _push(const FirewallScreen()),
            ),
          ]),
        ],
      ),
    );
  }
}

// ======================================================================
// VLANs
// ======================================================================

class VlanScreen extends StatefulWidget {
  const VlanScreen({super.key});

  @override
  State<VlanScreen> createState() => _VlanScreenState();
}

class _VlanScreenState extends State<VlanScreen> {
  List<VlanItem>? _items;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final d = await api.loadNetwork();
      if (mounted) setState(() => _items = parseVlans(d));
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _add() async {
    final s = context.read<AppState>();
    final swconfig = s.env.swconfig;
    final r = await showForm(
      context,
      S.addVlan,
      [
        FText('id', S.vlanId, keyboard: TextInputType.number),
        FNote(swconfig ? S.vlanSwconfigNote : S.vlanDsaNote),
        FText('ports', S.vlanPorts, hint: swconfig ? '0t 2 3' : 'lan1:t lan2:u*'),
        if (!swconfig) FText('ip', S.vlanIp, hint: S.optional, keyboard: TextInputType.number),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    final ports = r.s('ports').split(RegExp(r'[\s,]+')).where((e) => e.isNotEmpty).toList();
    await editConfig(context, (a) async {
      if (swconfig) {
        await a.stageVlanSwconfig(id: r.s('id'), ports: ports.join(' '));
      } else {
        await a.stageVlanDsa(id: r.s('id'), ports: ports, ip: r.s('ip'));
      }
    });
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final items = _items;
    return SubPage(
      title: S.vlans,
      fab: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add_rounded),
        label: const Text(S.add),
      ),
      body: _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : items == null
              ? const Loading()
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
                  children: [
                    if (items.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text(S.noVlans)),
                    for (final v in items)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Tile(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              Pill('VLAN ${v.id}', const Color(0xFF8B7CFF)),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text('${v.device}  ${v.ports}',
                                    style: const TextStyle(fontFamily: kMono, fontSize: 12.5)),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_rounded, color: kBad),
                                onPressed: () async {
                                  await editConfig(context, (a) => a.stageDeleteVlan(v.section));
                                  if (mounted) _load();
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
    );
  }
}

// ======================================================================
// Static routes
// ======================================================================

class RoutesScreen extends StatefulWidget {
  const RoutesScreen({super.key});

  @override
  State<RoutesScreen> createState() => _RoutesScreenState();
}

class _RoutesScreenState extends State<RoutesScreen> {
  List<RouteItem>? _items;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final d = await api.loadNetwork();
      if (mounted) setState(() => _items = parseRoutes(d));
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _add() async {
    final r = await showForm(
      context,
      S.addRoute,
      [
        FText('iface', S.interfaceName, initial: 'lan'),
        FText('target', S.routeTarget, hint: '10.10.0.0', keyboard: TextInputType.number),
        FText('mask', S.netmask, initial: '255.255.255.0'),
        FText('gw', S.gateway, keyboard: TextInputType.number),
        FText('metric', S.metric, hint: S.optional, keyboard: TextInputType.number),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    await editConfig(context, (a) => a.stageRoute(
          iface: r.s('iface'),
          target: r.s('target'),
          netmask: r.s('mask'),
          gateway: r.s('gw'),
          metric: r.s('metric'),
        ));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final items = _items;
    return SubPage(
      title: S.staticRoutes,
      fab: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add_rounded),
        label: const Text(S.add),
      ),
      body: _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : items == null
              ? const Loading()
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
                  children: [
                    if (items.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text(S.noRoutes)),
                    for (final v in items)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Tile(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('${v.target} / ${v.netmask}',
                                        style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.w800)),
                                    Text('via ${v.gateway}  (${v.iface})${v.metric.isEmpty ? '' : '  metric ${v.metric}'}',
                                        style: const TextStyle(fontFamily: kMono, fontSize: 12)),
                                  ],
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_rounded, color: kBad),
                                onPressed: () async {
                                  await editConfig(context, (a) => a.stageDeleteRoute(v.section));
                                  if (mounted) _load();
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
    );
  }
}

class KernelRoutesScreen extends StatefulWidget {
  const KernelRoutesScreen({super.key});

  @override
  State<KernelRoutesScreen> createState() => _KernelRoutesScreenState();
}

class _KernelRoutesScreenState extends State<KernelRoutesScreen> {
  String? _text;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final t = await api.kernelRoutes();
      if (mounted) setState(() => _text = t);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return SubPage(
      title: S.kernelRoutes,
      actions: [CircleBtn(icon: Icons.refresh_rounded, onTap: _load)],
      body: _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : _text == null
              ? const Loading()
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Tile(
                      child: SelectableText(_text!,
                          style: const TextStyle(fontFamily: kMono, fontSize: 11.5, height: 1.4)),
                    ),
                  ],
                ),
    );
  }
}

// ======================================================================
// SQM
// ======================================================================

class SqmScreen extends StatefulWidget {
  const SqmScreen({super.key});

  @override
  State<SqmScreen> createState() => _SqmScreenState();
}

class _SqmScreenState extends State<SqmScreen> {
  SqmConfig? _cfg;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final c = await api.loadSqm();
      if (mounted) setState(() => _cfg = c);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _edit(SqmConfig c) async {
    final s = context.read<AppState>();
    final r = await showForm(
      context,
      S.sqm,
      [
        const FNote(S.sqmNote),
        FSwitch('on', S.sqmEnable, initial: c.enabled),
        FText('iface', S.interfaceName, initial: c.iface.isEmpty ? s.api?.wanDev ?? '' : c.iface),
        FText('down', S.downKbit, initial: c.down, keyboard: TextInputType.number),
        FText('up', S.upKbit, initial: c.up, keyboard: TextInputType.number),
        FPick('qdisc', S.qdisc, const [('cake', 'cake'), ('fq_codel', 'fq_codel')], initial: c.qdisc),
        FPick('script', S.sqmScript, const [
          ('piece_of_cake.qos', 'piece_of_cake'),
          ('layer_cake.qos', 'layer_cake'),
          ('simple.qos', 'simple'),
        ], initial: c.script),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    await editConfig(context, (a) => a.stageSqm(
          enabled: r.b('on'),
          iface: r.s('iface'),
          down: r.s('down'),
          up: r.s('up'),
          qdisc: r.s('qdisc'),
          script: r.s('script'),
        ));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final c = _cfg;
    final env = context.read<AppState>().env;
    return SubPage(
      title: S.sqm,
      body: _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : c == null
              ? const Loading()
              : !c.installed
                  ? Padding(
                      padding: const EdgeInsets.all(16),
                      child: NotAvailable(S.sqm,
                          hint: env.pkg == 'apk' ? 'apk add sqm-scripts luci-app-sqm' : 'opkg install sqm-scripts'),
                    )
                  : ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        Tile(
                          accent: c.enabled,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(c.enabled ? S.on : S.off,
                                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                              const SizedBox(height: 8),
                              Text('${c.iface}  ↓${c.down}  ↑${c.up} kbit/s  ${c.qdisc}',
                                  style: const TextStyle(fontFamily: kMono, fontSize: 12.5)),
                              const SizedBox(height: 12),
                              FilledButton(onPressed: () => _edit(c), child: const Text(S.edit)),
                            ],
                          ),
                        ),
                      ],
                    ),
    );
  }
}

// ======================================================================
// Diagnostics
// ======================================================================

class DiagScreen extends StatefulWidget {
  const DiagScreen({super.key});

  @override
  State<DiagScreen> createState() => _DiagScreenState();
}

class _DiagScreenState extends State<DiagScreen> {
  ConnTestResult? _res;
  String _out = '';
  bool _busy = false;
  final _host = TextEditingController(text: 'openwrt.org');

  @override
  void dispose() {
    _host.dispose();
    super.dispose();
  }

  Future<void> _test() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    setState(() => _busy = true);
    try {
      final r = await api.connectionTest();
      if (mounted) setState(() => _res = r);
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _tool(String tool) async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    setState(() {
      _busy = true;
      _out = '';
    });
    try {
      final o = await api.diag(tool, _host.text.trim());
      if (mounted) setState(() => _out = o);
    } catch (e) {
      if (mounted) setState(() => _out = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _row(String label, bool ok, String extra) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Icon(ok ? Icons.check_circle_rounded : Icons.cancel_rounded, color: ok ? kGood : kBad),
            const SizedBox(width: 10),
            Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700))),
            Text(extra, style: const TextStyle(fontFamily: kMono, fontSize: 12)),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final r = _res;
    return SubPage(
      title: S.diagnostics,
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
        children: [
          Tile(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(S.connTest, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                if (r != null) ...[
                  _row(S.testGateway, r.gatewayOk, r.gatewayMs.isEmpty ? '' : '${r.gatewayMs} ms'),
                  _row(S.testInternet, r.internetOk, r.internetMs.isEmpty ? '' : '${r.internetMs} ms'),
                  _row(S.testDns, r.dnsOk, ''),
                  const SizedBox(height: 6),
                ],
                FilledButton(onPressed: _busy ? null : _test, child: const Text(S.runTest)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Tile(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(controller: _host, decoration: const InputDecoration(labelText: S.hostOrIp)),
                const SizedBox(height: 10),
                Wrap(spacing: 8, children: [
                  OutlinedButton(onPressed: _busy ? null : () => _tool('ping'), child: const Text('Ping')),
                  OutlinedButton(onPressed: _busy ? null : () => _tool('traceroute'), child: const Text('Traceroute')),
                  OutlinedButton(onPressed: _busy ? null : () => _tool('nslookup'), child: const Text('Nslookup')),
                ]),
                if (_busy) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
                if (_out.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  SelectableText(_out, style: const TextStyle(fontFamily: kMono, fontSize: 11.5, height: 1.4)),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
