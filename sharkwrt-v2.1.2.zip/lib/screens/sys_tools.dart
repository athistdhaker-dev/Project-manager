import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/strings.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';

// ======================================================================
// Packages (opkg or apk)
// ======================================================================

class PackagesScreen extends StatefulWidget {
  const PackagesScreen({super.key});

  @override
  State<PackagesScreen> createState() => _PackagesScreenState();
}

class _PackagesScreenState extends State<PackagesScreen> {
  List<PackageItem>? _installed;
  List<PackageItem> _results = const [];
  Set<String> _upgradable = {};
  String _query = '';
  String? _error;
  bool _busy = false;
  String _log = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final l = await api.installedPackages();
      Set<String> up = {};
      try {
        up = {for (final p in await api.upgradablePackages()) p.name};
      } catch (_) {}
      if (mounted) {
        setState(() {
          _installed = l;
          _upgradable = up;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _search() async {
    final api = context.read<AppState>().api;
    if (api == null || _query.length < 2) return;
    setState(() => _busy = true);
    try {
      final r = await api.searchPackages(_query);
      if (mounted) setState(() => _results = r);
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _update() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    setState(() => _busy = true);
    try {
      final o = await api.updatePackageLists();
      if (mounted) setState(() => _log = o);
      await _load();
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _act(String action, String name) async {
    if (action == 'remove') {
      final ok = await confirmDialog(context, S.removePackage, name);
      if (!ok || !mounted) return;
    }
    final api = context.read<AppState>().api;
    if (api == null) return;
    setState(() => _busy = true);
    try {
      final o = await api.packageAction(action, name);
      if (mounted) setState(() => _log = o);
      await _load();
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    final env = s.env;
    if (env.pkg.isEmpty) {
      return const SubPage(
        title: S.packages,
        body: Padding(padding: EdgeInsets.all(16), child: NotAvailable(S.packages, hint: 'opkg / apk')),
      );
    }
    final inst = _installed;
    final shownInstalled = inst == null
        ? const <PackageItem>[]
        : [for (final p in inst) if (_query.isEmpty || p.name.toLowerCase().contains(_query.toLowerCase())) p];
    final installedNames = {for (final p in inst ?? const <PackageItem>[]) p.name};
    return SubPage(
      title: S.packages,
      subtitle: env.pkg,
      actions: [CircleBtn(icon: Icons.sync_rounded, tooltip: S.updateLists, onTap: _busy ? null : _update)],
      body: _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : inst == null
              ? const Loading()
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 40),
                  children: [
                    TextField(
                      onChanged: (v) => setState(() => _query = v.trim()),
                      onSubmitted: (_) => _search(),
                      textInputAction: TextInputAction.search,
                      decoration: InputDecoration(
                        hintText: S.packageSearch,
                        prefixIcon: const Icon(Icons.search_rounded),
                        suffixIcon: IconButton(icon: const Icon(Icons.cloud_download_rounded), onPressed: _search),
                        filled: true,
                        fillColor: t.surface,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(22),
                          borderSide: BorderSide(color: t.outline),
                        ),
                      ),
                    ),
                    if (_busy) const Padding(padding: EdgeInsets.only(top: 10), child: LinearProgressIndicator()),
                    if (_upgradable.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Tile(
                          tint: kWarm,
                          padding: const EdgeInsets.all(12),
                          child: Text('${_upgradable.length} ${S.upgradesAvailable}',
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                        ),
                      ),
                    if (_results.isNotEmpty) ...[
                      const SectionTitle(S.searchResults),
                      for (final p in _results)
                        _row(p, installedNames.contains(p.name), t),
                    ],
                    SectionTitle('${S.installed} (${shownInstalled.length})'),
                    for (final p in shownInstalled.take(300)) _row(p, true, t),
                    if (_log.isNotEmpty) ...[
                      const SectionTitle(S.lastOutput),
                      Tile(
                        child: SelectableText(_log.trim(),
                            style: const TextStyle(fontFamily: kMono, fontSize: 11, height: 1.35)),
                      ),
                    ],
                  ],
                ),
    );
  }

  Widget _row(PackageItem p, bool installed, SharkTheme t) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Tile(
        padding: const EdgeInsets.fromLTRB(14, 8, 8, 8),
        radius: 20,
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text(p.version, style: TextStyle(color: t.sub, fontSize: 11.5, fontFamily: kMono)),
                  if (p.desc.isNotEmpty)
                    Text(p.desc, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: t.sub, fontSize: 11.5)),
                ],
              ),
            ),
            if (installed && _upgradable.contains(p.name))
              TextButton(onPressed: _busy ? null : () => _act('upgrade', p.name), child: const Text(S.upgrade)),
            if (installed)
              IconButton(
                icon: const Icon(Icons.delete_outline_rounded, color: kBad),
                onPressed: _busy ? null : () => _act('remove', p.name),
              )
            else
              FilledButton.tonal(onPressed: _busy ? null : () => _act('install', p.name), child: const Text(S.install)),
          ],
        ),
      ),
    );
  }
}

// ======================================================================
// Backup and restore
// ======================================================================

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  bool _busy = false;

  Future<void> _backup() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    setState(() => _busy = true);
    try {
      final Uint8List data = await api.backup();
      final dir = await getTemporaryDirectory();
      final host = context.read<AppState>().active?.host ?? 'router';
      final stamp = DateTime.now().toIso8601String().substring(0, 10);
      final f = File('${dir.path}/sharkwrt-$host-$stamp.tar.gz');
      await f.writeAsBytes(data);
      await Share.shareXFiles([XFile(f.path)], text: S.backupShareText);
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restore() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    final pick = await FilePicker.platform.pickFiles(withData: true);
    final bytes = pick?.files.single.bytes;
    if (bytes == null || !mounted) return;
    final ok = await confirmDialog(context, S.restoreTitle, S.restoreWarn, ok: S.restore);
    if (!ok || !mounted) return;
    setState(() => _busy = true);
    try {
      await api.restoreBackup(bytes);
      if (mounted) showMsg(context, S.restoreStarted);
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SubPage(
      title: S.backupRestore,
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Tile(
            accent: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(S.createBackup, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                const Text(S.backupInfo),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: _busy ? null : _backup,
                  icon: const Icon(Icons.ios_share_rounded),
                  label: const Text(S.createBackup),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Tile(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(S.restoreTitle, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                const Text(S.restoreInfo),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: _busy ? null : _restore,
                  icon: const Icon(Icons.upload_file_rounded),
                  label: const Text(S.chooseBackup),
                ),
              ],
            ),
          ),
          if (_busy) const Padding(padding: EdgeInsets.only(top: 16), child: LinearProgressIndicator()),
        ],
      ),
    );
  }
}

// ======================================================================
// Firmware upgrade: five gated stages
// ======================================================================

class FirmwareScreen extends StatefulWidget {
  const FirmwareScreen({super.key});

  @override
  State<FirmwareScreen> createState() => _FirmwareScreenState();
}

class _FirmwareScreenState extends State<FirmwareScreen> {
  int _stage = 0; // number of completed stages
  bool _busy = false;
  String _info = '';
  String _dl = '';
  String _sum = '';
  String _valid = '';
  bool _validOk = false;
  bool _backedUp = false;
  bool _keep = true;
  final _url = TextEditingController();
  final _expect = TextEditingController();

  @override
  void dispose() {
    _url.dispose();
    _expect.dispose();
    super.dispose();
  }

  Future<void> _run(Future<void> Function(RouterApi a) f) async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    setState(() => _busy = true);
    try {
      await f(api);
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _step(int n, String title, Widget body, {required bool unlocked}) {
    final done = _stage >= n;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Opacity(
        opacity: unlocked || done ? 1 : 0.45,
        child: Tile(
          tint: done ? kGood : null,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(done ? Icons.check_circle_rounded : Icons.looks_one_rounded, color: done ? kGood : null),
                  const SizedBox(width: 10),
                  Expanded(child: Text('$n. $title', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                ],
              ),
              if (unlocked || done) ...[const SizedBox(height: 10), body],
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return SubPage(
      title: S.firmware,
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
        children: [
          Tile(
            tint: kWarm,
            padding: const EdgeInsets.all(14),
            child: const Text(S.firmwareWarn),
          ),
          const SizedBox(height: 12),
          _step(
            1,
            S.fwStepCheck,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_info.isNotEmpty)
                  SelectableText(_info.trim(), style: const TextStyle(fontFamily: kMono, fontSize: 11.5)),
                const SizedBox(height: 8),
                FilledButton.tonal(
                  onPressed: _busy
                      ? null
                      : () => _run((a) async {
                            final i = await a.firmwareInfo();
                            if (mounted) {
                              setState(() {
                                _info = i;
                                _stage = 1;
                              });
                            }
                          }),
                  child: const Text(S.checkRouter),
                ),
              ],
            ),
            unlocked: true,
          ),
          _step(
            2,
            S.fwStepBackup,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(S.fwBackupFirst),
                const SizedBox(height: 8),
                Row(
                  children: [
                    OutlinedButton(
                      onPressed: () => Navigator.push(
                          context, MaterialPageRoute<void>(builder: (_) => const BackupScreen())),
                      child: const Text(S.backupRestore),
                    ),
                    const SizedBox(width: 10),
                    FilledButton.tonal(
                      onPressed: _stage < 1
                          ? null
                          : () => setState(() {
                                _backedUp = true;
                                if (_stage < 2) _stage = 2;
                              }),
                      child: const Text(S.iHaveBackup),
                    ),
                  ],
                ),
              ],
            ),
            unlocked: _stage >= 1,
          ),
          _step(
            3,
            S.fwStepDownload,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(S.fwDownloadNote),
                const SizedBox(height: 8),
                TextField(controller: _url, decoration: const InputDecoration(labelText: 'https://… sysupgrade.bin')),
                const SizedBox(height: 8),
                TextField(controller: _expect, decoration: const InputDecoration(labelText: S.sha256Optional)),
                const SizedBox(height: 8),
                FilledButton.tonal(
                  onPressed: _busy || !_backedUp
                      ? null
                      : () => _run((a) async {
                            final o = await a.firmwareDownload(_url.text.trim());
                            final sum = await a.firmwareChecksum();
                            if (!mounted) return;
                            setState(() {
                              _dl = o;
                              _sum = sum;
                              _stage = 3;
                            });
                          }),
                  child: const Text(S.downloadToRouter),
                ),
                if (_dl.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  SelectableText(_dl, style: const TextStyle(fontFamily: kMono, fontSize: 11.5)),
                  SelectableText('sha256 $_sum', style: const TextStyle(fontFamily: kMono, fontSize: 11)),
                ],
              ],
            ),
            unlocked: _stage >= 2,
          ),
          _step(
            4,
            S.fwStepValidate,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_valid.isNotEmpty)
                  SelectableText(_valid, style: const TextStyle(fontFamily: kMono, fontSize: 11.5)),
                const SizedBox(height: 8),
                FilledButton.tonal(
                  onPressed: _busy
                      ? null
                      : () => _run((a) async {
                            final exp = _expect.text.trim().toLowerCase();
                            if (exp.isNotEmpty && exp != _sum.toLowerCase()) {
                              if (mounted) {
                                setState(() {
                                  _valid = S.checksumMismatch;
                                  _validOk = false;
                                });
                              }
                              return;
                            }
                            final o = await a.firmwareValidate();
                            if (!mounted) return;
                            final ok = o.contains('@@VALID');
                            setState(() {
                              _valid = o.replaceAll('@@VALID', ok ? S.imageValid : '');
                              _validOk = ok;
                              if (ok) _stage = 4;
                            });
                          }),
                  child: const Text(S.validateImage),
                ),
              ],
            ),
            unlocked: _stage >= 3,
          ),
          _step(
            5,
            S.fwStepFlash,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text(S.keepSettings),
                  value: _keep,
                  onChanged: (v) => setState(() => _keep = v),
                ),
                const SizedBox(height: 8),
                HoldButton(
                  label: S.holdToFlash,
                  icon: Icons.system_update_rounded,
                  color: kBad,
                  onConfirmed: () {
                    if (!_validOk) return;
                    _run((a) async {
                      await a.firmwareFlash(keepSettings: _keep);
                      if (mounted) {
                        showMsg(context, S.flashStarted);
                        s.disconnect();
                        Navigator.of(context).popUntil((r) => r.isFirst);
                      }
                    });
                  },
                ),
              ],
            ),
            unlocked: _stage >= 4 && _validOk,
          ),
        ],
      ),
    );
  }
}

// ======================================================================
// Speed test
// ======================================================================

class SpeedScreen extends StatefulWidget {
  const SpeedScreen({super.key});

  @override
  State<SpeedScreen> createState() => _SpeedScreenState();
}

class _SpeedScreenState extends State<SpeedScreen> {
  SpeedResult? _res;
  bool _busy = false;
  String? _note;

  Future<void> _go(bool ookla) async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    setState(() {
      _busy = true;
      _note = null;
    });
    try {
      SpeedResult? r;
      if (ookla) {
        r = await api.speedOokla();
        if (r == null) _note = S.ooklaMissing;
      } else {
        r = await api.speedQuick();
      }
      if (mounted) setState(() => _res = r ?? _res);
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _cell(String label, String v, String unit, Color c) => Expanded(
        child: Tile(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [Caption(label), const SizedBox(height: 6), BigNumber(v, unit: unit, color: c, size: 28)],
          ),
        ),
      );

  String _f(double? v, [int d = 1]) => v == null ? '—' : v.toStringAsFixed(d);

  @override
  Widget build(BuildContext context) {
    final r = _res;
    final env = context.watch<AppState>().env;
    return SubPage(
      title: S.speedTest,
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
        children: [
          Row(children: [
            _cell(S.download, _f(r?.downMbps), 'Mbps', const Color(0xFF4D8DFF)),
            const SizedBox(width: 10),
            _cell(S.upload, _f(r?.upMbps), 'Mbps', kWarm),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            _cell(S.ping, _f(r?.pingMs), 'ms', kGood),
            const SizedBox(width: 10),
            _cell(S.jitter, _f(r?.jitterMs), 'ms', const Color(0xFF8B7CFF)),
            const SizedBox(width: 10),
            _cell(S.loss, _f(r?.lossPct, 0), '%', kBad),
          ]),
          const SizedBox(height: 16),
          if (_busy) const Padding(padding: EdgeInsets.only(bottom: 12), child: LinearProgressIndicator()),
          FilledButton.icon(
            onPressed: _busy ? null : () => _go(false),
            icon: const Icon(Icons.bolt_rounded),
            label: const Text(S.quickTest),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _busy || !(env.has('speedtest') || env.has('ookla')) ? null : () => _go(true),
            icon: const Icon(Icons.speed_rounded),
            label: const Text(S.ooklaTest),
          ),
          const SizedBox(height: 10),
          Text(
            env.has('speedtest') || env.has('ookla') ? S.speedNote : S.speedNoteNoOokla,
            style: const TextStyle(fontSize: 12.5),
          ),
          if (_note != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_note!)),
          if (r != null) Padding(padding: const EdgeInsets.only(top: 8), child: Pill(r.source, kGood)),
        ],
      ),
    );
  }
}

// ======================================================================
// Data usage (vnstat)
// ======================================================================

class UsageScreen extends StatefulWidget {
  const UsageScreen({super.key});

  @override
  State<UsageScreen> createState() => _UsageScreenState();
}

class _UsageScreenState extends State<UsageScreen> {
  List<UsageData>? _data;
  bool _missing = false;
  String? _error;
  int _sel = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final d = await api.loadUsage();
      if (!mounted) return;
      setState(() {
        _missing = d == null;
        _data = d;
        // prefer the WAN interface when it is known
        final wan = api.wanDev;
        final i = d?.indexWhere((e) => e.iface == wan) ?? -1;
        if (i >= 0) _sel = i;
      });
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final env = context.read<AppState>().env;
    final d = _data;
    Widget body;
    if (_error != null) {
      body = ErrorBox(_error!, onRetry: _load);
    } else if (_missing) {
      body = Padding(
        padding: const EdgeInsets.all(16),
        child: NotAvailable(S.dataUsage,
            hint: env.pkg == 'apk' ? 'apk add vnstat2' : 'opkg install vnstat2'),
      );
    } else if (d == null) {
      body = const Loading();
    } else if (d.isEmpty) {
      body = const Padding(padding: EdgeInsets.all(24), child: Text(S.usageEmpty));
    } else {
      final u = d[_sel.clamp(0, d.length - 1)];
      final days = u.days.length > 14 ? u.days.sublist(u.days.length - 14) : u.days;
      final months = u.months.length > 12 ? u.months.sublist(u.months.length - 12) : u.months;
      final today = u.days.isEmpty ? null : u.days.last;
      body = ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 40),
        children: [
          SizedBox(
            height: 40,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                for (var i = 0; i < d.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(d[i].iface),
                      selected: i == _sel,
                      onSelected: (_) => setState(() => _sel = i),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          if (today != null)
            Row(children: [
              Expanded(
                child: Tile(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Caption(S.today),
                    const SizedBox(height: 6),
                    Text('↓ ${fmtBytes(today.rx)}', style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.w800)),
                    Text('↑ ${fmtBytes(today.tx)}', style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.w800)),
                  ]),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Tile(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Caption(S.thisMonth),
                    const SizedBox(height: 6),
                    Text('↓ ${fmtBytes(months.isEmpty ? 0 : months.last.rx)}',
                        style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.w800)),
                    Text('↑ ${fmtBytes(months.isEmpty ? 0 : months.last.tx)}',
                        style: const TextStyle(fontFamily: kMono, fontWeight: FontWeight.w800)),
                  ]),
                ),
              ),
            ]),
          const SectionTitle(S.last14Days),
          Tile(
            child: MiniBars(
              values: [for (final p in days) (p.rx + p.tx).toDouble()],
              labels: [for (final p in days) p.label.length >= 2 ? p.label.substring(p.label.length - 2) : p.label],
              color: const Color(0xFF4D8DFF),
              height: 90,
            ),
          ),
          const SectionTitle(S.months),
          for (final m in months.reversed)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Tile(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                radius: 20,
                child: Row(children: [
                  Expanded(child: Text(m.label, style: const TextStyle(fontWeight: FontWeight.w800))),
                  Text('↓ ${fmtBytes(m.rx)}   ↑ ${fmtBytes(m.tx)}',
                      style: const TextStyle(fontFamily: kMono, fontSize: 12.5)),
                ]),
              ),
            ),
        ],
      );
    }
    return SubPage(title: S.dataUsage, body: body);
  }
}
