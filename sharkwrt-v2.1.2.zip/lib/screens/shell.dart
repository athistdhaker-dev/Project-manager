import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/strings.dart';
import '../core/ui.dart';
import '../state/app_state.dart';
import 'apply_flow.dart';
import 'clients.dart';
import 'dashboard.dart';
import 'more.dart';
import 'network.dart';
import 'wifi.dart';

class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key});

  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends State<ShellScreen> {
  int _index = 0;
  final Set<int> _visited = {0};

  Widget _tab(int i) {
    switch (i) {
      case 0:
        return const DashboardTab();
      case 1:
        return _withHeader(S.navDevices, S.devicesSub, const ClientsTab());
      case 2:
        return _withHeader(S.navAir, S.airSub, const WifiTab());
      case 3:
        return _withHeader(S.navNet, S.netSub, const NetworkTab());
      default:
        return const ToolsTab();
    }
  }

  Widget _withHeader(String title, String sub, Widget body) {
    return Column(
      children: [
        TabHeader(title: title, subtitle: sub),
        Expanded(child: body),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) setState(() => _index = 0);
      },
      child: AppBackdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Stack(
            children: [
              SafeArea(
                bottom: false,
                child: IndexedStack(
                  index: _index,
                  children: [
                    for (var i = 0; i < 5; i++)
                      _visited.contains(i) ? _tab(i) : const SizedBox.shrink(),
                  ],
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 14),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const PendingBanner(),
                        if (context.watch<AppState>().pendingCount > 0)
                          const SizedBox(height: 8),
                        FloatingNav(
                          index: _index,
                          onSelect: (i) => setState(() {
                            _index = i;
                            _visited.add(i);
                          }),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem(this.icon, this.label);
}

const List<_NavItem> _items = [
  _NavItem(Icons.bolt_rounded, S.navPulse),
  _NavItem(Icons.devices_rounded, S.navDevices),
  _NavItem(Icons.wifi_rounded, S.navAir),
  _NavItem(Icons.hub_rounded, S.navNet),
  _NavItem(Icons.apps_rounded, S.navTools),
];

/// Floating pill: the selected item grows and shows its label.
class FloatingNav extends StatelessWidget {
  final int index;
  final ValueChanged<int> onSelect;
  const FloatingNav({super.key, required this.index, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    return Container(
      height: 64,
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: t.surface2,
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: t.outline),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(t.dark ? 120 : 40),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          for (var i = 0; i < _items.length; i++)
            Expanded(
              flex: i == index ? 3 : 1,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onSelect(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  curve: Curves.easeOutCubic,
                  decoration: BoxDecoration(
                    color: i == index ? s.accent : Colors.transparent,
                    borderRadius: BorderRadius.circular(26),
                  ),
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        _items[i].icon,
                        size: 22,
                        color: i == index ? Colors.black87 : t.sub,
                      ),
                      if (i == index) ...[
                        const SizedBox(width: 6),
                        Flexible(
                          child: Text(
                            _items[i].label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
