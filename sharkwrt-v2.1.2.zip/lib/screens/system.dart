import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/forms.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';
import 'apply_flow.dart';
import 'sys_tools.dart';

// ======================================================================
// Services
// ======================================================================

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  List<ServiceItem>? _list;
  String? _error;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final l = await api.loadServices();
      if (mounted) {
        setState(() {
          _list = l;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _act(String name, String action) async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      await api.serviceAction(name, action);
      if (mounted) showMsg(context, '$name: $action');
      await Future<void>.delayed(const Duration(milliseconds: 800));
      await _load();
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    final l = _list;
    final shown = l == null
        ? const <ServiceItem>[]
        : [for (final s in l) if (_query.isEmpty || s.name.contains(_query.toLowerCase())) s];
    return SubPage(
      title: S.services,
      body: l == null
          ? (_error != null ? ErrorBox(_error!, onRetry: _load) : const Loading())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
                children: [
                  TextField(
                    onChanged: (v) => setState(() => _query = v.trim()),
                    decoration: InputDecoration(
                      hintText: S.search,
                      prefixIcon: const Icon(Icons.search_rounded),
                      filled: true,
                      fillColor: t.surface,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(22),
                        borderSide: BorderSide(color: t.outline),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  for (final s in shown)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Tile(
                        padding: const EdgeInsets.fromLTRB(14, 8, 4, 8),
                        child: Row(
                          children: [
                            StatusDot(up: s.running),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(s.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                                  Text(s.enabled ? S.startsAtBoot : S.disabledAtBoot,
                                      style: TextStyle(color: t.sub, fontSize: 12)),
                                ],
                              ),
                            ),
                            PopupMenuButton<String>(
                              onSelected: (a) => _act(s.name, a),
                              itemBuilder: (_) => [
                                const PopupMenuItem(value: 'start', child: Text(S.start)),
                                const PopupMenuItem(value: 'stop', child: Text(S.stop)),
                                const PopupMenuItem(value: 'restart', child: Text(S.restart)),
                                PopupMenuItem(
                                  value: s.enabled ? 'disable' : 'enable',
                                  child: Text(s.enabled ? S.disableAtBoot : S.enableAtBoot),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
    );
  }
}

// ======================================================================
// Logs (follow mode polls the log every 2 seconds)
// ======================================================================

class LogsScreen extends StatefulWidget {
  const LogsScreen({super.key});

  @override
  State<LogsScreen> createState() => _LogsScreenState();
}

class _LogsScreenState extends State<LogsScreen> {
  String _text = '';
  String _filter = '';
  bool _kernel = false;
  bool _follow = true;
  bool _busy = false;
  String? _error;
  Timer? _timer;
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (_follow) _load();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (_busy) return;
    final api = context.read<AppState>().api;
    if (api == null) return;
    _busy = true;
    try {
      final o = await api.readLog(filter: _filter, kernel: _kernel);
      if (!mounted) return;
      setState(() {
        _text = o;
        _error = null;
      });
      if (_follow) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      _busy = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    return SubPage(
      title: S.logs,
      actions: [
        CircleBtn(
          icon: _follow ? Icons.pause_rounded : Icons.play_arrow_rounded,
          tooltip: S.follow,
          onTap: () => setState(() => _follow = !_follow),
        ),
      ],
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    onChanged: (v) {
                      _filter = v.trim();
                      _load();
                    },
                    decoration: InputDecoration(
                      hintText: S.filter,
                      prefixIcon: const Icon(Icons.filter_list_rounded),
                      filled: true,
                      fillColor: t.surface,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(22),
                        borderSide: BorderSide(color: t.outline),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: const Text('dmesg'),
                  selected: _kernel,
                  onSelected: (v) {
                    setState(() => _kernel = v);
                    _load();
                  },
                ),
              ],
            ),
          ),
          Expanded(
            child: _error != null
                ? ErrorBox(_error!, onRetry: _load)
                : Container(
                    margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: t.surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: t.outline),
                    ),
                    child: SingleChildScrollView(
                      controller: _scroll,
                      child: SelectableText(
                        _text.isEmpty ? S.empty : _text,
                        style: const TextStyle(fontFamily: kMono, fontSize: 11, height: 1.35),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

// ======================================================================
// System hub
// ======================================================================

class SystemScreen extends StatelessWidget {
  const SystemScreen({super.key});

  void _push(BuildContext c, Widget w) =>
      Navigator.push(c, MaterialPageRoute<void>(builder: (_) => w));

  Future<void> _power(BuildContext context, String what) async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      switch (what) {
        case 'reboot':
          await api.reboot();
          break;
        case 'poweroff':
          await api.powerOff();
          break;
        case 'reset':
          await api.factoryReset();
          break;
      }
      if (context.mounted) showMsg(context, S.commandSent);
    } catch (e) {
      if (context.mounted) showMsg(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final env = s.env;
    return SubPage(
      title: S.system,
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
        children: [
          Tile(
            accent: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(s.info.model.isEmpty ? S.unknownDevice : s.info.model,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(
                  [
                    if (env.release.isNotEmpty) env.release,
                    if (env.board.isNotEmpty) env.board,
                    env.fw4 ? 'fw4' : 'fw3',
                    env.pkg.isEmpty ? S.noPkgManager : env.pkg,
                    env.swconfig ? 'swconfig' : 'DSA',
                  ].join('  •  '),
                  style: const TextStyle(fontFamily: kMono, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          InsetGroup(title: S.general, children: [
            SettingRow(
              icon: Icons.badge_rounded,
              title: S.hostnameTime,
              subtitle: S.hostnameTimeSub,
              onTap: () => _push(context, const TimeHostScreen()),
            ),
            SettingRow(
              icon: Icons.lightbulb_rounded,
              color: kWarm,
              title: S.leds,
              onTap: () => _push(context, const LedsScreen()),
            ),
            SettingRow(
              icon: Icons.vpn_key_rounded,
              title: S.sshKeys,
              subtitle: S.sshKeysSub,
              onTap: () => _push(context, const KeysScreen()),
            ),
          ]),
          InsetGroup(title: S.softwareData, children: [
            SettingRow(
              icon: Icons.inventory_2_rounded,
              color: const Color(0xFF4D8DFF),
              title: S.packages,
              onTap: () => _push(context, const PackagesScreen()),
            ),
            SettingRow(
              icon: Icons.save_alt_rounded,
              color: kGood,
              title: S.backupRestore,
              subtitle: S.backupRestoreSub,
              onTap: () => _push(context, const BackupScreen()),
            ),
            SettingRow(
              icon: Icons.system_update_rounded,
              color: const Color(0xFF8B7CFF),
              title: S.firmware,
              subtitle: S.firmwareSub,
              onTap: () => _push(context, const FirmwareScreen()),
            ),
          ]),
          const SectionTitle(S.power),
          HoldButton(
            label: S.holdToReboot,
            icon: Icons.restart_alt_rounded,
            color: kWarm,
            onConfirmed: () => _power(context, 'reboot'),
          ),
          const SizedBox(height: 10),
          HoldButton(
            label: S.holdToPowerOff,
            icon: Icons.power_settings_new_rounded,
            color: kBad,
            onConfirmed: () => _power(context, 'poweroff'),
          ),
          const SizedBox(height: 10),
          HoldButton(
            label: S.holdToReset,
            icon: Icons.delete_forever_rounded,
            color: kBad,
            onConfirmed: () => _power(context, 'reset'),
          ),
          const SizedBox(height: 8),
          const Text(S.resetWarning, style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}

// ======================================================================
// Hostname, time zone, NTP
// ======================================================================

class TimeHostScreen extends StatefulWidget {
  const TimeHostScreen({super.key});

  @override
  State<TimeHostScreen> createState() => _TimeHostScreenState();
}

class _TimeHostScreenState extends State<TimeHostScreen> {
  SystemCfg? _cfg;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final c = await api.loadSystemCfg();
      if (mounted) setState(() => _cfg = c);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _edit(SystemCfg c) async {
    final match = kTimezones.where((z) => z.$3 == c.timezone).toList();
    final r = await showForm(
      context,
      S.hostnameTime,
      [
        FText('host', S.hostname, initial: c.hostname),
        FPick('tz', S.timezone, [for (final z in kTimezones) (z.$3, z.$1)],
            initial: match.isEmpty ? '' : match.first.$3),
        FSwitch('ntp', S.ntpEnable, initial: c.ntpEnabled),
        FText('servers', S.ntpServers, initial: c.ntpServers.join(' '), hint: '0.openwrt.pool.ntp.org'),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    final zone = kTimezones.where((z) => z.$3 == r.s('tz')).toList();
    await editConfig(context, (a) => a.stageSystemCfg(
          hostname: r.s('host'),
          zonename: zone.isEmpty ? c.zonename : zone.first.$2,
          timezone: r.s('tz').isEmpty ? c.timezone : r.s('tz'),
          ntpEnabled: r.b('ntp'),
          ntpServers: r.s('servers').split(RegExp(r'[\s,]+')).where((e) => e.isNotEmpty).toList(),
        ));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final c = _cfg;
    return SubPage(
      title: S.hostnameTime,
      body: _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : c == null
              ? const Loading()
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    InsetGroup(children: [
                      SettingRow(icon: Icons.badge_rounded, title: S.hostname, subtitle: c.hostname),
                      SettingRow(
                          icon: Icons.schedule_rounded,
                          title: S.timezone,
                          subtitle: c.zonename.isEmpty ? c.timezone : '${c.zonename} (${c.timezone})'),
                      SettingRow(
                          icon: Icons.sync_rounded,
                          title: S.ntp,
                          subtitle: c.ntpEnabled ? c.ntpServers.join(', ') : S.off),
                    ]),
                    FilledButton(onPressed: () => _edit(c), child: const Text(S.edit)),
                  ],
                ),
    );
  }
}

// ======================================================================
// LEDs
// ======================================================================

class LedsScreen extends StatefulWidget {
  const LedsScreen({super.key});

  @override
  State<LedsScreen> createState() => _LedsScreenState();
}

class _LedsScreenState extends State<LedsScreen> {
  List<LedItem>? _leds;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final l = await api.loadLeds();
      if (mounted) setState(() => _leds = l);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _trigger(LedItem l) async {
    final r = await showForm(
      context,
      l.name,
      [
        FPick('t', S.ledTrigger, [for (final t in l.triggers) (t, t)], initial: l.trigger),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    await editConfig(context, (a) => a.stageLedTrigger(l.name, r.s('t')));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    final l = _leds;
    return SubPage(
      title: S.leds,
      body: _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : l == null
              ? const Loading()
              : l.isEmpty
                  ? const Padding(padding: EdgeInsets.all(16), child: NotAvailable(S.leds))
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
                      children: [
                        const Padding(
                          padding: EdgeInsets.only(bottom: 10),
                          child: Text(S.ledNote, style: TextStyle(fontSize: 12.5)),
                        ),
                        for (final e in l)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Tile(
                              padding: const EdgeInsets.fromLTRB(14, 8, 8, 8),
                              onTap: () => _trigger(e),
                              child: Row(
                                children: [
                                  Icon(Icons.circle, size: 14, color: e.brightness > 0 ? kGood : Colors.grey),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(e.name, style: const TextStyle(fontWeight: FontWeight.w800, fontFamily: kMono, fontSize: 13)),
                                        Text(e.trigger, style: const TextStyle(fontSize: 12)),
                                      ],
                                    ),
                                  ),
                                  Switch(
                                    value: e.brightness > 0,
                                    onChanged: (on) async {
                                      final api = context.read<AppState>().api;
                                      try {
                                        await api?.setLedNow(e.name, on ? e.maxBrightness : 0);
                                      } catch (err) {
                                        if (context.mounted) showMsg(context, err.toString());
                                      }
                                      _load();
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ),
                      ],
                    ),
    );
  }
}

// ======================================================================
// SSH keys
// ======================================================================

class KeysScreen extends StatefulWidget {
  const KeysScreen({super.key});

  @override
  State<KeysScreen> createState() => _KeysScreenState();
}

class _KeysScreenState extends State<KeysScreen> {
  List<AuthKey>? _keys;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final k = await api.loadAuthorizedKeys();
      if (mounted) setState(() => _keys = k);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _add() async {
    final r = await showForm(
      context,
      S.addKey,
      [const FText('key', S.publicKey, hint: 'ssh-ed25519 AAAA… me@phone', lines: 4)],
      ok: S.add,
    );
    if (r == null || !mounted) return;
    try {
      await context.read<AppState>().api?.addAuthorizedKey(r.s('key'));
      _load();
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  Future<void> _remove(AuthKey k) async {
    final ok = await confirmDialog(context, S.delete, '${k.type} ${k.comment}');
    if (!ok || !mounted) return;
    try {
      await context.read<AppState>().api?.removeAuthorizedKey(k.line);
      _load();
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final keys = _keys;
    return SubPage(
      title: S.sshKeys,
      fab: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add_rounded),
        label: const Text(S.add),
      ),
      body: _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : keys == null
              ? const Loading()
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
                  children: [
                    if (keys.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text(S.noKeys)),
                    for (final k in keys)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Tile(
                          padding: const EdgeInsets.fromLTRB(14, 10, 6, 10),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(k.comment.isEmpty ? k.type : k.comment,
                                        style: const TextStyle(fontWeight: FontWeight.w800)),
                                    Text('${k.type}  ${k.preview}',
                                        style: const TextStyle(fontFamily: kMono, fontSize: 11.5)),
                                  ],
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_rounded, color: kBad),
                                onPressed: () => _remove(k),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
    );
  }
}
