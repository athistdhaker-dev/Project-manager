import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/forms.dart';
import '../core/strings.dart';
import '../core/term_themes.dart';
import '../core/ui.dart';
import '../data/snippets.dart';
import '../data/term_tab.dart';
import '../state/app_state.dart';

const TextStyle _mono = TextStyle(fontFamily: 'DejaVuSansMono', fontSize: 12);

Future<void> showSnippetsSheet(BuildContext context, TermTab tab) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (_) => _SnippetsSheet(tab: tab),
  );
}

Future<void> showHistorySheet(BuildContext context, TermTab tab) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (_) => _HistorySheet(tab: tab),
  );
}

Future<void> showTermSettings(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (_) => const _TermSettingsSheet(),
  );
}

class _SnippetsSheet extends StatefulWidget {
  final TermTab tab;
  const _SnippetsSheet({required this.tab});

  @override
  State<_SnippetsSheet> createState() => _SnippetsSheetState();
}

class _SnippetsSheetState extends State<_SnippetsSheet> {
  String _q = '';

  Future<void> _edit(Snippet? old) async {
    final v = await askForm(
      context,
      old == null ? S.termNewSnippet : S.termEditSnippet,
      [
        FField(S.termSnippetName, old?.name ?? ''),
        FField(S.termSnippetCmd, old?.cmd ?? ''),
      ],
    );
    if (v == null || v[0].isEmpty || v[1].isEmpty || !mounted) return;
    final id = old?.id ?? 'u${DateTime.now().microsecondsSinceEpoch}';
    await context.read<AppState>().saveSnippet(Snippet(id, v[0], v[1]));
  }

  bool _match(Snippet s) {
    if (_q.isEmpty) return true;
    final q = _q.toLowerCase();
    return s.name.toLowerCase().contains(q) || s.cmd.toLowerCase().contains(q);
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final host = st.active?.host ?? '';
    final mine = st.userSnippets.where(_match).toList();
    final builtin = kBuiltinSnippets.where(_match).toList();

    Widget tile(Snippet s, {bool editable = false}) => ListTile(
          title: Text(s.name),
          subtitle: Text(s.cmd, style: _mono, maxLines: 2, overflow: TextOverflow.ellipsis),
          onTap: () {
            Navigator.pop(context);
            widget.tab.type(s.resolve(host));
          },
          onLongPress: () {
            Navigator.pop(context);
            widget.tab.run(s.resolve(host));
          },
          trailing: editable
              ? PopupMenuButton<String>(
                  onSelected: (v) {
                    if (v == 'edit') {
                      _edit(s);
                    } else {
                      st.deleteSnippet(s.id);
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: Text(S.edit)),
                    PopupMenuItem(value: 'del', child: Text(S.delete)),
                  ],
                )
              : null,
        );

    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.78,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 8, 4),
            child: Row(
              children: [
                const Expanded(
                  child: Text(S.termSnippets,
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                ),
                TextButton.icon(
                  onPressed: () => _edit(null),
                  icon: const Icon(Icons.add),
                  label: const Text(S.add),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              onChanged: (v) => setState(() => _q = v),
              decoration: const InputDecoration(
                hintText: S.search,
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(S.termSnippetHint,
                  style: TextStyle(fontSize: 12, color: st.theme.sub)),
            ),
          ),
          Expanded(
            child: ListView(
              children: [
                if (mine.isNotEmpty) const SectionTitle(S.termMySnippets),
                for (final s in mine) tile(s, editable: true),
                const SectionTitle(S.termBuiltin),
                for (final s in builtin) tile(s),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _HistorySheet extends StatefulWidget {
  final TermTab tab;
  const _HistorySheet({required this.tab});

  @override
  State<_HistorySheet> createState() => _HistorySheetState();
}

class _HistorySheetState extends State<_HistorySheet> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final all = st.history().reversed.toList();
    final list = all
        .where((c) => _q.isEmpty || c.toLowerCase().contains(_q.toLowerCase()))
        .toList();
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.7,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 8, 4),
            child: Row(
              children: [
                const Expanded(
                  child: Text(S.termHistory,
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                ),
                if (all.isNotEmpty)
                  TextButton(
                    onPressed: () async {
                      await st.clearHistory();
                      if (mounted) setState(() {});
                    },
                    child: const Text(S.termClearHistory),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              onChanged: (v) => setState(() => _q = v),
              decoration: const InputDecoration(
                hintText: S.search,
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: list.isEmpty
                ? Center(
                    child: Text(S.termNoHistory,
                        style: TextStyle(color: st.theme.sub)),
                  )
                : ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (_, i) => ListTile(
                      dense: true,
                      title: Text(list[i], style: _mono),
                      onTap: () {
                        Navigator.pop(context);
                        widget.tab.type(list[i]);
                      },
                      onLongPress: () {
                        Navigator.pop(context);
                        widget.tab.run(list[i]);
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _TermSettingsSheet extends StatefulWidget {
  const _TermSettingsSheet();

  @override
  State<_TermSettingsSheet> createState() => _TermSettingsSheetState();
}

class _TermSettingsSheetState extends State<_TermSettingsSheet> {
  late final TextEditingController _startup;

  @override
  void initState() {
    super.initState();
    _startup = TextEditingController(text: context.read<AppState>().termStartup);
  }

  @override
  void dispose() {
    _startup.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + bottom),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(S.termSettings,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          Text('${S.termFontSize}: ${s.termFont.toStringAsFixed(0)}'),
          Slider(
            min: 8,
            max: 28,
            divisions: 20,
            value: s.termFont.clamp(8.0, 28.0).toDouble(),
            onChanged: s.setTermFont,
          ),
          Text('${S.termLineHeight}: ${s.termLineHeight.toStringAsFixed(2)}'),
          Slider(
            min: 1.0,
            max: 1.8,
            divisions: 16,
            value: s.termLineHeight.clamp(1.0, 1.8).toDouble(),
            onChanged: s.setTermLineHeight,
          ),
          const SizedBox(height: 8),
          const Text(S.termColorScheme),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: [
              for (var i = 0; i < kTermSchemes.length; i++)
                ChoiceChip(
                  label: Text(kTermSchemes[i]),
                  selected: s.termScheme == i,
                  onSelected: (_) => s.setTermScheme(i),
                ),
            ],
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text(S.termConfirmDanger),
            subtitle: const Text(S.termConfirmDangerSub),
            value: s.termConfirm,
            onChanged: s.setTermConfirm,
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _startup,
            autocorrect: false,
            onChanged: s.setTermStartup,
            decoration: const InputDecoration(
              labelText: S.termStartup,
              hintText: S.termStartupHint,
            ),
          ),
        ],
      ),
    );
  }
}
