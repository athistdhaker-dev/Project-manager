import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/strings.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';

enum _ReviewChoice { apply, discard, later }

/// Stages a change on the router, then walks the user through review and apply.
/// Returns true when the change ended up applied and confirmed.
Future<bool> editConfig(
  BuildContext context,
  Future<void> Function(RouterApi api) stage, {
  bool review = true,
}) async {
  final s = context.read<AppState>();
  final api = s.api;
  if (api == null) return false;
  try {
    await stage(api);
  } catch (e) {
    if (context.mounted) showMsg(context, e.toString());
    await s.refreshPending();
    return false;
  }
  if (!context.mounted) return false;
  if (!review) {
    await s.refreshPending();
    return false;
  }
  return reviewAndApply(context);
}

/// Shows the staged changes and lets the user apply, discard or leave them for later.
Future<bool> reviewAndApply(BuildContext context) async {
  final s = context.read<AppState>();
  final api = s.api;
  if (api == null) return false;
  List<PendingChange> changes;
  try {
    changes = await api.pending();
  } catch (e) {
    if (context.mounted) showMsg(context, e.toString());
    return false;
  }
  await s.refreshPending();
  if (changes.isEmpty) {
    if (context.mounted) showMsg(context, S.nothingStaged);
    return false;
  }
  if (!context.mounted) return false;
  final choice = await showModalBottomSheet<_ReviewChoice>(
    context: context,
    isScrollControlled: true,
    builder: (_) => _ReviewSheet(changes: changes),
  );
  if (choice == null || choice == _ReviewChoice.later) return false;
  if (!context.mounted) return false;
  if (choice == _ReviewChoice.discard) {
    try {
      await api.discardPending();
    } catch (e) {
      if (context.mounted) showMsg(context, e.toString());
    }
    await s.refreshPending();
    if (context.mounted) showMsg(context, S.changesDiscarded);
    return false;
  }

  ApplyResult res;
  try {
    res = await api.applyPending();
  } catch (e) {
    if (context.mounted) showMsg(context, e.toString());
    return false;
  }
  if (!res.guarded) {
    await Future<void>.delayed(const Duration(seconds: 2));
    await s.refreshPending();
    if (context.mounted) showMsg(context, S.changesApplied);
    return true;
  }
  if (!context.mounted) return false;
  final kept = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (_) => _GuardDialog(api: api, result: res),
  );
  await s.refreshPending();
  if (context.mounted) {
    showMsg(context, kept == true ? S.changesApplied : S.changesReverted);
  }
  return kept == true;
}

class _ReviewSheet extends StatelessWidget {
  final List<PendingChange> changes;
  const _ReviewSheet({required this.changes});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    final pkgs = <String>[];
    for (final c in changes) {
      if (!pkgs.contains(c.pkg)) pkgs.add(c.pkg);
    }
    final risky = pkgs.any(kRiskyPackages.contains);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(S.reviewTitle,
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                ),
                Pill('${changes.length}', s.accent),
              ],
            ),
            const SizedBox(height: 4),
            Text(pkgs.join(' • '),
                style: TextStyle(color: t.sub, fontSize: 12)),
            const SizedBox(height: 12),
            Flexible(
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: t.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: t.outline),
                ),
                child: SingleChildScrollView(
                  child: SelectableText(
                    changes.map(describeChange).join('\n'),
                    style: const TextStyle(fontFamily: kMono, fontSize: 11.5, height: 1.4),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (risky)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.shield_moon_rounded, color: kWarm, size: 20),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(S.guardExplain,
                          style: TextStyle(color: t.sub, fontSize: 12.5)),
                    ),
                  ],
                ),
              ),
            Row(
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context, _ReviewChoice.discard),
                  child: const Text(S.discard),
                ),
                const Spacer(),
                TextButton(
                  onPressed: () => Navigator.pop(context, _ReviewChoice.later),
                  child: const Text(S.later),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () => Navigator.pop(context, _ReviewChoice.apply),
                  child: const Text(S.apply),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

enum _GuardPhase { applying, confirm, reverting }

class _GuardDialog extends StatefulWidget {
  final RouterApi api;
  final ApplyResult result;
  const _GuardDialog({required this.api, required this.result});

  @override
  State<_GuardDialog> createState() => _GuardDialogState();
}

class _GuardDialogState extends State<_GuardDialog> {
  Timer? _timer;
  _GuardPhase _phase = _GuardPhase.applying;
  int _remaining = 0;
  bool _probing = false;
  int _ticks = 0;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _remaining = widget.result.guardSeconds;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  int _left() {
    final used = DateTime.now().difference(widget.result.startedAt).inSeconds;
    return (widget.result.guardSeconds - used).clamp(0, widget.result.guardSeconds);
  }

  void _finish(bool kept) {
    if (_done) return;
    _done = true;
    _timer?.cancel();
    if (mounted) Navigator.of(context).pop(kept);
  }

  Future<void> _tick() async {
    if (_done || !mounted) return;
    _ticks++;
    final used = DateTime.now().difference(widget.result.startedAt).inSeconds;
    final left = _left();
    setState(() => _remaining = left);
    if (used > widget.result.guardSeconds + 60) {
      _finish(false); // gave up waiting; the router reverts on its own
      return;
    }

    // Give the router a moment to restart services before the first probe.
    if (_ticks < 3 || _probing) return;
    if (_ticks % 2 != 0 && _phase != _GuardPhase.reverting) return;
    _probing = true;
    final ok = await widget.api.reachable();
    _probing = false;
    if (_done || !mounted) return;

    if (ok) {
      bool armed = true;
      try {
        armed = await widget.api.guardActive();
      } catch (_) {}
      if (_done || !mounted) return;
      if (!armed) {
        _finish(false); // rolled back already (timer ran out or user reverted)
        return;
      }
      setState(() => _phase = left > 0 ? _GuardPhase.confirm : _GuardPhase.reverting);
    } else if (left <= 0) {
      setState(() => _phase = _GuardPhase.reverting);
    }
  }

  Future<void> _keep() async {
    try {
      await widget.api.confirmGuard();
    } catch (_) {}
    _finish(true);
  }

  Future<void> _revert() async {
    setState(() => _phase = _GuardPhase.reverting);
    try {
      await widget.api.rollbackNow();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    String title;
    String body;
    switch (_phase) {
      case _GuardPhase.applying:
        title = S.guardApplying;
        body = S.guardApplyingMsg;
        break;
      case _GuardPhase.confirm:
        title = S.guardKeepQ;
        body = S.guardKeepMsg;
        break;
      case _GuardPhase.reverting:
        title = S.guardReverting;
        body = S.guardRevertingMsg;
        break;
    }
    return PopScope(
      canPop: false,
      child: AlertDialog(
        title: Text(title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(body, style: TextStyle(color: t.sub)),
            const SizedBox(height: 16),
            if (_phase != _GuardPhase.reverting)
              Row(
                children: [
                  BigNumber('$_remaining', unit: 's', size: 30),
                  const SizedBox(width: 12),
                  Expanded(
                    child: LinearProgressIndicator(
                      value: widget.result.guardSeconds == 0
                          ? 0
                          : _remaining / widget.result.guardSeconds,
                    ),
                  ),
                ],
              )
            else
              const LinearProgressIndicator(),
          ],
        ),
        actions: [
          if (_phase == _GuardPhase.confirm) ...[
            TextButton(onPressed: _revert, child: const Text(S.revertNow)),
            FilledButton(onPressed: _keep, child: const Text(S.keepChanges)),
          ] else if (_phase == _GuardPhase.applying)
            TextButton(onPressed: _revert, child: const Text(S.revertNow)),
        ],
      ),
    );
  }
}

/// Slim banner shown above the tab bar while changes are staged but not applied.
class PendingBanner extends StatelessWidget {
  const PendingBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    if (s.pendingCount <= 0) return const SizedBox.shrink();
    return Tile(
      tint: kWarm,
      radius: 22,
      padding: const EdgeInsets.fromLTRB(16, 6, 8, 6),
      child: Row(
        children: [
          const Icon(Icons.pending_actions_rounded, color: kWarm, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text('${s.pendingCount} ${S.stagedChanges}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
          TextButton(
            onPressed: () => reviewAndApply(context),
            child: const Text(S.review),
          ),
        ],
      ),
    );
  }
}
