import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:xterm/xterm.dart';

import '../core/strings.dart';
import '../core/term_themes.dart';
import '../core/ui.dart';
import '../data/term_manager.dart';
import '../data/term_tab.dart';
import '../state/app_state.dart';
import 'term_sheets.dart';

class TerminalScreen extends StatefulWidget {
  const TerminalScreen({super.key});

  @override
  State<TerminalScreen> createState() => _TerminalScreenState();
}

class _TerminalScreenState extends State<TerminalScreen> {
  @override
  void initState() {
    super.initState();
    context.read<AppState>().term?.ensureOne();
  }

  Future<void> _copySelection(TermTab tab) async {
    final sel = tab.controller.selection;
    if (sel == null) return;
    final text = tab.terminal.buffer.getText(sel);
    await Clipboard.setData(ClipboardData(text: text));
    tab.controller.clearSelection();
    if (mounted) showMsg(context, 'Copied');
  }

  Future<void> _paste(TermTab tab) async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text;
    if (t != null && t.isNotEmpty) tab.paste(t);
  }

  Future<void> _rename(TermManager m, int i) async {
    final v = await askText(context, S.termRenameTab, initial: m.tabs[i].title);
    if (v != null) m.rename(i, v);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final m = s.term;
    if (m == null) {
      return GlassScaffold(
        title: S.terminal,
        body: const ErrorBox(S.sshNotConnected),
      );
    }
    return AnimatedBuilder(
      animation: m,
      builder: (context, _) {
        final tab = m.current;
        final scheme = buildTermTheme(s.termScheme, s.theme, s.accent);
        return GlassBackground(
          child: Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              title: const Text(S.terminal),
              actions: [
                if (tab != null)
                  AnimatedBuilder(
                    animation: tab.controller,
                    builder: (context, _) {
                      if (tab.controller.selection == null) {
                        return IconButton(
                          tooltip: S.paste,
                          icon: const Icon(Icons.content_paste),
                          onPressed: () => _paste(tab),
                        );
                      }
                      return IconButton(
                        tooltip: S.copy,
                        icon: const Icon(Icons.copy),
                        onPressed: () => _copySelection(tab),
                      );
                    },
                  ),
                IconButton(
                  tooltip: S.termSnippets,
                  icon: const Icon(Icons.bookmarks_outlined),
                  onPressed: tab == null
                      ? null
                      : () => showSnippetsSheet(context, tab),
                ),
                IconButton(
                  tooltip: S.termHistory,
                  icon: const Icon(Icons.history),
                  onPressed: tab == null
                      ? null
                      : () => showHistorySheet(context, tab),
                ),
                PopupMenuButton<String>(
                  onSelected: (v) async {
                    if (tab == null) return;
                    if (v == 'copyall') {
                      await Clipboard.setData(ClipboardData(text: tab.fullText()));
                      if (context.mounted) showMsg(context, 'Copied');
                    } else if (v == 'share') {
                      await Share.share(tab.fullText(), subject: 'SharkWRT session log');
                    } else if (v == 'settings') {
                      if (context.mounted) showTermSettings(context);
                    } else if (v == 'close') {
                      await m.closeTab(m.selected);
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'copyall', child: Text(S.termCopyAll)),
                    PopupMenuItem(value: 'share', child: Text(S.termShareLog)),
                    PopupMenuItem(value: 'settings', child: Text(S.termSettings)),
                    PopupMenuItem(value: 'close', child: Text('Close this tab')),
                  ],
                ),
              ],
            ),
            body: SafeArea(
              top: false,
              child: Column(
                children: [
                  _TabStrip(
                    m: m,
                    onRename: (i) => _rename(m, i),
                  ),
                  if (tab != null)
                    AnimatedBuilder(
                      animation: tab,
                      builder: (context, _) {
                        if (tab.state == TermState.connected) {
                          return const SizedBox.shrink();
                        }
                        return _StatusBanner(tab: tab);
                      },
                    ),
                  Expanded(
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 8),
                      decoration: BoxDecoration(
                        color: scheme.background,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: s.theme.border),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: IndexedStack(
                        index: m.tabs.isEmpty ? 0 : m.selected,
                        children: [
                          for (final t in m.tabs)
                            _TermPane(key: ValueKey<int>(t.id), tab: t),
                        ],
                      ),
                    ),
                  ),
                  if (tab != null) _KeysBar(tab: tab, onPaste: () => _paste(tab)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _TabStrip extends StatelessWidget {
  final TermManager m;
  final void Function(int) onRename;
  const _TabStrip({required this.m, required this.onRename});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return SizedBox(
      height: 48,
      child: Row(
        children: [
          Expanded(
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              children: [
                for (var i = 0; i < m.tabs.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: GestureDetector(
                      onTap: () => m.select(i),
                      onLongPress: () => onRename(i),
                      child: AnimatedBuilder(
                        animation: m.tabs[i],
                        builder: (context, _) {
                          final sel = i == m.selected;
                          final up = m.tabs[i].state == TermState.connected;
                          return Container(
                            padding: const EdgeInsets.only(left: 12, right: 4),
                            decoration: BoxDecoration(
                              color: sel
                                  ? s.accent.withAlpha(70)
                                  : s.theme.panel,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                  color: sel ? s.accent : s.theme.border),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.circle,
                                    size: 8,
                                    color: up ? Colors.greenAccent : Colors.redAccent),
                                const SizedBox(width: 8),
                                Text(m.tabs[i].title),
                                SizedBox(
                                  width: 32,
                                  height: 32,
                                  child: IconButton(
                                    padding: EdgeInsets.zero,
                                    iconSize: 16,
                                    icon: const Icon(Icons.close),
                                    onPressed: () => m.closeTab(i),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ),
              ],
            ),
          ),
          IconButton(
            tooltip: S.termNewTab,
            icon: const Icon(Icons.add),
            onPressed: m.open,
          ),
        ],
      ),
    );
  }
}

class _StatusBanner extends StatelessWidget {
  final TermTab tab;
  const _StatusBanner({required this.tab});

  @override
  Widget build(BuildContext context) {
    final connecting = tab.state == TermState.connecting;
    return Container(
      margin: const EdgeInsets.fromLTRB(8, 0, 8, 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: (connecting ? Colors.orange : Colors.redAccent).withAlpha(50),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(connecting ? Icons.sync : Icons.link_off, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              connecting
                  ? S.termConnecting
                  : (tab.error ?? S.termDisconnected),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (!connecting)
            TextButton(onPressed: tab.reconnect, child: const Text(S.termReconnect)),
        ],
      ),
    );
  }
}

class _TermPane extends StatefulWidget {
  final TermTab tab;
  const _TermPane({super.key, required this.tab});

  @override
  State<_TermPane> createState() => _TermPaneState();
}

class _TermPaneState extends State<_TermPane> {
  final ScrollController _sc = ScrollController();
  final FocusNode _focus = FocusNode();
  bool _showJump = false;

  final Map<int, Offset> _ptrs = <int, Offset>{};
  bool _pinching = false;
  double _startDist = 0;
  double _startFont = 13;
  double _font = 13;

  @override
  void initState() {
    super.initState();
    _sc.addListener(_onScroll);
  }

  @override
  void dispose() {
    _sc.removeListener(_onScroll);
    _sc.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_sc.hasClients) return;
    final away = _sc.position.maxScrollExtent - _sc.offset > 80;
    if (away != _showJump) setState(() => _showJump = away);
  }

  double _dist() {
    final l = _ptrs.values.toList();
    if (l.length < 2) return 0;
    return (l[0] - l[1]).distance;
  }

  void _down(PointerDownEvent e) {
    _ptrs[e.pointer] = e.position;
    if (_ptrs.length == 2) {
      _startDist = _dist();
      _startFont = context.read<AppState>().termFont;
      _font = _startFont;
      _pinching = true;
    }
  }

  void _move(PointerMoveEvent e) {
    if (!_ptrs.containsKey(e.pointer)) return;
    _ptrs[e.pointer] = e.position;
    if (_pinching && _ptrs.length >= 2 && _startDist > 0) {
      final f = (_startFont * _dist() / _startDist).clamp(8.0, 28.0).toDouble();
      if ((f - _font).abs() >= 0.4) setState(() => _font = f);
    }
  }

  void _up(PointerEvent e) {
    _ptrs.remove(e.pointer);
    if (_pinching && _ptrs.length < 2) {
      _pinching = false;
      context.read<AppState>().setTermFont(_font);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final theme = buildTermTheme(s.termScheme, s.theme, s.accent);
    final font = _pinching ? _font : s.termFont;
    return Stack(
      children: [
        Listener(
          onPointerDown: _down,
          onPointerMove: _move,
          onPointerUp: _up,
          onPointerCancel: _up,
          child: TerminalView(
            widget.tab.terminal,
            controller: widget.tab.controller,
            scrollController: _sc,
            focusNode: _focus,
            autofocus: true,
            theme: theme,
            textStyle: TerminalStyle(
              fontSize: font,
              height: s.termLineHeight,
              fontFamily: 'DejaVuSansMono',
            ),
            padding: const EdgeInsets.all(6),
          ),
        ),
        if (_showJump)
          Positioned(
            right: 10,
            bottom: 10,
            child: FloatingActionButton.small(
              tooltip: S.termJumpBottom,
              onPressed: () {
                if (_sc.hasClients) {
                  _sc.animateTo(
                    _sc.position.maxScrollExtent,
                    duration: const Duration(milliseconds: 200),
                    curve: Curves.easeOut,
                  );
                }
              },
              child: const Icon(Icons.keyboard_double_arrow_down),
            ),
          ),
      ],
    );
  }
}

class _KeysBar extends StatelessWidget {
  final TermTab tab;
  final VoidCallback onPaste;
  const _KeysBar({required this.tab, required this.onPaste});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    Widget k(String label, VoidCallback f, {double w = 44}) => _KeyButton(
          label: label,
          width: w,
          onTap: f,
        );
    Widget mod(String label, ValueNotifier<bool> n) => ValueListenableBuilder<bool>(
          valueListenable: n,
          builder: (context, on, _) => _KeyButton(
            label: label,
            width: 52,
            active: on,
            onTap: () => n.value = !n.value,
          ),
        );
    return Container(
      height: 52,
      margin: const EdgeInsets.fromLTRB(8, 6, 8, 6),
      decoration: BoxDecoration(
        color: s.theme.panel,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: s.theme.border),
      ),
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        children: [
          k('Esc', () => tab.raw('\x1b')),
          k('Tab', () => tab.raw('\t')),
          mod('Ctrl', tab.ctrl),
          mod('Alt', tab.alt),
          k('←', () => tab.key(TerminalKey.arrowLeft)),
          k('↑', () => tab.key(TerminalKey.arrowUp)),
          k('↓', () => tab.key(TerminalKey.arrowDown)),
          k('→', () => tab.key(TerminalKey.arrowRight)),
          k('Home', () => tab.key(TerminalKey.home), w: 52),
          k('End', () => tab.key(TerminalKey.end)),
          k('PgUp', () => tab.key(TerminalKey.pageUp), w: 52),
          k('PgDn', () => tab.key(TerminalKey.pageDown), w: 52),
          for (final c in const ['|', '/', '\\', '-', '_', '~', '`'])
            k(c, () => tab.type(c), w: 38),
          k('^C', () => tab.raw('\x03')),
          k('^D', () => tab.raw('\x04')),
          k('^Z', () => tab.raw('\x1a')),
          k('^L', () => tab.raw('\x0c')),
          k('^R', () => tab.raw('\x12')),
          k('Paste', onPaste, w: 56),
        ],
      ),
    );
  }
}

class _KeyButton extends StatelessWidget {
  final String label;
  final double width;
  final bool active;
  final VoidCallback onTap;
  const _KeyButton({
    required this.label,
    required this.onTap,
    this.width = 44,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        width: width,
        margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 6),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active ? s.accent.withAlpha(110) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: active ? s.accent : Colors.transparent),
        ),
        child: Text(
          label,
          style: const TextStyle(
            fontFamily: 'DejaVuSansMono',
            fontSize: 13,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}
