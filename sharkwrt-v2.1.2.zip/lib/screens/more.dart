import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/strings.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import '../state/app_state.dart';
import 'firewall.dart';
import 'settings.dart';
import 'sys_tools.dart';
import 'system.dart';
import 'terminal.dart';

class _Tool {
  final IconData icon;
  final Color color;
  final String title;
  final String sub;
  final Widget Function() page;
  const _Tool(this.icon, this.color, this.title, this.sub, this.page);
}

class ToolsTab extends StatelessWidget {
  const ToolsTab({super.key});

  List<_Tool> _tools() => [
        _Tool(Icons.terminal_rounded, kGood, S.terminal, S.toolTerminalSub,
            () => const TerminalScreen()),
        _Tool(Icons.shield_rounded, const Color(0xFFFF6B5B), S.firewall,
            S.toolFirewallSub, () => const FirewallScreen()),
        _Tool(Icons.miscellaneous_services_rounded, const Color(0xFF4D8DFF),
            S.services, S.toolServicesSub, () => const ServicesScreen()),
        _Tool(Icons.article_rounded, kWarm, S.logs, S.toolLogsSub,
            () => const LogsScreen()),
        _Tool(Icons.inventory_2_rounded, const Color(0xFF4D8DFF), S.packages,
            S.toolPackagesSub, () => const PackagesScreen()),
        _Tool(Icons.speed_rounded, kGood, S.speedTest, S.toolSpeedSub,
            () => const SpeedScreen()),
        _Tool(Icons.data_usage_rounded, const Color(0xFFFF6B5B), S.dataUsage,
            S.toolUsageSub, () => const UsageScreen()),
        _Tool(Icons.memory_rounded, const Color(0xFF8B7CFF), S.system,
            S.toolSystemSub, () => const SystemScreen()),
        _Tool(Icons.tune_rounded, const Color(0xFF22C3EE), S.settings,
            S.toolSettingsSub, () => const SettingsScreen()),
      ];

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final tools = _tools();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 120),
      children: [
        const TabHeader(title: S.navTools, subtitle: S.toolsSub),
        GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.12,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            for (final t in tools)
              Tile(
                padding: const EdgeInsets.all(16),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(builder: (_) => t.page()),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: t.color.withAlpha(40),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Icon(t.icon, color: t.color),
                    ),
                    const Spacer(),
                    Text(t.title,
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 2),
                    Text(t.sub,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: s.theme.sub, fontSize: 12)),
                  ],
                ),
              ),
          ],
        ),
      ],
    );
  }
}
