import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/strings.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import '../data/models.dart';
import '../data/ssh.dart';
import '../state/app_state.dart';
import 'settings.dart';
import 'shell.dart';

class RouterListScreen extends StatelessWidget {
  const RouterListScreen({super.key});

  Future<void> _open(BuildContext context, RouterProfile p) async {
    final s = context.read<AppState>();
    final nav = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    final err = await s.connect(p);
    nav.pop();
    if (err != null) {
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(err)));
      return;
    }
    await nav.push(MaterialPageRoute<void>(builder: (_) => const ShellScreen()));
    s.disconnect();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    return AppBackdrop(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 12, 0, 18),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 34,
                                height: 34,
                                decoration: BoxDecoration(
                                  color: s.accent,
                                  borderRadius: BorderRadius.circular(11),
                                ),
                                child: const Icon(Icons.waves_rounded,
                                    color: Colors.black87, size: 20),
                              ),
                              const SizedBox(width: 10),
                              const Text('SharkWRT',
                                  style: TextStyle(
                                      fontSize: 28,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: -0.8)),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(S.routersSub,
                              style: TextStyle(color: t.sub, fontSize: 13)),
                        ],
                      ),
                    ),
                    CircleBtn(
                      icon: Icons.tune_rounded,
                      tooltip: S.settings,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute<void>(
                            builder: (_) => const SettingsScreen()),
                      ),
                    ),
                  ],
                ),
              ),
              if (s.profiles.isEmpty) const _Onboarding(),
              for (final p in s.profiles)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Tile(
                    onTap: () => _open(context, p),
                    padding: const EdgeInsets.fromLTRB(16, 14, 6, 14),
                    child: Row(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: s.accent.withAlpha(40),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Icon(Icons.router_rounded, color: s.accent),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                p.name,
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.w800),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                '${p.user}@${p.host}:${p.port}',
                                style: const TextStyle(fontFamily: kMono, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        PopupMenuButton<String>(
                          onSelected: (v) async {
                            if (v == 'edit') {
                              Navigator.push(
                                context,
                                MaterialPageRoute<void>(
                                    builder: (_) => RouterFormScreen(profile: p)),
                              );
                            } else if (v == 'hostkey') {
                              await s.resetHostKey(p.id);
                              if (context.mounted) {
                                showMsg(context, S.hostKeyReset);
                              }
                            } else if (v == 'delete') {
                              final ok = await confirmDialog(
                                  context, S.delete, '${S.removeRouterQ} ${p.name}?',
                                  ok: S.delete);
                              if (ok) await s.deleteProfile(p.id);
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'edit', child: Text(S.edit)),
                            PopupMenuItem(
                                value: 'hostkey', child: Text(S.resetHostKey)),
                            PopupMenuItem(value: 'delete', child: Text(S.delete)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              if (s.profiles.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: FilledButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute<void>(
                          builder: (_) => const RouterFormScreen()),
                    ),
                    icon: const Icon(Icons.add_rounded),
                    label: const Text(S.addRouter),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Onboarding extends StatelessWidget {
  const _Onboarding();

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    Widget step(int n, String text) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 24,
                height: 24,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: s.accent.withAlpha(50),
                  shape: BoxShape.circle,
                ),
                child: Text('$n',
                    style: TextStyle(
                        color: s.accent,
                        fontWeight: FontWeight.w800,
                        fontSize: 12)),
              ),
              const SizedBox(width: 12),
              Expanded(child: Text(text)),
            ],
          ),
        );
    return Tile(
      accent: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(S.onbTitle,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          step(1, S.onbStep1),
          step(2, S.onbStep2),
          step(3, S.onbStep3),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute<void>(builder: (_) => const RouterFormScreen()),
              ),
              icon: const Icon(Icons.add_rounded),
              label: const Text(S.addRouter),
            ),
          ),
        ],
      ),
    );
  }
}

class RouterFormScreen extends StatefulWidget {
  final RouterProfile? profile;
  const RouterFormScreen({super.key, this.profile});

  @override
  State<RouterFormScreen> createState() => _RouterFormScreenState();
}

class _RouterFormScreenState extends State<RouterFormScreen> {
  late final String _id;
  late final TextEditingController _name;
  late final TextEditingController _host;
  late final TextEditingController _port;
  late final TextEditingController _user;
  final TextEditingController _pass = TextEditingController();
  final TextEditingController _key = TextEditingController();
  bool _useKey = false;
  bool _hide = true;
  bool _saving = false;
  bool _testing = false;
  String? _testResult;
  bool _testOk = false;

  @override
  void initState() {
    super.initState();
    final p = widget.profile;
    _id = p?.id ?? DateTime.now().microsecondsSinceEpoch.toString();
    _name = TextEditingController(text: p?.name ?? 'My Router');
    _host = TextEditingController(text: p?.host ?? '192.168.1.1');
    _port = TextEditingController(text: '${p?.port ?? 22}');
    _user = TextEditingController(text: p?.user ?? 'root');
    _useKey = p?.useKey ?? false;
  }

  @override
  void dispose() {
    _name.dispose();
    _host.dispose();
    _port.dispose();
    _user.dispose();
    _pass.dispose();
    _key.dispose();
    super.dispose();
  }

  RouterProfile _profile() {
    final host = _host.text.trim();
    return RouterProfile(
      id: _id,
      name: _name.text.trim().isEmpty ? host : _name.text.trim(),
      host: host,
      port: int.tryParse(_port.text.trim()) ?? 22,
      user: _user.text.trim(),
      useKey: _useKey,
    );
  }

  bool _validate() {
    if (_host.text.trim().isEmpty || _user.text.trim().isEmpty) {
      showMsg(context, S.hostUserRequired);
      return false;
    }
    if (!_useKey && widget.profile == null && _pass.text.isEmpty) {
      showMsg(context, S.passwordRequired);
      return false;
    }
    if (_useKey && widget.profile == null && _key.text.trim().isEmpty) {
      showMsg(context, S.keyRequired);
      return false;
    }
    return true;
  }

  Future<void> _test() async {
    if (!_validate()) return;
    setState(() {
      _testing = true;
      _testResult = null;
    });
    final s = context.read<AppState>();
    final p = _profile();
    final oldPw = await s.secret(p.id, 'pw');
    final oldKey = await s.secret(p.id, 'key');
    final sess = SshSession(
      profile: p,
      password: _pass.text.isNotEmpty ? _pass.text : oldPw,
      privateKey: _key.text.trim().isNotEmpty ? _key.text.trim() : oldKey,
      store: s.store,
    );
    String msg;
    bool ok = false;
    try {
      await sess.connect();
      final out = await sess.run('ubus call system board 2>/dev/null | head -n 12');
      final m = RegExp(r'"model":\s*"([^"]+)"').firstMatch(out);
      msg = m != null ? '${S.connectedTo} ${m.group(1)}' : S.connectedOk;
      ok = true;
    } catch (e) {
      msg = e.toString();
    }
    await sess.close();
    if (!mounted) return;
    setState(() {
      _testing = false;
      _testResult = msg;
      _testOk = ok;
    });
  }

  Future<void> _save() async {
    if (!_validate()) return;
    setState(() => _saving = true);
    final s = context.read<AppState>();
    final nav = Navigator.of(context);
    try {
      await s.saveProfile(
        _profile(),
        password: _pass.text.isNotEmpty ? _pass.text : null,
        key: _key.text.trim().isNotEmpty ? _key.text.trim() : null,
      );
      nav.pop();
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        showMsg(context, '${S.saveFailed}: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.profile != null;
    final t = context.watch<AppState>().theme;
    return SubPage(
      title: editing ? S.editRouter : S.addRouter,
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          TextField(
            controller: _name,
            decoration: const InputDecoration(labelText: S.fieldName),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _host,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(labelText: S.fieldHost),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _user,
                  decoration: const InputDecoration(labelText: S.fieldUser),
                ),
              ),
              const SizedBox(width: 12),
              SizedBox(
                width: 100,
                child: TextField(
                  controller: _port,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: S.fieldPort),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment<bool>(value: false, label: Text(S.authPassword)),
              ButtonSegment<bool>(value: true, label: Text(S.authKey)),
            ],
            selected: {_useKey},
            onSelectionChanged: (v) => setState(() => _useKey = v.first),
          ),
          const SizedBox(height: 12),
          if (!_useKey)
            TextField(
              controller: _pass,
              obscureText: _hide,
              decoration: InputDecoration(
                labelText: editing ? S.fieldPasswordKeep : S.fieldPassword,
                suffixIcon: IconButton(
                  icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _hide = !_hide),
                ),
              ),
            )
          else
            TextField(
              controller: _key,
              minLines: 5,
              maxLines: 8,
              style: const TextStyle(fontFamily: kMono, fontSize: 12),
              decoration: InputDecoration(
                labelText: editing ? S.fieldKeyKeep : S.fieldKey,
              ),
            ),
          const SizedBox(height: 8),
          Text(S.secretsNote, style: TextStyle(color: t.sub, fontSize: 12)),
          const SizedBox(height: 18),
          if (_testResult != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Tile(
                tint: _testOk ? kGood : kBad,
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Icon(_testOk ? Icons.check_circle_rounded : Icons.error_rounded,
                        color: _testOk ? kGood : kBad),
                    const SizedBox(width: 10),
                    Expanded(child: Text(_testResult!)),
                  ],
                ),
              ),
            ),
          OutlinedButton.icon(
            onPressed: _testing ? null : _test,
            icon: _testing
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.network_check_rounded),
            label: const Text(S.testConnection),
          ),
          const SizedBox(height: 10),
          FilledButton(
            onPressed: _saving ? null : _save,
            child: Text(_saving ? S.saving : S.save),
          ),
        ],
      ),
    );
  }
}
