import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../core/forms.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';
import 'apply_flow.dart';

String _encLabel(String e) {
  switch (e) {
    case 'psk2':
      return 'WPA2';
    case 'sae-mixed':
      return 'WPA2/WPA3';
    case 'sae':
      return 'WPA3';
    case 'psk-mixed':
      return 'WPA/WPA2';
    case 'owe':
      return 'OWE (open, encrypted)';
    case 'none':
      return 'Open';
    default:
      return e;
  }
}

Color _bandColor(String b) {
  switch (b) {
    case '5G':
      return const Color(0xFF4D8DFF);
    case '6G':
      return const Color(0xFF8B7CFF);
    default:
      return const Color(0xFF22C3EE);
  }
}

void showQr(BuildContext context, String ssid, String key, String enc, {bool hidden = false}) {
  final data = wifiQrPayload(ssid, key, enc, hidden: hidden);
  showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(ssid),
      content: SizedBox(
        width: 240,
        height: 240,
        child: QrImageView(
          data: data,
          backgroundColor: Colors.white,
          padding: const EdgeInsets.all(10),
        ),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text(S.close))],
    ),
  );
}

class WifiTab extends StatefulWidget {
  const WifiTab({super.key});

  @override
  State<WifiTab> createState() => _WifiTabState();
}

class _WifiTabState extends State<WifiTab> {
  WifiData? _data;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final d = await api.loadWifi();
      if (mounted) {
        setState(() {
          _data = d;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _stage(Future<void> Function(RouterApi a) f) async {
    await editConfig(context, f);
    if (mounted) _load();
  }

  // ------------------------------------------------------------ radios

  Future<void> _editRadio(RadioInfo r) async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    final chans = await api.loadChannels(r.name, r.band);
    if (!mounted) return;
    final pre = r.htmode.startsWith('EHT')
        ? 'EHT'
        : r.htmode.startsWith('HE')
            ? 'HE'
            : r.htmode.startsWith('VHT')
                ? 'VHT'
                : 'HT';
    final widths = r.band == '2.4G' || pre == 'HT' ? ['20', '40'] : ['20', '40', '80', '160'];
    final res = await showForm(
      context,
      '${S.radio} ${r.name} (${r.band})',
      [
        FPick('channel', S.channel, [
          ('auto', S.auto),
          for (final c in chans)
            if (!c.restricted)
              ('${c.channel}', '${c.channel}  (${c.mhz} MHz)${c.dfs ? '  DFS' : ''}'),
        ], initial: r.channel),
        FPick('htmode', S.width, [
          ('', S.auto),
          for (final w in widths) ('$pre$w', '$w MHz ($pre$w)'),
        ], initial: r.htmode),
        FText('txpower', S.txPower, initial: r.txpower, hint: S.txPowerHint, keyboard: TextInputType.number),
      ],
      ok: S.stage,
    );
    if (res == null || !mounted) return;
    await _stage((a) => a.stageRadio(
          r.name,
          channel: res.s('channel'),
          htmode: res.s('htmode'),
          txpower: res.s('txpower'),
        ));
  }

  Future<void> _country(WifiData d) async {
    final cur = d.radios.isEmpty ? '' : d.radios.first.country;
    final res = await showForm(
      context,
      S.country,
      [
        const FNote(S.countryNote),
        FPick('c', S.country, [for (final c in kCountries) (c.$1, '${c.$2} (${c.$1})')], initial: cur),
      ],
      ok: S.stage,
    );
    if (res == null || !mounted) return;
    await _stage((a) => a.stageCountryAll(res.s('c')));
  }

  // ------------------------------------------------------------- SSIDs

  Future<void> _addSsid(WifiData d) async {
    final res = await showForm(
      context,
      S.addNetwork,
      [
        FPick('radio', S.radio, [for (final r in d.radios) (r.name, '${r.name} (${r.band})')]),
        FText('ssid', S.ssid),
        FPick('enc', S.security, [for (final e in kEncryptions) (e, _encLabel(e))], initial: 'psk2'),
        FText('key', S.wifiPassword, obscure: true),
        const FSwitch('hidden', S.hiddenNetwork),
      ],
      ok: S.stage,
    );
    if (res == null || !mounted) return;
    if (res.s('ssid').isEmpty) return;
    if (res.s('enc') != 'none' && res.s('enc') != 'owe' && res.s('key').length < 8) {
      showMsg(context, S.passwordShort);
      return;
    }
    await _stage((a) => a.stageAddIface(
          radio: res.s('radio'),
          ssid: res.s('ssid'),
          encryption: res.s('enc'),
          key: res.s('key'),
          hidden: res.b('hidden'),
        ));
  }

  Future<void> _editSsid(WifiIface i) async {
    final res = await showForm(
      context,
      i.ssid,
      [
        FText('ssid', S.ssid, initial: i.ssid),
        FPick('enc', S.security, [for (final e in kEncryptions) (e, _encLabel(e))], initial: i.encryption),
        FText('key', S.wifiPasswordKeep, obscure: true),
        FSwitch('hidden', S.hiddenNetwork, initial: i.hidden),
        FSwitch('isolate', S.clientIsolation, initial: i.isolate),
      ],
      ok: S.stage,
    );
    if (res == null || !mounted) return;
    if (res.s('key').isNotEmpty && res.s('key').length < 8) {
      showMsg(context, S.passwordShort);
      return;
    }
    await _stage((a) => a.stageIface(
          i.section,
          ssid: res.s('ssid'),
          encryption: res.s('enc'),
          key: res.s('key'),
          hidden: res.b('hidden'),
          isolate: res.b('isolate'),
        ));
  }

  void _ssidSheet(WifiIface i) {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) {
        void run(VoidCallback f) {
          Navigator.pop(ctx);
          f();
        }

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(i.ssid, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
                InsetGroup(children: [
                  SettingRow(
                    icon: Icons.edit_rounded,
                    title: S.edit,
                    onTap: () => run(() => _editSsid(i)),
                  ),
                  SettingRow(
                    icon: Icons.qr_code_2_rounded,
                    title: S.showQr,
                    subtitle: i.key.isEmpty && i.encryption != 'none' ? S.qrNoKey : null,
                    onTap: () => run(() => showQr(context, i.ssid, i.key, i.encryption, hidden: i.hidden)),
                  ),
                  SettingRow(
                    icon: i.disabled ? Icons.wifi_rounded : Icons.wifi_off_rounded,
                    title: i.disabled ? S.enable : S.disable,
                    onTap: () => run(() => _stage((a) => a.stageIface(i.section, disabled: !i.disabled))),
                  ),
                  SettingRow(
                    icon: Icons.delete_rounded,
                    color: kBad,
                    title: S.delete,
                    onTap: () => run(() async {
                      final ok = await confirmDialog(context, S.delete, i.ssid);
                      if (ok && mounted) await _stage((a) => a.stageDeleteIface(i.section));
                    }),
                  ),
                ]),
              ],
            ),
          ),
        );
      },
    );
  }

  // --------------------------------------------------------- guest / IoT

  Future<void> _createGuest(WifiData d, String kind) async {
    final iot = kind == 'iot';
    final res = await showForm(
      context,
      iot ? S.createIot : S.createGuest,
      [
        FNote(iot ? S.iotNote : S.guestNote),
        FText('ssid', S.ssid, initial: iot ? 'Home-IoT' : 'Home-Guest'),
        FPick('enc', S.security, [for (final e in kEncryptions) (e, _encLabel(e))], initial: 'psk2'),
        FText('key', S.wifiPassword, obscure: true),
        for (final r in d.radios) FSwitch('r_${r.name}', '${r.name} (${r.band})', initial: iot ? r.band == '2.4G' : true),
      ],
      ok: S.stage,
    );
    if (res == null || !mounted) return;
    final radios = [for (final r in d.radios) if (res.b('r_${r.name}')) r.name];
    if (res.s('ssid').isEmpty) return;
    if (res.s('enc') != 'none' && res.s('key').length < 8) {
      showMsg(context, S.passwordShort);
      return;
    }
    await _stage((a) => a.stageCreateGuest(
          kind: kind,
          ssid: res.s('ssid'),
          encryption: res.s('enc'),
          key: res.s('key'),
          radios: radios,
        ));
  }

  Widget _guestTile(WifiData d, String kind) {
    final g = findGuest(d, kind);
    final iot = kind == 'iot';
    final title = iot ? S.iotWifi : S.guestWifi;
    final color = iot ? const Color(0xFFFF6B5B) : kWarm;
    if (!g.exists) {
      return Tile(
        onTap: () => _createGuest(d, kind),
        child: Row(
          children: [
            Icon(iot ? Icons.sensors_rounded : Icons.people_alt_rounded, color: color),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text(iot ? S.iotSub : S.guestSub, style: const TextStyle(fontSize: 12.5)),
                ],
              ),
            ),
            const Icon(Icons.add_circle_rounded),
          ],
        ),
      );
    }
    return Tile(
      tint: g.enabled ? color : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(iot ? Icons.sensors_rounded : Icons.people_alt_rounded, color: color),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                    Text(g.ssid, style: const TextStyle(fontSize: 12.5)),
                  ],
                ),
              ),
              Switch(value: g.enabled, onChanged: (v) => _stage((a) => a.stageGuestEnabled(g, v))),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              TextButton.icon(
                onPressed: () => showQr(context, g.ssid, g.key, g.encryption),
                icon: const Icon(Icons.qr_code_2_rounded),
                label: const Text(S.showQr),
              ),
              const Spacer(),
              TextButton(
                onPressed: () async {
                  final ok = await confirmDialog(context, S.removeNetwork, g.ssid);
                  if (ok && mounted) await _stage((a) => a.stageRemoveGuest(g));
                },
                child: const Text(S.delete, style: TextStyle(color: kBad)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // -------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    final d = _data;
    if (d == null) return _error != null ? ErrorBox(_error!, onRetry: _load) : const Loading();
    final main = [for (final i in d.ifaces) if (i.network != kGuestNet && i.network != kIotNet && i.mode == 'ap') i];
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 140),
        children: [
          const SectionTitle(S.radios),
          if (d.radios.isEmpty) const NotAvailable(S.noRadios),
          for (final r in d.radios)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Tile(
                onTap: () => _editRadio(r),
                child: Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: _bandColor(r.band).withAlpha(40),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(r.band,
                          style: TextStyle(color: _bandColor(r.band), fontWeight: FontWeight.w900, fontSize: 13)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(r.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 2),
                          Text(
                            [
                              '${S.channel} ${r.channel}',
                              if (r.htmode.isNotEmpty) r.htmode,
                              if (r.txpower.isNotEmpty) '${r.txpower} dBm',
                              if (r.country.isNotEmpty) r.country,
                            ].join('  •  '),
                            style: TextStyle(color: t.sub, fontSize: 12, fontFamily: kMono),
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: !r.disabled,
                      onChanged: (v) => _stage((a) => a.stageRadio(r.name, disabled: !v)),
                    ),
                  ],
                ),
              ),
            ),
          SectionTitle(S.networks, trailing: TextButton.icon(
            onPressed: d.radios.isEmpty ? null : () => _addSsid(d),
            icon: const Icon(Icons.add_rounded),
            label: const Text(S.add),
          )),
          if (main.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text(S.noNetworks)),
          for (final i in main)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Tile(
                padding: const EdgeInsets.all(14),
                onTap: () => _ssidSheet(i),
                child: Row(
                  children: [
                    Icon(i.disabled ? Icons.wifi_off_rounded : Icons.wifi_rounded,
                        color: i.disabled ? t.sub : _bandColor(d.bandOf(i.device))),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(i.ssid.isEmpty ? '—' : i.ssid,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                          Text('${_encLabel(i.encryption)}${i.hidden ? '  •  ${S.hiddenNetwork}' : ''}',
                              style: TextStyle(color: t.sub, fontSize: 12)),
                        ],
                      ),
                    ),
                    Pill(d.bandOf(i.device), _bandColor(d.bandOf(i.device))),
                  ],
                ),
              ),
            ),
          const SectionTitle(S.separateNetworks),
          _guestTile(d, 'guest'),
          const SizedBox(height: 10),
          _guestTile(d, 'iot'),
          const SectionTitle(S.wifiExtras),
          InsetGroup(children: [
            SettingRow(
              icon: Icons.public_rounded,
              title: S.country,
              subtitle: d.radios.isEmpty || d.radios.first.country.isEmpty ? S.countryUnset : d.radios.first.country,
              onTap: () => _country(d),
            ),
            SettingRow(
              icon: Icons.device_hub_rounded,
              title: S.meshRoaming,
              subtitle: S.meshRoamingSub,
              onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const MeshScreen())),
            ),
          ]),
        ],
      ),
    );
  }
}

// ======================================================================
// Mesh and roaming
// ======================================================================

class MeshScreen extends StatefulWidget {
  const MeshScreen({super.key});

  @override
  State<MeshScreen> createState() => _MeshScreenState();
}

class _MeshScreenState extends State<MeshScreen> {
  List<MeshPoint>? _mesh;
  RoamingState? _roam;
  List<String> _peers = const [];
  WifiData? _wifi;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final m = await api.loadMesh();
      final r = await api.loadRoaming();
      final p = await api.meshPeers();
      final w = await api.loadWifi();
      if (mounted) {
        setState(() {
          _mesh = m;
          _roam = r;
          _peers = p;
          _wifi = w;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _roaming() async {
    final r = _roam;
    if (r == null) return;
    final res = await showForm(
      context,
      S.roaming,
      [
        const FNote(S.roamingNote),
        FSwitch('r', S.fastRoaming, initial: r.fastRoaming),
        FSwitch('k', S.neighborReports, initial: r.neighborReports),
        FSwitch('v', S.bssTransition, initial: r.bssTransition),
        FText('md', S.mobilityDomain, initial: r.mobilityDomain.isEmpty ? '4f57' : r.mobilityDomain),
      ],
      ok: S.stage,
    );
    if (res == null || !mounted) return;
    await editConfig(context, (a) => a.stageRoaming(
          fast: res.b('r'),
          neighbor: res.b('k'),
          bss: res.b('v'),
          mobilityDomain: res.s('md'),
        ));
    if (mounted) _load();
  }

  Future<void> _join() async {
    final w = _wifi;
    if (w == null || w.radios.isEmpty) return;
    final res = await showForm(
      context,
      S.joinMesh,
      [
        const FNote(S.meshNote),
        FPick('radio', S.radio, [for (final r in w.radios) (r.name, '${r.name} (${r.band})')]),
        FText('id', S.meshId, initial: 'sharkmesh'),
        FText('key', S.wifiPassword, obscure: true),
      ],
      ok: S.stage,
    );
    if (res == null || !mounted) return;
    await editConfig(context, (a) => a.stageMeshPoint(radio: res.s('radio'), meshId: res.s('id'), key: res.s('key')));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    return SubPage(
      title: S.meshRoaming,
      body: _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : _mesh == null
              ? const Loading()
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
                  children: [
                    InsetGroup(title: S.roaming, children: [
                      SettingRow(
                        icon: Icons.swap_horiz_rounded,
                        title: S.roaming,
                        subtitle: (_roam?.fastRoaming ?? false) ? S.on : S.off,
                        onTap: _roaming,
                      ),
                    ]),
                    InsetGroup(title: S.meshNodes, children: [
                      for (final m in _mesh!)
                        SettingRow(
                          icon: Icons.hub_rounded,
                          title: m.meshId,
                          subtitle: m.radio,
                          trailing: TextButton(
                            onPressed: () async {
                              await editConfig(context, (a) => a.stageMeshLeave(m.section));
                              if (mounted) _load();
                            },
                            child: const Text(S.leave),
                          ),
                        ),
                      SettingRow(icon: Icons.add_link_rounded, title: S.joinMesh, onTap: _join),
                    ]),
                    if (_peers.isNotEmpty)
                      InsetGroup(title: S.meshPeers, children: [
                        for (final p in _peers)
                          SettingRow(
                            icon: Icons.sensors_rounded,
                            title: p,
                          ),
                      ]),
                    const Padding(
                      padding: EdgeInsets.only(top: 4),
                      child: Text(S.meshNeedsPkg, style: TextStyle(fontSize: 12.5)),
                    ),
                  ],
                ),
    );
  }
}
