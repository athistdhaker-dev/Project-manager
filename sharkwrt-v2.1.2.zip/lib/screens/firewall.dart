import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/forms.dart';
import '../core/strings.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';
import 'apply_flow.dart';

const List<(String, String)> _policies = [
  ('ACCEPT', 'Accept'),
  ('REJECT', 'Reject'),
  ('DROP', 'Drop'),
];

const List<(String, String)> _protos = [
  ('tcp udp', 'TCP + UDP'),
  ('tcp', 'TCP'),
  ('udp', 'UDP'),
  ('icmp', 'ICMP'),
  ('all', 'Any'),
];

class FirewallScreen extends StatefulWidget {
  const FirewallScreen({super.key});

  @override
  State<FirewallScreen> createState() => _FirewallScreenState();
}

class _FirewallScreenState extends State<FirewallScreen> {
  FwView? _fw;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final v = await api.loadFirewall();
      if (mounted) {
        setState(() {
          _fw = v;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _stage(Future<void> Function(RouterApi a) f) async {
    await editConfig(context, f);
    if (mounted) _load();
  }

  List<(String, String)> _zoneOptions(FwView v, {bool any = false}) => [
        if (any) ('', S.anyZone),
        for (final z in v.zones) (z.name, z.name),
      ];

  // ---------------------------------------------------------------- zones

  Future<void> _editZone(FwZone z) async {
    final r = await showForm(
      context,
      z.name,
      [
        FPick('in', S.zoneInput, _policies, initial: z.input),
        FPick('out', S.zoneOutput, _policies, initial: z.output),
        FPick('fwd', S.zoneForward, _policies, initial: z.forward),
        FSwitch('masq', S.masquerade, initial: z.masq),
        FSwitch('mtu', S.mtuFix, initial: z.mtuFix),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    await _stage((a) => a.stageZone(
          section: z.section,
          input: r.s('in'),
          output: r.s('out'),
          forward: r.s('fwd'),
          masq: r.b('masq'),
          mtuFix: r.b('mtu'),
        ));
  }

  // ------------------------------------------------------- port forwards

  Future<void> _editForward(FwView v, [FwRedirect? f]) async {
    final r = await showForm(
      context,
      f == null ? S.addForward : S.editForward,
      [
        FText('name', S.fieldName, initial: f?.name ?? ''),
        FPick('proto', S.protocol, _protos, initial: f?.proto ?? 'tcp udp'),
        FText('ext', S.externalPort, initial: f?.srcDport ?? '', keyboard: TextInputType.number),
        FText('ip', S.internalIp, initial: f?.destIp ?? '', keyboard: TextInputType.number),
        FText('int', S.internalPort, initial: f?.destPort ?? '', hint: S.sameAsExternal, keyboard: TextInputType.number),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    await _stage((a) => a.stagePortForward(
          section: f?.section ?? '',
          name: r.s('name').isEmpty ? 'Forward ${r.s('ext')}' : r.s('name'),
          proto: r.s('proto'),
          srcDport: r.s('ext'),
          destIp: r.s('ip'),
          destPort: r.s('int'),
        ));
  }

  Future<void> _dmz(FwRedirect? d) async {
    final r = await showForm(
      context,
      S.dmz,
      [
        const FNote(S.dmzNote),
        FSwitch('on', S.dmzEnable, initial: d != null),
        FText('ip', S.internalIp, initial: d?.destIp ?? '', keyboard: TextInputType.number),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    await _stage((a) => a.stageDmz(enabled: r.b('on'), ip: r.s('ip')));
  }

  // ---------------------------------------------------------------- rules

  Future<void> _editRule(FwView v, [FwRule? rule]) async {
    final r = await showForm(
      context,
      rule == null ? S.addRule : S.editRule,
      [
        FText('name', S.fieldName, initial: rule?.name ?? ''),
        FPick('src', S.fromZone, _zoneOptions(v, any: true), initial: rule?.src ?? ''),
        FPick('dest', S.toZone, [('', S.toDevice), ..._zoneOptions(v)], initial: rule?.dest ?? ''),
        FPick('proto', S.protocol, _protos, initial: rule?.proto.isEmpty ?? true ? 'tcp udp' : rule!.proto),
        FText('sip', S.sourceIp, initial: rule?.srcIp ?? '', hint: S.optional),
        FText('dip', S.destIp, initial: rule?.destIp ?? '', hint: S.optional),
        FText('port', S.destPort, initial: rule?.destPort ?? '', hint: S.optional),
        FPick('target', S.action, _policies, initial: rule?.target ?? 'ACCEPT'),
      ],
      ok: S.stage,
    );
    if (r == null || !mounted) return;
    if (r.s('name').isEmpty) {
      showMsg(context, S.nameRequired);
      return;
    }
    await _stage((a) => a.stageRule(
          section: rule?.section ?? '',
          name: r.s('name'),
          src: r.s('src'),
          dest: r.s('dest'),
          proto: r.s('proto'),
          srcIp: r.s('sip'),
          destIp: r.s('dip'),
          destPort: r.s('port'),
          target: r.s('target'),
        ));
  }

  Future<void> _delete(String section, String label) async {
    final ok = await confirmDialog(context, S.delete, label);
    if (ok && mounted) await _stage((a) => a.stageDeleteSection(section));
  }

  // ---------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    final v = _fw;
    return SubPage(
      title: S.firewall,
      body: _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : v == null
              ? const Loading()
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 60),
                  children: [
                    InsetGroup(title: S.protection, children: [
                      _switchRow(Icons.waves_rounded, S.synFlood, S.synFloodSub, v.defaults.synFlood,
                          (on) => _stage((a) => a.stageProtection(synFlood: on, dropInvalid: v.defaults.dropInvalid))),
                      _switchRow(Icons.rule_rounded, S.dropInvalid, S.dropInvalidSub, v.defaults.dropInvalid,
                          (on) => _stage((a) => a.stageProtection(synFlood: v.defaults.synFlood, dropInvalid: on))),
                      _switchRow(Icons.bolt_rounded, S.flowOffload, S.flowOffloadSub, v.defaults.flowOffload,
                          (on) => _stage((a) => a.stageFlowOffload(software: on, hardware: false))),
                    ]),
                    InsetGroup(title: S.zones, children: [
                      for (final z in v.zones)
                        SettingRow(
                          icon: Icons.layers_rounded,
                          title: z.name,
                          subtitle: 'in ${z.input} • out ${z.output} • fwd ${z.forward}${z.masq ? ' • NAT' : ''}',
                          onTap: () => _editZone(z),
                        ),
                    ]),
                    SectionTitle(S.portForwards,
                        trailing: TextButton.icon(
                          onPressed: () => _editForward(v),
                          icon: const Icon(Icons.add_rounded),
                          label: const Text(S.add),
                        )),
                    _dmzTile(v),
                    const SizedBox(height: 8),
                    for (final f in v.redirects.where((e) => !e.isDmz))
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Tile(
                          padding: const EdgeInsets.fromLTRB(14, 10, 6, 10),
                          onTap: () => _editForward(v, f),
                          onLongPress: () => _delete(f.section, f.name),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(f.name.isEmpty ? f.section : f.name,
                                        style: const TextStyle(fontWeight: FontWeight.w800)),
                                    Text(
                                      '${f.proto} ${f.srcDport} → ${f.destIp}${f.destPort.isEmpty ? '' : ':${f.destPort}'}',
                                      style: TextStyle(color: t.sub, fontSize: 12, fontFamily: kMono),
                                    ),
                                  ],
                                ),
                              ),
                              Switch(
                                value: f.enabled,
                                onChanged: (on) => _stage((a) => a.stageSectionEnabled(f.section, on)),
                              ),
                            ],
                          ),
                        ),
                      ),
                    SectionTitle(S.rules,
                        trailing: TextButton.icon(
                          onPressed: () => _editRule(v),
                          icon: const Icon(Icons.add_rounded),
                          label: const Text(S.add),
                        )),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Text(S.rulesHint, style: TextStyle(color: t.sub, fontSize: 12)),
                    ),
                    for (final r in v.rules)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Tile(
                          padding: const EdgeInsets.fromLTRB(14, 10, 6, 10),
                          onTap: () => _editRule(v, r),
                          onLongPress: () => _delete(r.section, r.name),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(r.name.isEmpty ? r.section : r.name,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(fontWeight: FontWeight.w800)),
                                    const SizedBox(height: 2),
                                    Text(
                                      '${r.src.isEmpty ? '*' : r.src} → ${r.dest.isEmpty ? S.toDevice : r.dest}'
                                      '  ${r.proto}${r.destPort.isEmpty ? '' : ':${r.destPort}'}',
                                      style: TextStyle(color: t.sub, fontSize: 12, fontFamily: kMono),
                                    ),
                                  ],
                                ),
                              ),
                              Pill(r.target, r.target == 'ACCEPT' ? kGood : kBad),
                              Switch(
                                value: r.enabled,
                                onChanged: (on) => _stage((a) => a.stageSectionEnabled(r.section, on)),
                              ),
                            ],
                          ),
                        ),
                      ),
                    const SizedBox(height: 6),
                    Text(S.longPressDelete, style: TextStyle(color: t.sub, fontSize: 12)),
                  ],
                ),
    );
  }

  Widget _dmzTile(FwView v) {
    FwRedirect? d;
    for (final e in v.redirects) {
      if (e.isDmz) d = e;
    }
    return Tile(
      tint: d != null ? kWarm : null,
      padding: const EdgeInsets.all(14),
      onTap: () => _dmz(d),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: kWarm),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(S.dmz, style: TextStyle(fontWeight: FontWeight.w800)),
                Text(d == null ? S.off : d.destIp, style: const TextStyle(fontSize: 12.5)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded),
        ],
      ),
    );
  }

  Widget _switchRow(IconData icon, String title, String sub, bool value, ValueChanged<bool> on) {
    return SettingRow(
      icon: icon,
      title: title,
      subtitle: sub,
      trailing: Switch(value: value, onChanged: on),
      onTap: () => on(!value),
    );
  }
}
