import 'package:flutter/material.dart';

import '../core/strings.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../data/router_api.dart';
import '../data/snippets.dart';
import '../data/ssh.dart';
import '../data/store.dart';
import '../data/term_manager.dart';

int _clampInt(int v, int max) => v < 0 ? 0 : (v > max ? max : v);

class AppState extends ChangeNotifier {
  final Store store = Store();
  final GlobalKey<NavigatorState> navKey = GlobalKey<NavigatorState>();

  List<RouterProfile> profiles = [];
  int themeIndex = 0;
  int accentIndex = 0;
  bool blur = true;

  // terminal settings
  double termFont = 13;
  double termLineHeight = 1.25;
  int termScheme = 0;
  bool termConfirm = true;
  String termStartup = '';
  List<Snippet> userSnippets = [];

  RouterProfile? active;
  SshSession? session;
  RouterApi? api;
  RouterInfo info = RouterInfo();
  TermManager? term;
  int pendingCount = 0;
  bool bioLock = false;
  Map<String, String> _aliases = {};

  SharkTheme get theme => kThemes[_clampInt(themeIndex, kThemes.length - 1)];
  Color get accent => kAccents[_clampInt(accentIndex, kAccents.length - 1)];

  Future<void> init() async {
    await store.init();
    final p = store.prefs;
    T pick<T>(T def, T? Function() read) {
      try {
        return read() ?? def;
      } catch (_) {
        return def; // wrong stored type: fall back to the default
      }
    }

    try {
      profiles = store.loadProfiles();
    } catch (_) {
      profiles = [];
    }
    themeIndex = pick(0, () => p.getInt('theme'));
    accentIndex = pick(0, () => p.getInt('accent'));
    blur = pick(true, () => p.getBool('blur'));
    bioLock = pick(false, () => p.getBool('bio_lock'));
    termFont = pick(13.0, () => p.getDouble('term_font'));
    termLineHeight = pick(1.25, () => p.getDouble('term_lh'));
    termScheme = pick(0, () => p.getInt('term_scheme'));
    termConfirm = pick(true, () => p.getBool('term_confirm'));
    termStartup = pick('', () => p.getString('term_startup'));
    try {
      userSnippets = decodeSnippets(store.snippetsRaw());
    } catch (_) {
      userSnippets = [];
    }
  }

  Future<void> setTheme(int i) async {
    themeIndex = i;
    await store.prefs.setInt('theme', i);
    notifyListeners();
  }

  Future<void> setAccent(int i) async {
    accentIndex = i;
    await store.prefs.setInt('accent', i);
    notifyListeners();
  }

  Future<void> setBioLock(bool v) async {
    bioLock = v;
    await store.prefs.setBool('bio_lock', v);
    notifyListeners();
  }

  RouterEnv get env => api?.env ?? RouterEnv();

  /// Re-reads how many changes are staged on the router (drives the banner).
  Future<void> refreshPending() async {
    final a = api;
    if (a == null) return;
    try {
      pendingCount = await a.pendingCount();
    } catch (_) {}
    notifyListeners();
  }

  Future<void> setBlur(bool v) async {
    blur = v;
    await store.prefs.setBool('blur', v);
    notifyListeners();
  }

  // ------------------------------------------------------ terminal settings

  Future<void> setTermFont(double v) async {
    termFont = v.clamp(8.0, 28.0).toDouble();
    await store.prefs.setDouble('term_font', termFont);
    notifyListeners();
  }

  Future<void> setTermLineHeight(double v) async {
    termLineHeight = v.clamp(1.0, 1.8).toDouble();
    await store.prefs.setDouble('term_lh', termLineHeight);
    notifyListeners();
  }

  Future<void> setTermScheme(int i) async {
    termScheme = i;
    await store.prefs.setInt('term_scheme', i);
    notifyListeners();
  }

  Future<void> setTermConfirm(bool v) async {
    termConfirm = v;
    await store.prefs.setBool('term_confirm', v);
    notifyListeners();
  }

  Future<void> setTermStartup(String v) async {
    termStartup = v;
    await store.prefs.setString('term_startup', v);
    notifyListeners();
  }

  Future<void> saveSnippet(Snippet s) async {
    final i = userSnippets.indexWhere((e) => e.id == s.id);
    if (i >= 0) {
      userSnippets[i] = s;
    } else {
      userSnippets.add(s);
    }
    await store.saveSnippetsRaw(encodeSnippets(userSnippets));
    notifyListeners();
  }

  Future<void> deleteSnippet(String id) async {
    userSnippets.removeWhere((e) => e.id == id);
    await store.saveSnippetsRaw(encodeSnippets(userSnippets));
    notifyListeners();
  }

  List<String> history() => store.history();
  Future<void> clearHistory() async {
    await store.clearHistory();
    notifyListeners();
  }

  Future<bool> _confirmDanger(String cmd) async {
    final ctx = navKey.currentContext;
    if (ctx == null) return true;
    final r = await showDialog<bool>(
      context: ctx,
      builder: (c) => AlertDialog(
        title: const Text(S.termDangerTitle),
        content: Text(cmd, style: const TextStyle(fontFamily: 'DejaVuSansMono')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text(S.cancel)),
          FilledButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('Run')),
        ],
      ),
    );
    return r ?? false;
  }

  // ------------------------------------------------------------ profiles

  Future<void> saveProfile(RouterProfile p,
      {String? password, String? key}) async {
    final i = profiles.indexWhere((e) => e.id == p.id);
    if (i >= 0) {
      profiles[i] = p;
    } else {
      profiles.add(p);
    }
    await store.saveProfiles(profiles);
    if (password != null) await store.setSecret(p.id, 'pw', password);
    if (key != null) await store.setSecret(p.id, 'key', key);
    notifyListeners();
  }

  Future<void> deleteProfile(String id) async {
    profiles.removeWhere((e) => e.id == id);
    await store.saveProfiles(profiles);
    await store.deleteSecrets(id);
    await store.clearFingerprint(id);
    notifyListeners();
  }

  Future<void> resetHostKey(String id) => store.clearFingerprint(id);

  Future<String?> secret(String id, String kind) => store.secret(id, kind);

  // ---------------------------------------------------------- connection

  /// Returns an error message, or null on success.
  Future<String?> connect(RouterProfile p) async {
    final pw = await store.secret(p.id, 'pw');
    final key = await store.secret(p.id, 'key');
    final s = SshSession(profile: p, password: pw, privateKey: key, store: store);
    try {
      await s.connect();
      final a = RouterApi(s);
      RouterInfo i;
      try {
        i = await a.loadInfo();
      } catch (_) {
        i = RouterInfo();
      }
      try {
        await a.detectEnv();
      } catch (_) {}
      session = s;
      api = a;
      pendingCount = 0;
      info = i;
      active = p;
      _aliases = store.aliases(p.id);
      term = TermManager(
        ssh: s,
        onCommand: (c) => store.addHistory(c),
        confirmDanger: _confirmDanger,
        wantConfirm: () => termConfirm,
        startupCommand: () => termStartup,
      );
      notifyListeners();
      refreshPending();
      return null;
    } catch (e) {
      await s.close();
      return e.toString();
    }
  }

  void disconnect() {
    final t = term;
    term = null;
    if (t != null) {
      t.closeAll().then((_) => t.dispose());
    }
    session?.close();
    session = null;
    api = null;
    pendingCount = 0;
    active = null;
    info = RouterInfo();
    notifyListeners();
  }

  // ------------------------------------------------------------- aliases

  String? alias(String mac) => _aliases[mac.toLowerCase()];

  Future<void> setAlias(String mac, String name) async {
    final p = active;
    if (p == null) return;
    if (name.isEmpty) {
      _aliases.remove(mac.toLowerCase());
    } else {
      _aliases[mac.toLowerCase()] = name;
    }
    await store.saveAliases(p.id, _aliases);
    notifyListeners();
  }
}
