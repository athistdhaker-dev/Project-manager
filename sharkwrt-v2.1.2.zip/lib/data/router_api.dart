import '../core/strings.dart';
import '../core/uci.dart';
import 'api_models.dart';
import 'api_util.dart';
import 'ssh.dart';

export 'api_clients.dart';
export 'api_config.dart';
export 'api_fw.dart';
export 'api_mesh.dart';
export 'api_models.dart';
export 'api_net.dart';
export 'api_sys.dart';
export 'api_wifi.dart';

/// Single entry point for everything that talks to the router. The UI never calls
/// ssh.run directly; feature code lives in the api_*.dart extensions.
class RouterApi {
  final SshSession ssh;
  RouterApi(this.ssh);

  RouterEnv env = RouterEnv();
  String wanDev = '';
  int? _pTotal;
  int? _pIdle;

  Future<String> run(String cmd,
          {Duration timeout = const Duration(seconds: 25)}) =>
      ssh.run(cmd, timeout: timeout);

  // ---------------------------------------------------------- environment

  static const String _envCmd =
      r'''ubus call system board 2>/dev/null; echo '@@TOOLS'; for c in fw4 fw3 opkg apk swconfig iwinfo vnstat vnstati nlbwmon etherwake wol speedtest ookla conntrack curl wget uclient-fetch sysupgrade tc ethtool traceroute nslookup ip; do command -v $c >/dev/null 2>&1 && echo "T $c"; done; echo '@@REL'; cat /etc/openwrt_release 2>/dev/null; true''';

  Future<RouterEnv> detectEnv() async {
    final out = await ssh.run(_envCmd);
    final e = RouterEnv();
    final board = tryJson(out.split('@@TOOLS').first);
    if (board != null) {
      e.board = '${board['board_name'] ?? ''}';
      final r = board['release'];
      if (r is Map) {
        e.release = '${r['description'] ?? ''}';
        e.version = '${r['version'] ?? ''}';
      }
    }
    for (final l in section(out, 'TOOLS').split('\n')) {
      final t = l.trim();
      if (t.startsWith('T ')) e.tools.add(t.substring(2).trim());
    }
    final rel = section(out, 'REL');
    if (e.version.isEmpty) {
      final m = RegExp(r"DISTRIB_RELEASE='?([^'\n]+)").firstMatch(rel);
      if (m != null) e.version = m.group(1)!;
    }
    e.fw4 = e.has('fw4');
    e.swconfig = e.has('swconfig');
    e.pkg = e.has('apk') ? 'apk' : (e.has('opkg') ? 'opkg' : '');
    env = e;
    return e;
  }

  // ------------------------------------------------------------------ info

  Future<RouterInfo> loadInfo() async {
    final out = await ssh.run(
        r'''ubus call system board 2>/dev/null; echo '@@'; ubus call network.interface.wan status 2>/dev/null''');
    final parts = out.split('@@');
    final b = tryJson(parts[0]);
    final w = parts.length > 1 ? tryJson(parts[1]) : null;
    final info = RouterInfo();
    if (b != null) {
      info.model = '${b['model'] ?? ''}';
      info.hostname = '${b['hostname'] ?? ''}';
      info.board = '${b['board_name'] ?? ''}';
      final r = b['release'];
      if (r is Map) info.release = '${r['description'] ?? ''}';
    }
    if (w != null) {
      info.wanDev = '${w['l3_device'] ?? w['device'] ?? ''}';
      info.wanProto = '${w['proto'] ?? ''}';
      final a = w['ipv4-address'];
      if (a is List && a.isNotEmpty && a.first is Map) {
        info.wanIp = '${(a.first as Map)['address'] ?? ''}';
      }
      final rt = w['route'];
      if (rt is List) {
        for (final r in rt) {
          if (r is Map && '${r['target']}' == '0.0.0.0') {
            info.wanGateway = '${r['nexthop'] ?? ''}';
            break;
          }
        }
      }
      final d = w['dns-server'];
      if (d is List) info.dns = d.join(', ');
      info.wanUp = w['up'] == true;
    }
    wanDev = info.wanDev;
    return info;
  }

  // ----------------------------------------------------------------- stats

  static const String _statsCmd =
      r'''cat /proc/loadavg; echo '@@'; head -n1 /proc/stat; echo '@@'; grep -E '^(MemTotal|MemAvailable|MemFree|Buffers|Cached):' /proc/meminfo; echo '@@'; cat /proc/uptime; echo '@@'; (df -k /overlay 2>/dev/null || df -k /) | tail -n1; echo '@@'; cat /proc/net/dev; echo '@@'; cat /sys/class/thermal/thermal_zone*/temp 2>/dev/null | head -n1''';

  Future<Stats> loadStats() async {
    final out = await ssh.run(_statsCmd);
    final st = parseStats(out, _pTotal, _pIdle);
    _pTotal = st.$2;
    _pIdle = st.$3;
    return st.$1;
  }

  // --------------------------------------------------------------- actions

  Future<void> reboot() => ssh.run('(sleep 1; reboot) >/dev/null 2>&1 &');

  Future<void> restartWifi() => ssh.run('(wifi reload >/dev/null 2>&1 &)');

  Future<void> restartNetwork() =>
      ssh.run('(/etc/init.d/network restart >/dev/null 2>&1 &)');

  /// Terminal-style one-off command (used by diagnostics, not by the UI directly).
  Future<String> exec(String cmd) => ssh.run('sh -c ${shq(cmd)} 2>&1',
      timeout: const Duration(seconds: 40));
}

/// Pure parser so it can be unit-tested with sample output.
/// Returns (stats, cpuTotal, cpuIdle) so the caller can keep the previous CPU sample.
(Stats, int?, int?) parseStats(String out, int? prevTotal, int? prevIdle) {
  final parts = out.split('@@');
  if (parts.length < 6) throw SshException(S.statsParseFailed);
  final st = Stats();
  st.load = double.tryParse(parts[0].trim().split(' ').first) ?? 0;

  int? total;
  int? idle;
  final cl = parts[1].trim().split(RegExp(r'\s+'));
  if (cl.length > 5 && cl[0] == 'cpu') {
    final v = cl.sublist(1).map((e) => int.tryParse(e) ?? 0).toList();
    total = v.take(8).fold<int>(0, (a, b) => a + b);
    idle = v[3] + (v.length > 4 ? v[4] : 0);
    if (prevTotal != null && prevIdle != null) {
      final dt = total - prevTotal;
      final di = idle - prevIdle;
      if (dt > 0) st.cpu = ((dt - di) * 100 / dt).clamp(0, 100).toDouble();
    }
  }

  final mem = <String, int>{};
  for (final l in parts[2].split('\n')) {
    final m = RegExp(r'^(\w+):\s+(\d+)').firstMatch(l.trim());
    if (m != null) mem[m.group(1)!] = int.parse(m.group(2)!);
  }
  st.memTotal = mem['MemTotal'] ?? 0;
  final avail = mem['MemAvailable'] ??
      ((mem['MemFree'] ?? 0) + (mem['Buffers'] ?? 0) + (mem['Cached'] ?? 0));
  st.memUsed = st.memTotal - avail;

  st.uptime = double.tryParse(parts[3].trim().split(' ').first) ?? 0;

  final df = parts[4].trim().split(RegExp(r'\s+'));
  if (df.length >= 4) {
    st.flashTotal = int.tryParse(df[1]) ?? 0;
    st.flashUsed = int.tryParse(df[2]) ?? 0;
  }

  for (final l in parts[5].split('\n')) {
    final i = l.indexOf(':');
    if (i < 0) continue;
    final dev = l.substring(0, i).trim();
    final c = l.substring(i + 1).trim().split(RegExp(r'\s+'));
    if (c.length >= 9) {
      st.net[dev] = [int.tryParse(c[0]) ?? 0, int.tryParse(c[8]) ?? 0];
    }
  }
  if (parts.length > 6) {
    final raw = double.tryParse(parts[6].trim());
    if (raw != null && raw > 0) st.tempC = raw > 1000 ? raw / 1000 : raw;
  }
  st.at = DateTime.now();
  return (st, total, idle);
}
