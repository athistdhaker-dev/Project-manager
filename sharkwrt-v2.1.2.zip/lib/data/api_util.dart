import 'dart:convert';

import '../core/strings.dart';
import '../core/uci.dart';
import 'ssh.dart';

/// Validation helpers: anything that ends up inside a shell command goes through
/// one of these (or through shq) first.

String needName(String s) {
  if (!isSafeName(s)) throw SshException(S.badName);
  return s;
}

String needMac(String s) {
  if (!isMac(s)) throw SshException(S.badMac);
  return s.toLowerCase();
}

String needIp(String s) {
  if (!isIpv4(s)) throw SshException(S.badIp);
  return s;
}

String needInt(String s) {
  if (!RegExp(r'^\d{1,9}$').hasMatch(s)) throw SshException(S.badNumber);
  return s;
}

String needPort(String s) {
  if (!RegExp(r'^\d{1,5}(-\d{1,5})?$').hasMatch(s)) throw SshException(S.badPort);
  return s;
}

String needProto(String s) {
  if (!const ['tcp', 'udp', 'tcp udp', 'icmp', 'all'].contains(s)) {
    throw SshException(S.badProto);
  }
  return s;
}

String needDns(String s) {
  if (!RegExp(r'^[0-9a-fA-F:.]+$').hasMatch(s)) throw SshException(S.badIp);
  return s;
}

String needToken(String s) {
  if (!RegExp(r'^[A-Za-z0-9_.\-:@/]+$').hasMatch(s)) throw SshException(S.badName);
  return s;
}

Map<String, dynamic>? tryJson(String s) {
  try {
    final v = jsonDecode(s.trim());
    if (v is Map) return Map<String, dynamic>.from(v);
  } catch (_) {}
  return null;
}

/// Returns the text between "@@NAME" and the next "@@" marker.
String section(String out, String name) {
  final i = out.indexOf('@@$name');
  if (i < 0) return '';
  final start = out.indexOf('\n', i);
  if (start < 0) return '';
  final next = out.indexOf('@@', start);
  return out.substring(start + 1, next < 0 ? out.length : next);
}

// ---------------------------------------------------------------- uci builders
// Every builder returns a complete shell fragment with its own quoting.

String uciSet(String path, String value) => 'uci set ${shq('$path=$value')}';

/// Creates a named section: uci set pkg.name=type
String uciNew(String pkg, String name, String type) =>
    'uci set ${shq('$pkg.$name=$type')}';

String uciAddList(String path, String value) =>
    'uci add_list ${shq('$path=$value')}';

/// Delete that does not fail when the option or section is already gone.
String uciDel(String path) => '(uci -q delete ${shq(path)}; true)';

String uciBool(String path, bool v) => uciSet(path, v ? '1' : '0');

/// Runs the fragments as one `&&` chain and checks for the success marker, because
/// the SSH channel does not hand back the exit status.
Future<String> runChain(
  Future<String> Function(String cmd) run,
  List<String> cmds,
) async {
  if (cmds.isEmpty) return '';
  final out = await run('${cmds.join(' && ')} && echo @@OK');
  if (!out.contains('@@OK')) {
    final msg = out.trim();
    throw SshException(msg.isEmpty ? S.commandFailed : msg);
  }
  return out.replaceAll('@@OK', '').trim();
}
