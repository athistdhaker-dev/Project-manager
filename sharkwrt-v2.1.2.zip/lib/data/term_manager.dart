import 'package:flutter/foundation.dart';

import 'ssh.dart';
import 'term_tab.dart';

/// The terminal tabs for the connected router. Lives in AppState (not in the screen),
/// so shells keep running while the user browses other screens.
class TermManager extends ChangeNotifier {
  TermManager({
    required this.ssh,
    required this.onCommand,
    required this.confirmDanger,
    required this.wantConfirm,
    required this.startupCommand,
  });

  final SshSession ssh;
  final void Function(String cmd) onCommand;
  final Future<bool> Function(String cmd) confirmDanger;
  final bool Function() wantConfirm;
  final String Function() startupCommand;

  final List<TermTab> tabs = [];
  int selected = 0;
  int _seq = 1;

  TermTab? get current =>
      (selected >= 0 && selected < tabs.length) ? tabs[selected] : null;

  void ensureOne() {
    if (tabs.isEmpty) open();
  }

  TermTab open() {
    final t = TermTab(
      id: _seq,
      title: 'Shell $_seq',
      ssh: ssh,
      onCommand: onCommand,
      confirmDanger: confirmDanger,
      wantConfirm: wantConfirm,
      startupCommand: startupCommand,
    );
    _seq++;
    tabs.add(t);
    selected = tabs.length - 1;
    notifyListeners();
    t.start();
    return t;
  }

  void select(int i) {
    if (i < 0 || i >= tabs.length) return;
    selected = i;
    notifyListeners();
  }

  void rename(int i, String name) {
    if (i < 0 || i >= tabs.length || name.trim().isEmpty) return;
    tabs[i].title = name.trim();
    notifyListeners();
  }

  Future<void> closeTab(int i) async {
    if (i < 0 || i >= tabs.length) return;
    final t = tabs.removeAt(i);
    await t.close();
    t.dispose();
    if (tabs.isEmpty) {
      selected = 0;
      open();
      return;
    }
    if (selected >= tabs.length) selected = tabs.length - 1;
    notifyListeners();
  }

  Future<void> closeAll() async {
    final all = List<TermTab>.from(tabs);
    tabs.clear();
    for (final t in all) {
      await t.close();
      t.dispose();
    }
  }
}
