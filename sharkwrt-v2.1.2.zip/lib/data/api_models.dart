import '../core/uci.dart';

class RouterInfo {
  String model = '';
  String release = '';
  String hostname = '';
  String board = '';
  String wanDev = '';
  String wanProto = '';
  String wanIp = '';
  String wanGateway = '';
  String dns = '';
  bool wanUp = false;
}

/// What the router can do, detected once after connecting.
class RouterEnv {
  String release = '';
  String version = '';
  String board = '';
  bool fw4 = true;
  String pkg = ''; // 'opkg', 'apk' or '' when neither exists
  bool swconfig = false;
  final Set<String> tools = <String>{};
  bool has(String t) => tools.contains(t);
  bool get isDsa => !swconfig;
  bool get detected => release.isNotEmpty || board.isNotEmpty;
}

class Stats {
  double cpu = 0;
  double load = 0;
  int memTotal = 0; // kB
  int memUsed = 0; // kB
  int flashTotal = 0; // kB
  int flashUsed = 0; // kB
  double uptime = 0; // seconds
  double? tempC;
  final Map<String, List<int>> net = {}; // dev -> [rx, tx]
  DateTime at = DateTime.now();
}

class RadioInfo {
  final String name;
  final String band;
  final String channel;
  final String htmode;
  final String country;
  final String txpower;
  final bool disabled;
  RadioInfo(this.name, this.band, this.channel, this.htmode, this.disabled,
      {this.country = '', this.txpower = ''});
}

class WifiIface {
  final String section;
  final String device;
  final String ssid;
  final String encryption;
  final String key;
  final String mode;
  final String network;
  final bool disabled;
  final bool hidden;
  final bool isolate;
  WifiIface(
    this.section,
    this.device,
    this.ssid,
    this.encryption,
    this.key,
    this.mode,
    this.disabled, {
    this.network = '',
    this.hidden = false,
    this.isolate = false,
  });
}

class WifiData {
  final List<RadioInfo> radios;
  final List<WifiIface> ifaces;
  WifiData(this.radios, this.ifaces);
  String bandOf(String radio) {
    for (final r in radios) {
      if (r.name == radio) return r.band;
    }
    return '?';
  }
}

class NetClient {
  final String mac;
  String ip;
  String hostname;
  String band; // 5G, 2.4G, 6G, LAN
  String ssid;
  String network; // lan, guest, iot ... (from the bridge/interface it sits on)
  int? signal;
  NetClient(this.mac, this.ip, this.hostname, this.band, this.signal,
      {this.ssid = '', this.network = 'lan'});
}

class ClientsData {
  final List<NetClient> clients;
  final Map<String, String> blocked; // mac -> name
  final Map<String, String> reserved; // mac -> reserved ip
  ClientsData(this.clients, this.blocked, [this.reserved = const {}]);
}

class NetworkData {
  final UciConfig network;
  final UciConfig dhcp;
  NetworkData(this.network, this.dhcp);
}

class FirewallData {
  final UciConfig cfg;
  FirewallData(this.cfg);
}

class ServiceItem {
  final String name;
  final bool enabled;
  final bool running;
  ServiceItem(this.name, this.enabled, [this.running = false]);
}

/// One line from `uci changes`.
class PendingChange {
  final String pkg;
  final String path; // pkg.section[.option]
  final String op; // set, add, del, list-add, list-del
  final String value;
  const PendingChange(this.pkg, this.path, this.op, this.value);
}

class ApplyResult {
  final List<String> packages;
  final bool guarded;
  final int guardSeconds;
  final DateTime startedAt;
  ApplyResult(this.packages, this.guarded, this.guardSeconds, this.startedAt);
}

class UsagePoint {
  final String label; // day or month
  final int rx; // bytes
  final int tx; // bytes
  const UsagePoint(this.label, this.rx, this.tx);
}

class UsageData {
  final String iface;
  final List<UsagePoint> days;
  final List<UsagePoint> months;
  const UsageData(this.iface, this.days, this.months);
}

class SpeedResult {
  double? pingMs;
  double? jitterMs;
  double? lossPct;
  double? downMbps;
  double? upMbps;
  String source = '';
}

class PackageItem {
  final String name;
  final String version;
  final String desc;
  final bool installed;
  final bool upgradable;
  const PackageItem(this.name, this.version,
      {this.desc = '', this.installed = false, this.upgradable = false});
}

class LedItem {
  final String name; // e.g. green:wan
  final String trigger;
  final int brightness;
  final int maxBrightness;
  final List<String> triggers;
  const LedItem(this.name, this.trigger, this.brightness, this.maxBrightness,
      this.triggers);
}

class RouteItem {
  final String section;
  final String iface;
  final String target;
  final String netmask;
  final String gateway;
  final String metric;
  const RouteItem(this.section, this.iface, this.target, this.netmask,
      this.gateway, this.metric);
}
