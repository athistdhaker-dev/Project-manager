import 'dart:convert';
import 'dart:typed_data';

import '../core/strings.dart';
import '../core/uci.dart';
import 'api_models.dart';
import 'api_util.dart';
import 'router_api.dart';
import 'ssh.dart';

/// Common time zones: label -> (zonename, POSIX tz string).
const List<(String, String, String)> kTimezones = [
  ('UTC', 'UTC', 'UTC0'),
  ('India (IST)', 'Asia/Kolkata', 'IST-5:30'),
  ('Dubai', 'Asia/Dubai', '<+04>-4'),
  ('Karachi', 'Asia/Karachi', 'PKT-5'),
  ('Dhaka', 'Asia/Dhaka', '<+06>-6'),
  ('Bangkok', 'Asia/Bangkok', '<+07>-7'),
  ('Singapore', 'Asia/Singapore', '<+08>-8'),
  ('Tokyo', 'Asia/Tokyo', 'JST-9'),
  ('Sydney', 'Australia/Sydney', 'AEST-10AEDT,M10.1.0,M4.1.0/3'),
  ('London', 'Europe/London', 'GMT0BST,M3.5.0/1,M10.5.0'),
  ('Berlin / Paris', 'Europe/Berlin', 'CET-1CEST,M3.5.0,M10.5.0/3'),
  ('Moscow', 'Europe/Moscow', 'MSK-3'),
  ('New York', 'America/New_York', 'EST5EDT,M3.2.0,M11.1.0'),
  ('Chicago', 'America/Chicago', 'CST6CDT,M3.2.0,M11.1.0'),
  ('Los Angeles', 'America/Los_Angeles', 'PST8PDT,M3.2.0,M11.1.0'),
];

class SystemCfg {
  final String hostname;
  final String timezone;
  final String zonename;
  final bool ntpEnabled;
  final List<String> ntpServers;
  const SystemCfg(this.hostname, this.timezone, this.zonename, this.ntpEnabled,
      this.ntpServers);
}

class AuthKey {
  final int line; // 1-based line in authorized_keys
  final String type;
  final String comment;
  final String preview;
  const AuthKey(this.line, this.type, this.comment, this.preview);
}

SystemCfg parseSystemCfg(String out) {
  final cfg = parseUciShow(out);
  UciSection? sys;
  for (final s in cfg.ofType('system')) {
    sys = s;
    break;
  }
  UciSection? ntp;
  for (final s in cfg.ofType('timeserver')) {
    ntp = s;
    break;
  }
  final servers = (ntp?.o('server') ?? '')
      .split(' ')
      .where((e) => e.isNotEmpty)
      .toList();
  return SystemCfg(
    sys?.o('hostname') ?? '',
    sys?.o('timezone') ?? 'UTC0',
    sys?.o('zonename') ?? '',
    ntp == null ? true : ntp.o('enabled') != '0',
    servers,
  );
}

List<ServiceItem> parseServices(String out) {
  final res = <ServiceItem>[];
  for (final l in out.split('\n')) {
    final f = l.trim().split(RegExp(r'\s+'));
    if (f.length != 3) continue;
    res.add(ServiceItem(f[0], f[1] == '1', f[2] == '1'));
  }
  res.sort((a, b) => a.name.compareTo(b.name));
  return res;
}

/// opkg: "name - version [- description]"
List<PackageItem> parseOpkgList(String out, {bool installed = false}) {
  final res = <PackageItem>[];
  for (final l in out.split('\n')) {
    final p = l.split(' - ');
    if (p.length < 2) continue;
    final name = p[0].trim();
    if (name.isEmpty || name.contains(' ')) continue;
    res.add(PackageItem(name, p[1].trim(),
        desc: p.length > 2 ? p.sublist(2).join(' - ').trim() : '',
        installed: installed));
  }
  return res;
}

/// apk: "name-1.2.3-r0 arch {origin} (license) [installed]"
List<PackageItem> parseApkList(String out) {
  final res = <PackageItem>[];
  final re = RegExp(r'^(.+?)-(\d[^\s]*)\s');
  for (final l in out.split('\n')) {
    final m = re.firstMatch('${l.trim()} ');
    if (m == null) continue;
    res.add(PackageItem(m.group(1)!, m.group(2)!,
        installed: l.contains('[installed]') || l.contains('[upgradable')));
  }
  return res;
}

List<LedItem> parseLeds(String out) {
  final res = <LedItem>[];
  for (final block in out.split('@@LED ').skip(1)) {
    final lines = block.split('\n');
    final name = lines.first.trim();
    if (name.isEmpty) continue;
    var trigger = '';
    var triggers = <String>[];
    var br = 0;
    var mx = 1;
    for (final l in lines.skip(1)) {
      if (l.startsWith('T:')) {
        final raw = l.substring(2).trim();
        triggers = raw.split(' ').map((e) => e.replaceAll(RegExp(r'[\[\]]'), '')).where((e) => e.isNotEmpty).toList();
        final m = RegExp(r'\[([^\]]+)\]').firstMatch(raw);
        if (m != null) trigger = m.group(1)!;
      } else if (l.startsWith('B:')) {
        br = int.tryParse(l.substring(2).trim()) ?? 0;
      } else if (l.startsWith('M:')) {
        mx = int.tryParse(l.substring(2).trim()) ?? 1;
      }
    }
    res.add(LedItem(name, trigger, br, mx, triggers));
  }
  return res;
}

List<AuthKey> parseAuthorizedKeys(String out) {
  final res = <AuthKey>[];
  var n = 0;
  for (final raw in out.split('\n')) {
    n++;
    final l = raw.trim();
    if (l.isEmpty || l.startsWith('#')) continue;
    final f = l.split(RegExp(r'\s+'));
    if (f.length < 2) continue;
    final blob = f[1];
    final preview = blob.length > 24 ? '${blob.substring(0, 12)}…${blob.substring(blob.length - 8)}' : blob;
    res.add(AuthKey(n, f[0], f.length > 2 ? f.sublist(2).join(' ') : '', preview));
  }
  return res;
}

/// vnstat 2.x JSON -> usage for each interface.
List<UsageData> parseVnstat(String out) {
  final j = tryJson(out);
  if (j == null) return const [];
  final ifs = j['interfaces'];
  if (ifs is! List) return const [];
  final res = <UsageData>[];
  for (final i in ifs) {
    if (i is! Map) continue;
    final name = '${i['name'] ?? ''}';
    final traffic = i['traffic'];
    if (traffic is! Map) continue;
    List<UsagePoint> pts(String key, bool day) {
      final l = traffic[key];
      if (l is! List) return const [];
      final r = <UsagePoint>[];
      for (final e in l) {
        if (e is! Map) continue;
        final d = e['date'];
        var label = '';
        if (d is Map) {
          final m = '${d['month'] ?? ''}'.padLeft(2, '0');
          label = day ? '$m-${'${d['day'] ?? ''}'.padLeft(2, '0')}' : '${d['year']}-$m';
        }
        r.add(UsagePoint(label, (e['rx'] as num?)?.toInt() ?? 0,
            (e['tx'] as num?)?.toInt() ?? 0));
      }
      return r;
    }

    res.add(UsageData(name, pts('day', true), pts('month', false)));
  }
  return res;
}

/// Ookla CLI JSON -> result.
SpeedResult? parseOokla(String out) {
  final i = out.indexOf('{');
  if (i < 0) return null;
  final j = tryJson(out.substring(i));
  if (j == null || j['download'] is! Map) return null;
  final r = SpeedResult()..source = 'Ookla';
  final dl = j['download'] as Map;
  final ul = j['upload'];
  r.downMbps = ((dl['bandwidth'] as num?) ?? 0) * 8 / 1e6;
  if (ul is Map) r.upMbps = ((ul['bandwidth'] as num?) ?? 0) * 8 / 1e6;
  final p = j['ping'];
  if (p is Map) {
    r.pingMs = (p['latency'] as num?)?.toDouble();
    r.jitterMs = (p['jitter'] as num?)?.toDouble();
  }
  r.lossPct = (j['packetLoss'] as num?)?.toDouble();
  return r;
}

const String _ledRe = r'^[A-Za-z0-9_:.\-]+$';

extension SysApi on RouterApi {
  // ------------------------------------------------------------- services

  Future<List<ServiceItem>> loadServices() async {
    final out = await ssh.run(
        r'''for f in /etc/init.d/*; do [ -x "$f" ] || continue; n=${f##*/}; e=0; "$f" enabled >/dev/null 2>&1 && e=1; r=0; "$f" running >/dev/null 2>&1 && r=1; echo "$n $e $r"; done''',
        timeout: const Duration(seconds: 40));
    return parseServices(out);
  }

  Future<void> serviceAction(String name, String action) async {
    needName(name);
    if (!const ['start', 'stop', 'restart', 'enable', 'disable'].contains(action)) {
      throw SshException(S.badName);
    }
    await ssh.run('/etc/init.d/$name $action >/dev/null 2>&1; true');
  }

  // ----------------------------------------------------------------- logs

  /// Snapshot of the system log (or kernel log). Call repeatedly to "follow".
  Future<String> readLog({int lines = 200, String filter = '', bool kernel = false}) async {
    final n = lines.clamp(10, 1000);
    final base = kernel ? 'dmesg | tail -n $n' : 'logread -l $n';
    final cmd = filter.isEmpty ? base : '$base | grep -i -- ${shq(filter)}';
    return ssh.run('$cmd 2>&1; true');
  }

  // ------------------------------------------------------------- packages

  Future<List<PackageItem>> installedPackages() async {
    if (env.pkg == 'apk') {
      return parseApkList(await ssh.run('apk list -I 2>/dev/null',
          timeout: const Duration(seconds: 40)));
    }
    if (env.pkg == 'opkg') {
      return parseOpkgList(
          await ssh.run('opkg list-installed 2>/dev/null',
              timeout: const Duration(seconds: 40)),
          installed: true);
    }
    return const [];
  }

  Future<List<PackageItem>> searchPackages(String q) async {
    if (!RegExp(r'^[A-Za-z0-9_.+\-]{2,40}$').hasMatch(q)) throw SshException(S.badName);
    if (env.pkg == 'apk') {
      return parseApkList(await ssh.run('apk search -v ${shq(q)} 2>/dev/null | head -n 60',
          timeout: const Duration(seconds: 40)));
    }
    return parseOpkgList(await ssh.run(
        'opkg list 2>/dev/null | grep -i -- ${shq(q)} | head -n 60',
        timeout: const Duration(seconds: 60)));
  }

  Future<List<PackageItem>> upgradablePackages() async {
    if (env.pkg == 'apk') {
      return parseApkList(await ssh.run('apk list -u 2>/dev/null',
          timeout: const Duration(seconds: 40)));
    }
    final out = await ssh.run('opkg list-upgradable 2>/dev/null',
        timeout: const Duration(seconds: 40));
    final res = <PackageItem>[];
    for (final l in out.split('\n')) {
      final p = l.split(' - ');
      if (p.length >= 2) {
        res.add(PackageItem(p[0].trim(), p.length > 2 ? p[2].trim() : p[1].trim(),
            upgradable: true, installed: true));
      }
    }
    return res;
  }

  Future<String> updatePackageLists() => ssh.run(
      env.pkg == 'apk' ? 'apk update 2>&1' : 'opkg update 2>&1',
      timeout: const Duration(seconds: 120));

  /// action: install, remove, upgrade. Returns the package manager output.
  Future<String> packageAction(String action, String name) async {
    needToken(name);
    final apk = env.pkg == 'apk';
    String cmd;
    switch (action) {
      case 'install':
        cmd = apk ? 'apk add ${shq(name)}' : 'opkg install ${shq(name)}';
        break;
      case 'remove':
        cmd = apk ? 'apk del ${shq(name)}' : 'opkg remove ${shq(name)}';
        break;
      case 'upgrade':
        cmd = apk ? 'apk add -u ${shq(name)}' : 'opkg upgrade ${shq(name)}';
        break;
      default:
        throw SshException(S.badName);
    }
    return (await ssh.run('$cmd 2>&1', timeout: const Duration(seconds: 180))).trim();
  }

  // ----------------------------------------------------------------- LEDs

  Future<List<LedItem>> loadLeds() async {
    final out = await ssh.run(
        r'''for d in /sys/class/leds/*; do [ -d "$d" ] || continue; echo "@@LED ${d##*/}"; echo "T:$(cat $d/trigger 2>/dev/null)"; echo "B:$(cat $d/brightness 2>/dev/null)"; echo "M:$(cat $d/max_brightness 2>/dev/null)"; done; true''');
    return parseLeds(out);
  }

  /// Immediate change (lost on reboot).
  Future<void> setLedNow(String name, int brightness) async {
    if (!RegExp(_ledRe).hasMatch(name)) throw SshException(S.badName);
    await ssh.run('echo ${brightness.clamp(0, 255)} > /sys/class/leds/$name/brightness');
  }

  /// Persistent trigger via /etc/config/system (staged).
  Future<void> stageLedTrigger(String name, String trigger) async {
    if (!RegExp(_ledRe).hasMatch(name) || !RegExp(_ledRe).hasMatch(trigger)) {
      throw SshException(S.badName);
    }
    final sec = 'swled_${name.replaceAll(RegExp(r'[^A-Za-z0-9]'), '_')}';
    await runChain(ssh.run, [
      uciNew('system', sec, 'led'),
      uciSet('system.$sec.name', 'SharkWRT $name'),
      uciSet('system.$sec.sysfs', name),
      uciSet('system.$sec.trigger', trigger),
    ]);
  }

  // ------------------------------------------------- hostname / time / NTP

  Future<SystemCfg> loadSystemCfg() async {
    final out = await ssh.run('uci show system 2>/dev/null; true');
    return parseSystemCfg(out);
  }

  Future<void> stageSystemCfg({
    required String hostname,
    required String zonename,
    required String timezone,
    required bool ntpEnabled,
    required List<String> ntpServers,
  }) async {
    if (!RegExp(r'^[A-Za-z0-9]([A-Za-z0-9\-]{0,61}[A-Za-z0-9])?$').hasMatch(hostname)) {
      throw SshException(S.badName);
    }
    if (!RegExp(r'^[A-Za-z0-9+\-:,./<>]+$').hasMatch(timezone)) throw SshException(S.badName);
    if (zonename.isNotEmpty && !RegExp(r'^[A-Za-z0-9_/+\-]+$').hasMatch(zonename)) {
      throw SshException(S.badName);
    }
    for (final s in ntpServers) {
      if (!RegExp(r'^[A-Za-z0-9.\-]+$').hasMatch(s)) throw SshException(S.badName);
    }
    final cmds = <String>[
      uciSet('system.@system[0].hostname', hostname),
      uciSet('system.@system[0].timezone', timezone),
      if (zonename.isEmpty) uciDel('system.@system[0].zonename') else uciSet('system.@system[0].zonename', zonename),
      uciBool('system.ntp.enabled', ntpEnabled),
      if (ntpServers.isNotEmpty) uciDel('system.ntp.server'),
      for (final s in ntpServers) uciAddList('system.ntp.server', s),
    ];
    await runChain(ssh.run, cmds);
  }

  // -------------------------------------------------------------- backup

  /// Creates a sysupgrade backup tarball and returns its bytes.
  Future<Uint8List> backup() async {
    final out = await ssh.run(
        'rm -f /tmp/sw-backup.tar.gz; sysupgrade -b /tmp/sw-backup.tar.gz >/dev/null 2>&1; '
        '[ -s /tmp/sw-backup.tar.gz ] && base64 /tmp/sw-backup.tar.gz || echo @@FAIL; rm -f /tmp/sw-backup.tar.gz',
        timeout: const Duration(seconds: 60));
    if (out.contains('@@FAIL') || out.trim().isEmpty) {
      throw SshException(S.backupFailed);
    }
    try {
      return base64.decode(out.replaceAll(RegExp(r'\s'), ''));
    } catch (_) {
      throw SshException(S.backupFailed);
    }
  }

  /// Uploads a backup tarball, validates it and restores it. The router reboots.
  Future<void> restoreBackup(Uint8List data) async {
    final b64 = base64.encode(data);
    await ssh.run('rm -f /tmp/sw-restore.b64 /tmp/sw-restore.tar.gz');
    const chunk = 3000;
    for (var i = 0; i < b64.length; i += chunk) {
      final part = b64.substring(i, i + chunk > b64.length ? b64.length : i + chunk);
      await ssh.run('printf %s ${shq(part)} >> /tmp/sw-restore.b64');
    }
    final chk = await ssh.run(
        'base64 -d /tmp/sw-restore.b64 > /tmp/sw-restore.tar.gz 2>/dev/null; '
        'tar tzf /tmp/sw-restore.tar.gz >/dev/null 2>&1 && echo @@VALID || echo @@BAD');
    if (!chk.contains('@@VALID')) {
      await ssh.run('rm -f /tmp/sw-restore.b64 /tmp/sw-restore.tar.gz');
      throw SshException(S.backupInvalid);
    }
    await ssh.run(
        '(sleep 1; sysupgrade -r /tmp/sw-restore.tar.gz; sleep 1; reboot) >/dev/null 2>&1 &');
  }

  // ------------------------------------------------------------- firmware

  /// Stage 1: what the router is and how much room there is.
  Future<String> firmwareInfo() => ssh.run(
      r'''ubus call system board 2>/dev/null | grep -E '"(model|board_name|description)"'; echo "free RAM (kB): $(awk '/MemAvailable/ {print $2}' /proc/meminfo)"; echo "tmp free: $(df -k /tmp | tail -n1 | awk '{print $4}') kB"''');

  /// Stage 2: router downloads the image itself.
  Future<String> firmwareDownload(String url) async {
    if (!RegExp(r'^https://[A-Za-z0-9._~:/?#@!$&*+,;=%\-]+$').hasMatch(url)) {
      throw SshException(S.badUrl);
    }
    return (await ssh.run(
            'rm -f /tmp/sw-fw.bin; (uclient-fetch -q -O /tmp/sw-fw.bin ${shq(url)} || wget -q -O /tmp/sw-fw.bin ${shq(url)} || curl -sL -o /tmp/sw-fw.bin ${shq(url)}) 2>&1; ls -l /tmp/sw-fw.bin 2>&1',
            timeout: const Duration(minutes: 5)))
        .trim();
  }

  /// Stage 3: checksum of the downloaded image.
  Future<String> firmwareChecksum() async =>
      (await ssh.run('sha256sum /tmp/sw-fw.bin 2>&1')).trim().split(' ').first;

  /// Stage 4: sysupgrade's own validation (does not flash).
  Future<String> firmwareValidate() async =>
      (await ssh.run('sysupgrade -T /tmp/sw-fw.bin 2>&1 && echo @@VALID',
              timeout: const Duration(seconds: 60)))
          .trim();

  /// Stage 5: flash. The router reboots and the SSH session ends.
  Future<void> firmwareFlash({required bool keepSettings}) async {
    await ssh.run(
        '(sleep 1; sysupgrade ${keepSettings ? '' : '-n '}/tmp/sw-fw.bin) >/dev/null 2>&1 &');
  }

  Future<void> factoryReset() =>
      ssh.run('(sleep 1; firstboot -y; reboot) >/dev/null 2>&1 &');

  Future<void> powerOff() => ssh.run('(sleep 1; poweroff) >/dev/null 2>&1 &');

  // ------------------------------------------------------------- SSH keys

  Future<List<AuthKey>> loadAuthorizedKeys() async =>
      parseAuthorizedKeys(await ssh.run('cat /etc/dropbear/authorized_keys 2>/dev/null; true'));

  Future<void> addAuthorizedKey(String key) async {
    final k = key.trim();
    if (!RegExp(r'^(ssh-(rsa|ed25519)|ecdsa-sha2-[a-z0-9]+|sk-[a-z0-9@.\-]+) [A-Za-z0-9+/=]+( [^\n\r]*)?$')
        .hasMatch(k)) {
      throw SshException(S.badKey);
    }
    await ssh.run('mkdir -p /etc/dropbear && printf %s\\\\n ${shq(k)} >> /etc/dropbear/authorized_keys && chmod 600 /etc/dropbear/authorized_keys');
  }

  Future<void> removeAuthorizedKey(int line) async {
    if (line < 1 || line > 100000) throw SshException(S.badNumber);
    await ssh.run("sed -i '${line}d' /etc/dropbear/authorized_keys");
  }

  // ----------------------------------------------------- speed / usage

  /// Quick test: latency/jitter/loss via ping, throughput via the router's own download.
  Future<SpeedResult> speedQuick() async {
    const cmd = r'''P=$(ping -c 6 -W 2 1.1.1.1 2>&1); echo "$P" | tail -n 3;
U=https://speed.cloudflare.com/__down?bytes=12000000;
S=$(cut -d' ' -f1 /proc/uptime);
if command -v curl >/dev/null 2>&1; then curl -s -o /dev/null "$U"; else uclient-fetch -q -O /dev/null "$U" 2>/dev/null || wget -q -O /dev/null "$U"; fi;
E=$(cut -d' ' -f1 /proc/uptime); echo "DL $S $E"
if command -v curl >/dev/null 2>&1; then head -c 4000000 /dev/urandom > /tmp/swup.bin; S=$(cut -d' ' -f1 /proc/uptime); curl -s -o /dev/null -F file=@/tmp/swup.bin https://speed.cloudflare.com/__up; E=$(cut -d' ' -f1 /proc/uptime); rm -f /tmp/swup.bin; echo "UL $S $E"; fi''';
    final out = await ssh.run(cmd, timeout: const Duration(seconds: 90));
    return parseQuickSpeed(out);
  }

  Future<SpeedResult?> speedOokla() async {
    if (!env.has('speedtest') && !env.has('ookla')) return null;
    final bin = env.has('speedtest') ? 'speedtest' : 'ookla';
    final out = await ssh.run('$bin --accept-license --accept-gdpr -f json 2>&1',
        timeout: const Duration(seconds: 120));
    return parseOokla(out);
  }

  Future<List<UsageData>?> loadUsage() async {
    if (!env.has('vnstat')) return null;
    final out = await ssh.run('vnstat --json 2>/dev/null; true',
        timeout: const Duration(seconds: 25));
    return parseVnstat(out);
  }
}

SpeedResult parseQuickSpeed(String out) {
  final r = SpeedResult()..source = 'Quick';
  final loss = RegExp(r'(\d+(?:\.\d+)?)% packet loss').firstMatch(out);
  if (loss != null) r.lossPct = double.tryParse(loss.group(1)!);
  final rtt = RegExp(r'=\s*([\d.]+)/([\d.]+)/([\d.]+)(?:/([\d.]+))?').firstMatch(out);
  if (rtt != null) {
    r.pingMs = double.tryParse(rtt.group(2)!);
    final mn = double.tryParse(rtt.group(1)!);
    final mx = double.tryParse(rtt.group(3)!);
    if (mn != null && mx != null) r.jitterMs = (mx - mn) / 2;
  }
  final dl = RegExp(r'^DL ([\d.]+) ([\d.]+)', multiLine: true).firstMatch(out);
  if (dl != null) {
    final dt = double.parse(dl.group(2)!) - double.parse(dl.group(1)!);
    if (dt > 0.2) r.downMbps = 12000000 * 8 / dt / 1e6;
  }
  final ul = RegExp(r'^UL ([\d.]+) ([\d.]+)', multiLine: true).firstMatch(out);
  if (ul != null) {
    final dt = double.parse(ul.group(2)!) - double.parse(ul.group(1)!);
    if (dt > 0.2) r.upMbps = 4000000 * 8 / dt / 1e6;
  }
  return r;
}
