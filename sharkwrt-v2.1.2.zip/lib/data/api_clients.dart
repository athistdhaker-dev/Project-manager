import '../core/uci.dart';
import 'api_models.dart';
import 'api_util.dart';
import 'router_api.dart';

const String _blockPrefix = 'swblk_';
const String _leasePrefix = 'swlease_';

/// Pure parser for the combined clients command output (see loadClients).
ClientsData parseClients(String out) {
  // dhcp leases: expiry mac ip hostname clientid
  final names = <String, String>{};
  final leaseIp = <String, String>{};
  for (final l in section(out, 'LEASES').split('\n')) {
    final f = l.trim().split(RegExp(r'\s+'));
    if (f.length >= 4) {
      final mac = f[1].toLowerCase();
      leaseIp[mac] = f[2];
      if (f[3] != '*') names[mac] = f[3];
    }
  }

  // neighbours on the LAN bridge
  final neighIp = <String, String>{};
  for (final l in section(out, 'NEIGH').split('\n')) {
    final f = l.trim().split(RegExp(r'\s+'));
    if (f.length < 5) continue;
    final ip = f[0];
    if (ip.contains(':')) continue;
    final di = f.indexOf('dev');
    final dev = (di >= 0 && di + 1 < f.length) ? f[di + 1] : '';
    final li = f.indexOf('lladdr');
    if (li < 0 || li + 1 >= f.length) continue;
    final state = f.last;
    if (state == 'FAILED' || state == 'INCOMPLETE') continue;
    if (!(dev.startsWith('br-') || dev == 'lan' || dev == 'br0')) continue;
    neighIp[f[li + 1].toLowerCase()] = ip;
  }

  final byMac = <String, NetClient>{};
  var band = '2.4G';
  var ssid = '';
  String? curMac;
  for (final raw in section(out, 'WIFI').split('\n')) {
    final l = raw.trim();
    if (l.startsWith('IFACE ')) {
      band = '2.4G';
      ssid = '';
      curMac = null;
    } else if (l.startsWith('ssid ')) {
      ssid = l.substring(5).trim();
    } else if (l.startsWith('channel')) {
      final m = RegExp(r'\((\d+) MHz\)').firstMatch(l);
      if (m != null) {
        final mhz = int.parse(m.group(1)!);
        band = mhz >= 5925 ? '6G' : (mhz >= 3000 ? '5G' : '2.4G');
      }
    } else if (l.startsWith('Station ')) {
      final f = l.split(RegExp(r'\s+'));
      if (f.length >= 2) {
        final mac = f[1].toLowerCase();
        curMac = mac;
        byMac[mac] = NetClient(
          mac,
          neighIp[mac] ?? leaseIp[mac] ?? '',
          names[mac] ?? '',
          band,
          null,
          ssid: ssid,
        );
      }
    } else if (curMac != null && l.startsWith('signal:')) {
      final m = RegExp(r'signal:\s*(-?\d+)').firstMatch(l);
      if (m != null) byMac[curMac]?.signal = int.parse(m.group(1)!);
    }
  }
  neighIp.forEach((mac, ip) {
    if (!byMac.containsKey(mac)) {
      byMac[mac] = NetClient(mac, ip, names[mac] ?? '', 'LAN', null);
    }
  });

  final list = byMac.values.toList()
    ..sort((a, b) => _ipKey(a.ip).compareTo(_ipKey(b.ip)));

  // blocked MACs (rules this app created)
  final blocked = <String, String>{};
  final fw = parseUciShow(section(out, 'FW'));
  for (final s in fw.ofType('rule')) {
    if (!s.name.startsWith(_blockPrefix)) continue;
    final mac = (s.o('src_mac') ?? '').toLowerCase();
    if (isMac(mac)) blocked[mac] = names[mac] ?? '';
  }

  // reservations
  final reserved = <String, String>{};
  final dhcp = parseUciShow(section(out, 'DHCP'));
  for (final s in dhcp.ofType('host')) {
    final mac = (s.o('mac') ?? '').toLowerCase();
    if (isMac(mac)) reserved[mac] = s.o('ip') ?? '';
  }
  return ClientsData(list, blocked, reserved);
}

int _ipKey(String ip) {
  final p = ip.split('.');
  if (p.length != 4) return 1 << 40;
  var v = 0;
  for (final x in p) {
    v = v * 256 + (int.tryParse(x) ?? 0);
  }
  return v;
}

extension ClientsApi on RouterApi {
  static const String _clientsCmd =
      r'''echo '@@LEASES'; cat /tmp/dhcp.leases 2>/dev/null; echo '@@NEIGH'; ip neigh show 2>/dev/null; echo '@@WIFI'; for i in $(iw dev 2>/dev/null | awk '$1=="Interface"{print $2}'); do echo "IFACE $i"; iw dev $i info 2>/dev/null | grep -E 'channel|ssid'; iw dev $i station dump 2>/dev/null; done; echo '@@DHCP'; uci show dhcp 2>/dev/null; echo '@@FW'; uci show firewall 2>/dev/null | grep swblk_; true''';

  Future<ClientsData> loadClients() async {
    final out = await ssh.run(_clientsCmd, timeout: const Duration(seconds: 30));
    return parseClients(out);
  }

  /// Blocks a device's internet access by MAC (any zone -> wan).
  Future<void> stageBlock(String mac) async {
    final m = needMac(mac);
    final sec = '$_blockPrefix${m.replaceAll(':', '')}';
    await runChain(ssh.run, [
      uciNew('firewall', sec, 'rule'),
      uciSet('firewall.$sec.name', 'SharkWRT block $m'),
      uciSet('firewall.$sec.src', '*'),
      uciSet('firewall.$sec.src_mac', m),
      uciSet('firewall.$sec.dest', 'wan'),
      uciSet('firewall.$sec.target', 'REJECT'),
    ]);
  }

  Future<void> stageUnblock(String mac) {
    final m = needMac(mac);
    return runChain(
        ssh.run, [uciDel('firewall.$_blockPrefix${m.replaceAll(':', '')}')]);
  }

  /// Existing connections survive a firewall reload; drop them after blocking.
  Future<void> killConnections(String ip) async {
    if (!isIpv4(ip)) return;
    await ssh.run('conntrack -D -s $ip >/dev/null 2>&1; true');
  }

  Future<void> stageStaticLease(String name, String mac, String ip) async {
    final m = needMac(mac);
    needIp(ip);
    final sec = '$_leasePrefix${m.replaceAll(':', '')}';
    await runChain(ssh.run, [
      uciNew('dhcp', sec, 'host'),
      uciSet('dhcp.$sec.mac', m),
      uciSet('dhcp.$sec.ip', ip),
      if (name.isNotEmpty) uciSet('dhcp.$sec.name', name),
    ]);
  }

  Future<void> stageDeleteLease(String section) =>
      runChain(ssh.run, [uciDel('dhcp.${needName(section)}')]);

  /// Sends a magic packet from the router. Returns null on success, or a hint.
  Future<String?> wakeOnLan(String mac) async {
    final m = needMac(mac);
    final out = await ssh.run(
        'IF=\$(uci -q get network.lan.device || echo br-lan); '
        'if command -v etherwake >/dev/null 2>&1; then etherwake -b -i "\$IF" $m && echo SENT; '
        'elif command -v ether-wake >/dev/null 2>&1; then ether-wake -b -i "\$IF" $m && echo SENT; '
        'elif command -v wol >/dev/null 2>&1; then wol -i "\$(uci -q get network.lan.broadcast || echo 255.255.255.255)" $m && echo SENT; '
        'else echo NOWOL; fi 2>&1');
    if (out.contains('SENT')) return null;
    final inst = env.pkg == 'apk' ? 'apk add etherwake' : 'opkg update && opkg install etherwake';
    return inst;
  }

  /// Per-device traffic totals from nlbwmon: mac -> [down, up] bytes.
  /// Returns null when nlbwmon is not installed.
  Future<Map<String, List<int>>?> deviceUsage() async {
    final out = await ssh.run(
        'command -v nlbw >/dev/null 2>&1 || { echo NONLBW; exit 0; }; nlbw -c csv -g mac 2>&1 | head -n 400');
    if (out.contains('NONLBW')) return null;
    return parseNlbw(out);
  }
}

/// Parses `nlbw -c csv -g mac`; the header row tells which column is which.
Map<String, List<int>> parseNlbw(String out) {
  final lines = out.split('\n').where((l) => l.trim().isNotEmpty).toList();
  if (lines.length < 2) return {};
  String delim = ';';
  for (final d in [';', ',', '\t', ' ']) {
    if (lines.first.contains(d)) {
      delim = d;
      break;
    }
  }
  List<String> cells(String l) =>
      l.split(delim).map((e) => e.trim().replaceAll('"', '')).toList();
  final head = cells(lines.first);
  final iMac = head.indexOf('mac');
  final iRx = head.indexOf('rx_bytes');
  final iTx = head.indexOf('tx_bytes');
  if (iMac < 0 || iRx < 0 || iTx < 0) return {};
  final res = <String, List<int>>{};
  for (final l in lines.skip(1)) {
    final c = cells(l);
    if (c.length <= iTx || c.length <= iMac || c.length <= iRx) continue;
    final mac = c[iMac].toLowerCase();
    if (!isMac(mac)) continue;
    final rx = int.tryParse(c[iRx]) ?? 0;
    final tx = int.tryParse(c[iTx]) ?? 0;
    final cur = res[mac] ?? [0, 0];
    res[mac] = [cur[0] + rx, cur[1] + tx];
  }
  return res;
}
