import '../core/uci.dart';
import 'api_models.dart';
import 'api_util.dart';
import 'router_api.dart';
import 'ssh.dart';

/// Interface names used for the guest and IoT networks the app creates.
const String kGuestNet = 'swguest';
const String kIotNet = 'swiot';

class ChannelInfo {
  final int channel;
  final int mhz;
  final bool restricted;
  final bool dfs;
  const ChannelInfo(this.channel, this.mhz, {this.restricted = false, this.dfs = false});
}

/// State of the app-managed guest / IoT network.
class GuestNet {
  final String kind; // 'guest' or 'iot'
  final bool exists;
  final bool enabled;
  final String ssid;
  final String key;
  final String encryption;
  final List<WifiIface> ifaces;
  const GuestNet({
    required this.kind,
    required this.exists,
    required this.enabled,
    required this.ssid,
    required this.key,
    required this.encryption,
    required this.ifaces,
  });

  String get netName => kind == 'iot' ? kIotNet : kGuestNet;
}

String _bandOf(UciSection s) {
  final ch = s.o('channel') ?? 'auto';
  final b = s.o('band');
  final hw = s.o('hwmode');
  if (b == '2g') return '2.4G';
  if (b == '5g') return '5G';
  if (b == '6g') return '6G';
  if (hw == '11g' || hw == '11b') return '2.4G';
  if (hw == '11a') return '5G';
  final n = int.tryParse(ch);
  if (n != null) return n <= 14 ? '2.4G' : '5G';
  return '?';
}

/// Pure parser for `uci show wireless`.
WifiData parseWifi(String out) {
  final cfg = parseUciShow(out);
  final radios = cfg.ofType('wifi-device').map((s) {
    return RadioInfo(
      s.name,
      _bandOf(s),
      s.o('channel') ?? 'auto',
      s.o('htmode') ?? '',
      s.o('disabled') == '1',
      country: s.o('country') ?? '',
      txpower: s.o('txpower') ?? '',
    );
  }).toList();
  final ifaces = cfg.ofType('wifi-iface').map((s) {
    return WifiIface(
      s.name,
      s.o('device') ?? '',
      s.o('ssid') ?? '',
      s.o('encryption') ?? 'none',
      s.o('key') ?? '',
      s.o('mode') ?? 'ap',
      s.o('disabled') == '1',
      network: s.o('network') ?? '',
      hidden: s.o('hidden') == '1',
      isolate: s.o('isolate') == '1',
    );
  }).toList();
  return WifiData(radios, ifaces);
}

GuestNet findGuest(WifiData w, String kind) {
  final net = kind == 'iot' ? kIotNet : kGuestNet;
  final list = w.ifaces.where((i) => i.network == net).toList();
  if (list.isEmpty) {
    return GuestNet(
      kind: kind,
      exists: false,
      enabled: false,
      ssid: '',
      key: '',
      encryption: 'psk2',
      ifaces: const [],
    );
  }
  final first = list.first;
  return GuestNet(
    kind: kind,
    exists: true,
    enabled: list.any((i) => !i.disabled),
    ssid: first.ssid,
    key: first.key,
    encryption: first.encryption,
    ifaces: list,
  );
}

String _qrEscape(String s) => s.replaceAllMapped(
    RegExp(r'([\\;,:"])'), (m) => '\\${m.group(1)}');

/// The text a phone camera understands as "join this Wi-Fi".
String wifiQrPayload(String ssid, String key, String encryption, {bool hidden = false}) {
  final open = encryption == 'none' || key.isEmpty;
  final b = StringBuffer('WIFI:');
  b.write('T:${open ? 'nopass' : 'WPA'};');
  b.write('S:${_qrEscape(ssid)};');
  if (!open) b.write('P:${_qrEscape(key)};');
  if (hidden) b.write('H:true;');
  b.write(';');
  return b.toString();
}

const List<String> kEncryptions = [
  'psk2',
  'sae-mixed',
  'sae',
  'psk-mixed',
  'owe',
  'none',
];

/// A short list of regulatory domains (code, name).
const List<(String, String)> kCountries = [
  ('IN', 'India'),
  ('US', 'United States'),
  ('GB', 'United Kingdom'),
  ('DE', 'Germany'),
  ('FR', 'France'),
  ('IT', 'Italy'),
  ('ES', 'Spain'),
  ('NL', 'Netherlands'),
  ('CA', 'Canada'),
  ('AU', 'Australia'),
  ('NZ', 'New Zealand'),
  ('JP', 'Japan'),
  ('KR', 'South Korea'),
  ('CN', 'China'),
  ('SG', 'Singapore'),
  ('MY', 'Malaysia'),
  ('ID', 'Indonesia'),
  ('TH', 'Thailand'),
  ('VN', 'Vietnam'),
  ('PH', 'Philippines'),
  ('PK', 'Pakistan'),
  ('BD', 'Bangladesh'),
  ('LK', 'Sri Lanka'),
  ('NP', 'Nepal'),
  ('AE', 'United Arab Emirates'),
  ('SA', 'Saudi Arabia'),
  ('TR', 'Turkey'),
  ('ZA', 'South Africa'),
  ('NG', 'Nigeria'),
  ('KE', 'Kenya'),
  ('EG', 'Egypt'),
  ('BR', 'Brazil'),
  ('MX', 'Mexico'),
  ('AR', 'Argentina'),
  ('RU', 'Russia'),
  ('PL', 'Poland'),
  ('SE', 'Sweden'),
  ('NO', 'Norway'),
  ('CH', 'Switzerland'),
  ('00', 'World (generic)'),
];

List<ChannelInfo> _staticChannels(String band) {
  if (band == '2.4G') {
    return [for (var c = 1; c <= 13; c++) ChannelInfo(c, 2407 + 5 * c)];
  }
  const five = [36, 40, 44, 48, 52, 56, 60, 64, 100, 104, 108, 112, 116, 120,
      124, 128, 132, 136, 140, 144, 149, 153, 157, 161, 165];
  return [
    for (final c in five)
      ChannelInfo(c, 5000 + 5 * c, dfs: c >= 52 && c <= 144),
  ];
}

extension WifiApi on RouterApi {
  Future<WifiData> loadWifi() async {
    final out = await ssh.run('uci show wireless 2>/dev/null');
    return parseWifi(out);
  }

  /// wifi-iface section -> kernel interface name (needed for iwinfo / assoclist).
  Future<Map<String, String>> wifiIfnames() async {
    final out = await ssh.run('ubus call network.wireless status 2>/dev/null');
    final j = tryJson(out);
    final res = <String, String>{};
    if (j == null) return res;
    j.forEach((radio, v) {
      if (v is Map && v['interfaces'] is List) {
        for (final i in v['interfaces'] as List) {
          if (i is Map && i['section'] != null && i['ifname'] != null) {
            res['${i['section']}'] = '${i['ifname']}';
          }
        }
      }
    });
    return res;
  }

  /// Channels the radio may use right now (live from iwinfo, else a static list).
  Future<List<ChannelInfo>> loadChannels(String radio, String band) async {
    try {
      final w = await loadWifi();
      final names = await wifiIfnames();
      String? ifname;
      for (final i in w.ifaces) {
        if (i.device == radio && names.containsKey(i.section)) {
          ifname = names[i.section];
          break;
        }
      }
      if (ifname != null && isSafeName(ifname)) {
        final out = await ssh.run('iwinfo ${shq(ifname)} freqlist 2>/dev/null');
        final list = <ChannelInfo>[];
        for (final l in out.split('\n')) {
          final m = RegExp(r'(\d+\.\d+)\s*GHz\s*\(Channel\s+(\d+)\)(.*)$').firstMatch(l);
          if (m == null) continue;
          final mhz = (double.parse(m.group(1)!) * 1000).round();
          final ch = int.parse(m.group(2)!);
          final tail = (m.group(3) ?? '').toLowerCase();
          list.add(ChannelInfo(
            ch,
            mhz,
            restricted: tail.contains('restricted') || tail.contains('disabled'),
            dfs: tail.contains('radar') || (mhz >= 5250 && mhz <= 5730),
          ));
        }
        if (list.isNotEmpty) return list;
      }
    } catch (_) {}
    return _staticChannels(band);
  }

  // ------------------------------------------------------------- staging

  Future<void> stageIface(
    String section, {
    String? ssid,
    String? encryption,
    String? key,
    bool? hidden,
    bool? isolate,
    bool? disabled,
  }) async {
    final p = 'wireless.${needName(section)}';
    final c = <String>[];
    if (ssid != null) c.add(uciSet('$p.ssid', ssid));
    if (encryption != null) {
      c.add(uciSet('$p.encryption', encryption));
      if (encryption == 'none') c.add(uciDel('$p.key'));
    }
    if (key != null && key.isNotEmpty && encryption != 'none') {
      c.add(uciSet('$p.key', key));
    }
    if (hidden != null) c.add(hidden ? uciSet('$p.hidden', '1') : uciDel('$p.hidden'));
    if (isolate != null) {
      c.add(isolate ? uciSet('$p.isolate', '1') : uciDel('$p.isolate'));
    }
    if (disabled != null) {
      c.add(disabled ? uciSet('$p.disabled', '1') : uciDel('$p.disabled'));
    }
    await runChain(ssh.run, c);
  }

  Future<void> stageAddIface({
    required String radio,
    required String ssid,
    required String encryption,
    required String key,
    String network = 'lan',
    bool hidden = false,
  }) async {
    final r = needName(radio);
    final net = needName(network);
    final c = <String>[
      r'S=$(uci add wireless wifi-iface)',
      r'uci set wireless.$S.device=' + shq(r),
      r'uci set wireless.$S.mode=ap',
      r'uci set wireless.$S.network=' + shq(net),
      r'uci set wireless.$S.ssid=' + shq(ssid),
      r'uci set wireless.$S.encryption=' + shq(encryption),
      if (encryption != 'none') r'uci set wireless.$S.key=' + shq(key),
      if (hidden) r'uci set wireless.$S.hidden=1',
    ];
    await runChain(ssh.run, c);
  }

  Future<void> stageDeleteIface(String section) =>
      runChain(ssh.run, [uciDel('wireless.${needName(section)}')]);

  Future<void> stageRadio(
    String radio, {
    String? channel,
    String? htmode,
    String? txpower,
    String? country,
    bool? disabled,
  }) async {
    final p = 'wireless.${needName(radio)}';
    final c = <String>[];
    if (channel != null) {
      if (channel != 'auto') needInt(channel);
      c.add(uciSet('$p.channel', channel));
    }
    if (htmode != null) c.add(htmode.isEmpty ? uciDel('$p.htmode') : uciSet('$p.htmode', needToken(htmode)));
    if (txpower != null) {
      if (txpower.isEmpty) {
        c.add(uciDel('$p.txpower'));
      } else {
        c.add(uciSet('$p.txpower', needInt(txpower)));
      }
    }
    if (country != null) {
      if (!RegExp(r'^[A-Z0-9]{2}$').hasMatch(country)) throw SshException('Invalid country code');
      c.add(uciSet('$p.country', country));
    }
    if (disabled != null) {
      c.add(disabled ? uciSet('$p.disabled', '1') : uciDel('$p.disabled'));
    }
    await runChain(ssh.run, c);
  }

  /// Sets the regulatory domain on every radio.
  Future<void> stageCountryAll(String country) async {
    final w = await loadWifi();
    for (final r in w.radios) {
      await stageRadio(r.name, country: country);
    }
  }

  // ------------------------------------------------------- guest and IoT

  Future<String> _freeSubnet(int startThird) async {
    final out = await ssh.run(
        'uci show network 2>/dev/null | grep -E "ipaddr="; uci show dhcp 2>/dev/null | grep -E "start="');
    final used = <String>{};
    for (final m in RegExp(r'(\d+)\.(\d+)\.(\d+)\.\d+').allMatches(out)) {
      used.add('${m.group(1)}.${m.group(2)}.${m.group(3)}');
    }
    for (var x = startThird; x < 250; x++) {
      final p = '192.168.$x';
      if (!used.contains(p)) return p;
    }
    throw SshException('No free subnet found');
  }

  /// Builds an isolated Wi-Fi network (own subnet, DHCP and firewall zone).
  Future<void> stageCreateGuest({
    required String kind, // 'guest' or 'iot'
    required String ssid,
    required String encryption,
    required String key,
    required List<String> radios,
  }) async {
    if (radios.isEmpty) throw SshException('Pick at least one radio');
    final iot = kind == 'iot';
    final net = iot ? kIotNet : kGuestNet;
    final tag = iot ? 'iot' : 'guest';
    final base = await _freeSubnet(iot ? 40 : 30);
    final c = <String>[
      uciNew('network', net, 'interface'),
      uciSet('network.$net.proto', 'static'),
      uciSet('network.$net.ipaddr', '$base.1'),
      uciSet('network.$net.netmask', '255.255.255.0'),
      uciNew('dhcp', net, 'dhcp'),
      uciSet('dhcp.$net.interface', net),
      uciSet('dhcp.$net.start', '100'),
      uciSet('dhcp.$net.limit', '100'),
      uciSet('dhcp.$net.leasetime', '1h'),
      uciNew('firewall', 'sw_${tag}_zone', 'zone'),
      uciSet('firewall.sw_${tag}_zone.name', net),
      uciSet('firewall.sw_${tag}_zone.network', net),
      uciSet('firewall.sw_${tag}_zone.input', 'REJECT'),
      uciSet('firewall.sw_${tag}_zone.output', 'ACCEPT'),
      uciSet('firewall.sw_${tag}_zone.forward', 'REJECT'),
      uciNew('firewall', 'sw_${tag}_fwd', 'forwarding'),
      uciSet('firewall.sw_${tag}_fwd.src', net),
      uciSet('firewall.sw_${tag}_fwd.dest', 'wan'),
      uciNew('firewall', 'sw_${tag}_dhcp', 'rule'),
      uciSet('firewall.sw_${tag}_dhcp.name', 'SharkWRT $tag DHCP'),
      uciSet('firewall.sw_${tag}_dhcp.src', net),
      uciSet('firewall.sw_${tag}_dhcp.proto', 'udp'),
      uciSet('firewall.sw_${tag}_dhcp.dest_port', '67'),
      uciSet('firewall.sw_${tag}_dhcp.target', 'ACCEPT'),
      uciNew('firewall', 'sw_${tag}_dns', 'rule'),
      uciSet('firewall.sw_${tag}_dns.name', 'SharkWRT $tag DNS'),
      uciSet('firewall.sw_${tag}_dns.src', net),
      uciSet('firewall.sw_${tag}_dns.proto', 'tcp udp'),
      uciSet('firewall.sw_${tag}_dns.dest_port', '53'),
      uciSet('firewall.sw_${tag}_dns.target', 'ACCEPT'),
      if (iot) ...[
        // let the main LAN reach IoT devices (phone controlling a smart bulb)
        uciNew('firewall', 'sw_iot_fromlan', 'forwarding'),
        uciSet('firewall.sw_iot_fromlan.src', 'lan'),
        uciSet('firewall.sw_iot_fromlan.dest', net),
      ],
    ];
    for (final r in radios) {
      final sec = 'sw_${tag}_${needName(r)}';
      c.addAll([
        uciNew('wireless', sec, 'wifi-iface'),
        uciSet('wireless.$sec.device', r),
        uciSet('wireless.$sec.mode', 'ap'),
        uciSet('wireless.$sec.network', net),
        uciSet('wireless.$sec.ssid', ssid),
        uciSet('wireless.$sec.encryption', encryption),
        if (encryption != 'none') uciSet('wireless.$sec.key', key),
        uciSet('wireless.$sec.isolate', '1'),
      ]);
    }
    await runChain(ssh.run, c);
  }

  Future<void> stageGuestEnabled(GuestNet g, bool on) async {
    final c = <String>[
      for (final i in g.ifaces)
        on
            ? uciDel('wireless.${needName(i.section)}.disabled')
            : uciSet('wireless.${needName(i.section)}.disabled', '1'),
    ];
    await runChain(ssh.run, c);
  }

  Future<void> stageRemoveGuest(GuestNet g) async {
    final tag = g.kind == 'iot' ? 'iot' : 'guest';
    final c = <String>[
      for (final i in g.ifaces) uciDel('wireless.${needName(i.section)}'),
      uciDel('network.${g.netName}'),
      uciDel('dhcp.${g.netName}'),
      uciDel('firewall.sw_${tag}_zone'),
      uciDel('firewall.sw_${tag}_fwd'),
      uciDel('firewall.sw_${tag}_dhcp'),
      uciDel('firewall.sw_${tag}_dns'),
      if (g.kind == 'iot') uciDel('firewall.sw_iot_fromlan'),
    ];
    await runChain(ssh.run, c);
  }
}
