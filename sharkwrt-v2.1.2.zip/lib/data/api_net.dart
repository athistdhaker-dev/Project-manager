import '../core/strings.dart';
import '../core/uci.dart';
import 'api_models.dart';
import 'api_util.dart';
import 'router_api.dart';
import 'ssh.dart';

const String _vlanPrefix = 'swvlan';
const String _routePrefix = 'swroute_';

String _needLease(String s) {
  if (!RegExp(r'^\d{1,6}[smhdw]?$').hasMatch(s) && s != 'infinite') {
    throw SshException(S.badNumber);
  }
  return s;
}

String _needMask(String s) {
  if (!isIpv4(s)) throw SshException(S.badIp);
  return s;
}

String _needPortTag(String s) {
  // lan1, lan2:t, lan3:u*, eth0.1 ...
  if (!RegExp(r'^[A-Za-z0-9_.\-]+(:[tu]\*?)?$').hasMatch(s)) {
    throw SshException(S.badName);
  }
  return s;
}

String _needVlanId(String s) {
  final n = int.tryParse(s);
  if (n == null || n < 1 || n > 4094) throw SshException(S.badNumber);
  return '$n';
}

/// WAN settings as read from the router, for pre-filling the edit form.
class WanConfig {
  final String proto;
  final String username;
  final String ip;
  final String netmask;
  final String gateway;
  final String dns;
  final String mtu;
  final String macaddr;
  final String metric;
  final bool peerdns;
  final bool ipv6Enabled;
  final String reqPrefix;
  const WanConfig({
    this.proto = 'dhcp',
    this.username = '',
    this.ip = '',
    this.netmask = '',
    this.gateway = '',
    this.dns = '',
    this.mtu = '',
    this.macaddr = '',
    this.metric = '',
    this.peerdns = true,
    this.ipv6Enabled = false,
    this.reqPrefix = 'auto',
  });
}

class LanConfig {
  final String ip;
  final String netmask;
  final bool dhcpEnabled;
  final String start;
  final String limit;
  final String leasetime;
  const LanConfig({
    this.ip = '192.168.1.1',
    this.netmask = '255.255.255.0',
    this.dhcpEnabled = true,
    this.start = '100',
    this.limit = '150',
    this.leasetime = '12h',
  });
}

class VlanItem {
  final String section;
  final String kind; // 'dsa' or 'swconfig'
  final String device; // br-lan or switch0
  final String id;
  final String ports; // "lan1:t lan2:u*" or "0t 1 2"
  const VlanItem(this.section, this.kind, this.device, this.id, this.ports);
}

class SqmConfig {
  final bool installed;
  final bool enabled;
  final String iface;
  final String down; // kbit/s
  final String up;
  final String qdisc;
  final String script;
  const SqmConfig({
    this.installed = false,
    this.enabled = false,
    this.iface = '',
    this.down = '0',
    this.up = '0',
    this.qdisc = 'cake',
    this.script = 'piece_of_cake.qos',
  });
}

class ConnTestResult {
  final bool gatewayOk;
  final bool internetOk;
  final bool dnsOk;
  final String gatewayMs;
  final String internetMs;
  final String raw;
  const ConnTestResult(this.gatewayOk, this.internetOk, this.dnsOk,
      this.gatewayMs, this.internetMs, this.raw);
}

LanConfig parseLan(NetworkData d) {
  final lan = d.network['lan'];
  final dhcp = d.dhcp['lan'];
  var ip = lan?.o('ipaddr') ?? '192.168.1.1';
  var mask = lan?.o('netmask') ?? '255.255.255.0';
  // CIDR form: 192.168.1.1/24
  final slash = ip.indexOf('/');
  if (slash > 0) {
    final bits = int.tryParse(ip.substring(slash + 1)) ?? 24;
    ip = ip.substring(0, slash);
    mask = _maskFromBits(bits);
  }
  return LanConfig(
    ip: ip,
    netmask: mask,
    dhcpEnabled: dhcp == null ? true : dhcp.o('ignore') != '1',
    start: dhcp?.o('start') ?? '100',
    limit: dhcp?.o('limit') ?? '150',
    leasetime: dhcp?.o('leasetime') ?? '12h',
  );
}

String _maskFromBits(int bits) {
  final b = bits.clamp(0, 32);
  final v = b == 0 ? 0 : (0xFFFFFFFF << (32 - b)) & 0xFFFFFFFF;
  return '${(v >> 24) & 255}.${(v >> 16) & 255}.${(v >> 8) & 255}.${v & 255}';
}

WanConfig parseWan(NetworkData d) {
  final w = d.network['wan'];
  final w6 = d.network['wan6'];
  if (w == null) return const WanConfig();
  return WanConfig(
    proto: w.o('proto') ?? 'dhcp',
    username: w.o('username') ?? '',
    ip: w.o('ipaddr') ?? '',
    netmask: w.o('netmask') ?? '',
    gateway: w.o('gateway') ?? '',
    dns: w.o('dns') ?? '',
    mtu: w.o('mtu') ?? '',
    macaddr: w.o('macaddr') ?? '',
    metric: w.o('metric') ?? '',
    peerdns: w.o('peerdns') != '0',
    ipv6Enabled: w6 != null && (w6.o('proto') ?? '') == 'dhcpv6' && w6.o('auto') != '0',
    reqPrefix: w6?.o('reqprefix') ?? 'auto',
  );
}

List<VlanItem> parseVlans(NetworkData d) {
  final res = <VlanItem>[];
  for (final s in d.network.ofType('bridge-vlan')) {
    res.add(VlanItem(
        s.name, 'dsa', s.o('device') ?? '', s.o('vlan') ?? '', s.o('ports') ?? ''));
  }
  for (final s in d.network.ofType('switch_vlan')) {
    res.add(VlanItem(s.name, 'swconfig', s.o('device') ?? '', s.o('vlan') ?? '',
        s.o('ports') ?? ''));
  }
  return res;
}

List<RouteItem> parseRoutes(NetworkData d) {
  final res = <RouteItem>[];
  for (final s in d.network.ofType('route')) {
    res.add(RouteItem(s.name, s.o('interface') ?? '', s.o('target') ?? '',
        s.o('netmask') ?? '', s.o('gateway') ?? '', s.o('metric') ?? ''));
  }
  return res;
}

/// Parses `iwinfo`-free sqm uci output into a config.
SqmConfig parseSqm(String out) {
  if (out.contains('NOSQM')) return const SqmConfig();
  final cfg = parseUciShow(out);
  UciSection? q = cfg['swsqm'];
  q ??= cfg.ofType('queue').isEmpty ? null : cfg.ofType('queue').first;
  if (q == null) return const SqmConfig(installed: true);
  return SqmConfig(
    installed: true,
    enabled: q.o('enabled') == '1',
    iface: q.o('interface') ?? '',
    down: q.o('download') ?? '0',
    up: q.o('upload') ?? '0',
    qdisc: q.o('qdisc') ?? 'cake',
    script: q.o('script') ?? 'piece_of_cake.qos',
  );
}

ConnTestResult parseConnTest(String out) {
  bool ok(String name) => RegExp('^$name=1', multiLine: true).hasMatch(out);
  String ms(String name) {
    final m = RegExp('^$name=([0-9.]+)', multiLine: true).firstMatch(out);
    return m == null ? '' : m.group(1)!;
  }

  return ConnTestResult(ok('GW'), ok('NET'), ok('DNS'), ms('GWMS'), ms('NETMS'), out);
}

extension NetApi on RouterApi {
  Future<NetworkData> loadNetwork() async {
    final out = await ssh.run(
        "echo '@@NET'; uci show network 2>/dev/null; echo '@@DHCP'; uci show dhcp 2>/dev/null; true");
    return NetworkData(
      parseUciShow(section(out, 'NET')),
      parseUciShow(section(out, 'DHCP')),
    );
  }

  // ------------------------------------------------------------------ LAN

  Future<void> stageLan(LanConfig c) async {
    _needMask(c.ip);
    _needMask(c.netmask);
    needInt(c.start);
    needInt(c.limit);
    _needLease(c.leasetime);
    await runChain(ssh.run, [
      uciSet('network.lan.ipaddr', c.ip),
      uciSet('network.lan.netmask', c.netmask),
      uciSet('dhcp.lan.start', c.start),
      uciSet('dhcp.lan.limit', c.limit),
      uciSet('dhcp.lan.leasetime', c.leasetime),
      if (c.dhcpEnabled) uciDel('dhcp.lan.ignore') else uciSet('dhcp.lan.ignore', '1'),
    ]);
  }

  // ------------------------------------------------------------------ WAN

  Future<void> stageWan({
    required String proto,
    String username = '',
    String password = '',
    String ip = '',
    String netmask = '',
    String gateway = '',
    String mtu = '',
    String metric = '',
  }) async {
    if (!const ['dhcp', 'pppoe', 'static'].contains(proto)) {
      throw SshException(S.badName);
    }
    final cmds = <String>[uciSet('network.wan.proto', proto)];
    // clear fields that belong to other protocols
    for (final o in const ['username', 'password', 'ipaddr', 'netmask', 'gateway']) {
      cmds.add(uciDel('network.wan.$o'));
    }
    if (proto == 'pppoe') {
      cmds.add(uciSet('network.wan.username', username));
      cmds.add(uciSet('network.wan.password', password));
      cmds.add(uciSet('network.wan.ipv6', 'auto'));
    } else if (proto == 'static') {
      cmds.add(uciSet('network.wan.ipaddr', needIp(ip)));
      cmds.add(uciSet('network.wan.netmask', _needMask(netmask)));
      cmds.add(uciSet('network.wan.gateway', needIp(gateway)));
    }
    if (mtu.isEmpty) {
      cmds.add(uciDel('network.wan.mtu'));
    } else {
      final n = int.tryParse(mtu);
      if (n == null || n < 576 || n > 9000) throw SshException(S.badNumber);
      cmds.add(uciSet('network.wan.mtu', '$n'));
    }
    if (metric.isEmpty) {
      cmds.add(uciDel('network.wan.metric'));
    } else {
      cmds.add(uciSet('network.wan.metric', needInt(metric)));
    }
    await runChain(ssh.run, cmds);
  }

  /// Custom DNS servers for WAN (ignores the ISP-provided ones). Empty list = ISP DNS.
  Future<void> stageDnsOverride(List<String> servers) async {
    final cmds = <String>[uciDel('network.wan.dns')];
    if (servers.isEmpty) {
      cmds.add(uciDel('network.wan.peerdns'));
    } else {
      cmds.add(uciSet('network.wan.peerdns', '0'));
      for (final s in servers) {
        cmds.add(uciAddList('network.wan.dns', needDns(s)));
      }
    }
    await runChain(ssh.run, cmds);
  }

  Future<void> stageMacClone(String mac) async {
    if (mac.isEmpty) {
      await runChain(ssh.run, [uciDel('network.wan.macaddr')]);
      return;
    }
    await runChain(ssh.run, [uciSet('network.wan.macaddr', needMac(mac))]);
  }

  /// IPv6 prefix delegation on WAN6 with a /64 handed to LAN.
  Future<void> stageIpv6({required bool enabled, String reqPrefix = 'auto'}) async {
    if (!RegExp(r'^(auto|no|\d{1,2})$').hasMatch(reqPrefix)) {
      throw SshException(S.badNumber);
    }
    if (!enabled) {
      await runChain(ssh.run, [
        '(uci -q get network.wan6 >/dev/null && uci set network.wan6.auto=0 || true)',
        uciDel('network.lan.ip6assign'),
      ]);
      return;
    }
    await runChain(ssh.run, [
      uciNew('network', 'wan6', 'interface'),
      uciSet('network.wan6.proto', 'dhcpv6'),
      uciSet('network.wan6.device', '@wan'),
      uciSet('network.wan6.reqaddress', 'try'),
      uciSet('network.wan6.reqprefix', reqPrefix),
      uciDel('network.wan6.auto'),
      uciSet('network.lan.ip6assign', '64'),
    ]);
  }

  /// Lower metric wins. Used to build WAN failover: primary 10, backup 20.
  Future<void> stageMetric(String iface, String metric) async {
    needName(iface);
    await runChain(ssh.run, [uciSet('network.$iface.metric', needInt(metric))]);
  }

  // ----------------------------------------------------------------- VLAN

  /// DSA (OpenWrt 21.02+ with a bridge-vlan layout). ports like ['lan1:u*', 'lan2:t'].
  Future<void> stageVlanDsa({
    required String id,
    required List<String> ports,
    String device = 'br-lan',
    String ip = '',
    String netmask = '255.255.255.0',
  }) async {
    final v = _needVlanId(id);
    needToken(device);
    final sec = '$_vlanPrefix$v';
    final cmds = <String>[
      uciNew('network', 'swbv$v', 'bridge-vlan'),
      uciSet('network.swbv$v.device', device),
      uciSet('network.swbv$v.vlan', v),
      uciDel('network.swbv$v.ports'),
      for (final p in ports) uciAddList('network.swbv$v.ports', _needPortTag(p)),
    ];
    if (ip.isNotEmpty) {
      cmds.addAll([
        uciNew('network', sec, 'interface'),
        uciSet('network.$sec.device', '$device.$v'),
        uciSet('network.$sec.proto', 'static'),
        uciSet('network.$sec.ipaddr', needIp(ip)),
        uciSet('network.$sec.netmask', _needMask(netmask)),
      ]);
    }
    await runChain(ssh.run, cmds);
  }

  /// swconfig (older, switch-chip routers). ports like "0t 2 3 4".
  Future<void> stageVlanSwconfig({
    required String id,
    required String ports,
    String device = 'switch0',
  }) async {
    final v = _needVlanId(id);
    needToken(device);
    if (!RegExp(r'^[0-9tu* ]+$').hasMatch(ports)) throw SshException(S.badName);
    await runChain(ssh.run, [
      uciNew('network', 'swsv$v', 'switch_vlan'),
      uciSet('network.swsv$v.device', device),
      uciSet('network.swsv$v.vlan', v),
      uciSet('network.swsv$v.ports', ports.trim()),
    ]);
  }

  Future<void> stageDeleteVlan(String sectionName) async {
    needName(sectionName);
    final extra = <String>[];
    // also drop the interface this app created for the VLAN, if any
    final m = RegExp(r'^swbv(\d+)$').firstMatch(sectionName);
    if (m != null) extra.add(uciDel('network.$_vlanPrefix${m.group(1)}'));
    await runChain(ssh.run, [uciDel('network.$sectionName'), ...extra]);
  }

  // --------------------------------------------------------------- routes

  Future<void> stageRoute({
    required String iface,
    required String target,
    required String netmask,
    required String gateway,
    String metric = '',
  }) async {
    needName(iface);
    needIp(target);
    _needMask(netmask);
    needIp(gateway);
    final id = target.replaceAll('.', '_');
    final sec = '$_routePrefix$id';
    await runChain(ssh.run, [
      uciNew('network', sec, 'route'),
      uciSet('network.$sec.interface', iface),
      uciSet('network.$sec.target', target),
      uciSet('network.$sec.netmask', netmask),
      uciSet('network.$sec.gateway', gateway),
      if (metric.isEmpty) uciDel('network.$sec.metric') else uciSet('network.$sec.metric', needInt(metric)),
    ]);
  }

  Future<void> stageDeleteRoute(String sectionName) =>
      runChain(ssh.run, [uciDel('network.${needName(sectionName)}')]);

  /// Routes the kernel is actually using (read-only).
  Future<String> kernelRoutes() async {
    final out = await ssh.run(
        "echo '# IPv4'; ip route show 2>&1; echo; echo '# IPv6'; ip -6 route show 2>&1");
    return out.trim();
  }

  // ------------------------------------------------------------------ SQM

  Future<SqmConfig> loadSqm() async {
    final out = await ssh.run(
        "[ -f /etc/config/sqm ] && uci show sqm 2>/dev/null || echo NOSQM");
    return parseSqm(out);
  }

  Future<void> stageSqm({
    required bool enabled,
    required String iface,
    required String down,
    required String up,
    String qdisc = 'cake',
    String script = 'piece_of_cake.qos',
  }) async {
    needToken(iface);
    needInt(down);
    needInt(up);
    needToken(qdisc);
    needToken(script);
    await runChain(ssh.run, [
      uciNew('sqm', 'swsqm', 'queue'),
      uciBool('sqm.swsqm.enabled', enabled),
      uciSet('sqm.swsqm.interface', iface),
      uciSet('sqm.swsqm.download', down),
      uciSet('sqm.swsqm.upload', up),
      uciSet('sqm.swsqm.qdisc', qdisc),
      uciSet('sqm.swsqm.script', script),
      uciSet('sqm.swsqm.linklayer', 'none'),
    ]);
  }

  // ------------------------------------------------------ connection test

  Future<ConnTestResult> connectionTest() async {
    const cmd = r'''GW=$(ip route show default 2>/dev/null | awk '{print $3; exit}');
if [ -n "$GW" ]; then R=$(ping -c 2 -W 2 "$GW" 2>&1); if echo "$R" | grep -q ' 0% packet loss'; then echo GW=1; else echo GW=0; fi; echo "GWMS=$(echo "$R" | awk -F'/' '/min\/avg|round-trip/ {print $5}')"; else echo GW=0; fi;
R=$(ping -c 2 -W 2 1.1.1.1 2>&1); if echo "$R" | grep -q ' 0% packet loss'; then echo NET=1; else echo NET=0; fi; echo "NETMS=$(echo "$R" | awk -F'/' '/min\/avg|round-trip/ {print $5}')";
if nslookup openwrt.org >/dev/null 2>&1; then echo DNS=1; else echo DNS=0; fi''';
    final out = await ssh.run(cmd, timeout: const Duration(seconds: 40));
    return parseConnTest(out);
  }

  /// Ping / traceroute / nslookup from the router itself.
  Future<String> diag(String tool, String host) async {
    if (!RegExp(r'^[A-Za-z0-9.\-:]+$').hasMatch(host)) throw SshException(S.badName);
    final String cmd;
    switch (tool) {
      case 'ping':
        cmd = 'ping -c 4 -W 2 ${shq(host)} 2>&1';
        break;
      case 'traceroute':
        cmd = 'traceroute -m 15 -w 2 ${shq(host)} 2>&1';
        break;
      case 'nslookup':
        cmd = 'nslookup ${shq(host)} 2>&1';
        break;
      default:
        throw SshException(S.badName);
    }
    return (await ssh.run(cmd, timeout: const Duration(seconds: 60))).trim();
  }
}
