import '../core/strings.dart';
import '../core/uci.dart';
import 'api_util.dart';
import 'api_wifi.dart';
import 'router_api.dart';
import 'ssh.dart';

class MeshPoint {
  final String section;
  final String radio;
  final String meshId;
  final bool disabled;
  const MeshPoint(this.section, this.radio, this.meshId, this.disabled);
}

class RoamingState {
  final bool fastRoaming; // 802.11r
  final bool neighborReports; // 802.11k
  final bool bssTransition; // 802.11v
  final String mobilityDomain;
  const RoamingState(
      this.fastRoaming, this.neighborReports, this.bssTransition, this.mobilityDomain);
}

/// 802.11s mesh point interfaces found in the wireless config.
List<MeshPoint> parseMeshPoints(String out) {
  final cfg = parseUciShow(out);
  final res = <MeshPoint>[];
  for (final s in cfg.ofType('wifi-iface')) {
    if ((s.o('mode') ?? '') != 'mesh') continue;
    res.add(MeshPoint(s.name, s.o('device') ?? '', s.o('mesh_id') ?? '',
        s.o('disabled') == '1'));
  }
  return res;
}

/// Reads roaming flags from the first AP interface that has any set.
RoamingState parseRoaming(String out) {
  final cfg = parseUciShow(out);
  for (final s in cfg.ofType('wifi-iface')) {
    if ((s.o('mode') ?? 'ap') != 'ap') continue;
    if (s.o('ieee80211r') != null || s.o('ieee80211k') != null || s.o('bss_transition') != null) {
      return RoamingState(
        s.o('ieee80211r') == '1',
        s.o('ieee80211k') == '1',
        s.o('bss_transition') == '1' || s.o('ieee80211v') == '1',
        s.o('mobility_domain') ?? '',
      );
    }
  }
  return const RoamingState(false, false, false, '');
}

extension MeshApi on RouterApi {
  Future<List<MeshPoint>> loadMesh() async =>
      parseMeshPoints(await ssh.run('uci show wireless 2>/dev/null; true'));

  Future<RoamingState> loadRoaming() async =>
      parseRoaming(await ssh.run('uci show wireless 2>/dev/null; true'));

  /// Joins or creates an 802.11s mesh (SAE). Needs the mesh11sd/wpad-mesh package.
  Future<void> stageMeshPoint({
    required String radio,
    required String meshId,
    required String key,
  }) async {
    needName(radio);
    if (!RegExp(r'^[A-Za-z0-9_\-]{1,32}$').hasMatch(meshId)) throw SshException(S.badName);
    if (key.length < 8) throw SshException(S.badName);
    final sec = 'swmesh_$radio';
    await runChain(ssh.run, [
      uciNew('wireless', sec, 'wifi-iface'),
      uciSet('wireless.$sec.device', radio),
      uciSet('wireless.$sec.mode', 'mesh'),
      uciSet('wireless.$sec.mesh_id', meshId),
      uciSet('wireless.$sec.encryption', 'sae'),
      uciSet('wireless.$sec.key', key),
      uciSet('wireless.$sec.mesh_fwding', '1'),
      uciSet('wireless.$sec.network', 'lan'),
    ]);
  }

  Future<void> stageMeshLeave(String section) =>
      runChain(ssh.run, [uciDel('wireless.${needName(section)}')]);

  /// Peers seen on mesh interfaces: "mac signal".
  Future<List<String>> meshPeers() async {
    final out = await ssh.run(
        r'''for i in $(iw dev 2>/dev/null | awk '$1=="Interface"{print $2}'); do iw dev $i info 2>/dev/null | grep -q 'type mesh' && iw dev $i station dump 2>/dev/null | awk -v i=$i '/^Station/{m=$2} /signal:/{print i, m, $2, "dBm"}'; done; true''');
    return out.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  }

  /// 802.11r/k/v on every AP interface so phones hand off between access points.
  Future<void> stageRoaming({
    required bool fast,
    required bool neighbor,
    required bool bss,
    String mobilityDomain = '4f57',
  }) async {
    if (!RegExp(r'^[0-9a-fA-F]{4}$').hasMatch(mobilityDomain)) throw SshException(S.badName);
    final w = await loadWifi();
    final cmds = <String>[];
    for (final i in w.ifaces) {
      if (i.mode != 'ap') continue;
      final p = 'wireless.${needName(i.section)}';
      cmds.add(uciBool('$p.ieee80211k', neighbor));
      cmds.add(uciBool('$p.bss_transition', bss));
      if (fast) {
        cmds.addAll([
          uciSet('$p.ieee80211r', '1'),
          uciSet('$p.mobility_domain', mobilityDomain),
          uciSet('$p.ft_over_ds', '0'),
          uciSet('$p.ft_psk_generate_local', '1'),
        ]);
      } else {
        cmds.add(uciSet('$p.ieee80211r', '0'));
      }
    }
    await runChain(ssh.run, cmds);
  }
}
