import 'api_models.dart';
import 'api_util.dart';
import 'router_api.dart';
import '../core/uci.dart';

/// Packages whose changes can cut the user off from the router.
const Set<String> kRiskyPackages = {'network', 'wireless', 'firewall'};

const String _bakDir = '/tmp/sharkwrt-bak';
const String _guardPid = '/tmp/sharkwrt-guard.pid';
const String _guardSh = '/tmp/sharkwrt-guard.sh';
const String _restoreSh = '/tmp/sharkwrt-restore.sh';

/// Values of these options are masked in the review list.
final RegExp _secretKey =
    RegExp(r'\.(key|password|psk|sae_password|private_key|preshared_key)$');

/// Parses the output of `uci changes`.
List<PendingChange> parsePending(String out) {
  final res = <PendingChange>[];
  for (final raw in out.split('\n')) {
    var l = raw.trim();
    if (l.isEmpty) continue;
    if (l.startsWith('-')) {
      final path = l.substring(1);
      res.add(PendingChange(path.split('.').first, path, 'del', ''));
      continue;
    }
    final eq = l.indexOf('=');
    if (eq < 0) continue;
    var op = 'set';
    var path = l.substring(0, eq);
    if (path.endsWith('+')) {
      op = 'list-add';
      path = path.substring(0, path.length - 1);
    } else if (path.endsWith('-')) {
      op = 'list-del';
      path = path.substring(0, path.length - 1);
    }
    var value = l.substring(eq + 1);
    if (value.length >= 2 && value.startsWith("'") && value.endsWith("'")) {
      value = value.substring(1, value.length - 1);
    }
    if (op == 'set' && path.split('.').length == 2) op = 'add'; // new section
    res.add(PendingChange(path.split('.').first, path, op, value));
  }
  return res;
}

/// Human friendly one-line description of a change, with secrets masked.
String describeChange(PendingChange c) {
  final shown = _secretKey.hasMatch(c.path) ? '••••••' : c.value;
  switch (c.op) {
    case 'del':
      return '− ${c.path}';
    case 'add':
      return '+ ${c.path}  ($shown)';
    case 'list-add':
      return '+ ${c.path}  $shown';
    case 'list-del':
      return '− ${c.path}  $shown';
    default:
      return '~ ${c.path} = $shown';
  }
}

extension ConfigApi on RouterApi {
  /// Everything staged but not yet committed.
  Future<List<PendingChange>> pending() async {
    final out = await ssh.run('uci changes 2>/dev/null');
    return parsePending(out);
  }

  Future<int> pendingCount() async {
    final out = await ssh.run('uci changes 2>/dev/null | wc -l');
    return int.tryParse(out.trim()) ?? 0;
  }

  Future<List<String>> pendingPackages() async {
    final out = await ssh.run(
        r"uci changes 2>/dev/null | sed 's/^-//' | cut -d. -f1 | sort -u");
    return out
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty && isSafeName(e))
        .toList();
  }

  /// Drops staged changes (all packages, or only the given ones).
  Future<void> discardPending([List<String>? pkgs]) async {
    final list = pkgs ?? await pendingPackages();
    if (list.isEmpty) return;
    final cmd = list.map((p) => 'uci revert ${needName(p)}').join('; ');
    await ssh.run(cmd);
  }

  String _reloadFor(List<PendingChange> changes, List<String> pkgs) {
    final cmds = <String>[];
    final netNeedsRestart = changes.any((c) =>
        c.pkg == 'network' &&
        (c.path.contains('bridge-vlan') ||
            c.value == 'bridge-vlan' ||
            c.value == 'switch_vlan' ||
            c.value == 'device'));
    if (pkgs.contains('network')) {
      cmds.add(netNeedsRestart
          ? '/etc/init.d/network restart'
          : '/etc/init.d/network reload');
    }
    if (pkgs.contains('wireless')) cmds.add('wifi reload');
    if (pkgs.contains('firewall')) cmds.add('/etc/init.d/firewall reload');
    if (pkgs.contains('dhcp')) {
      cmds.add('/etc/init.d/dnsmasq restart');
      cmds.add('[ -x /etc/init.d/odhcpd ] && /etc/init.d/odhcpd restart');
    }
    if (pkgs.contains('system')) cmds.add('/etc/init.d/system reload');
    if (pkgs.contains('sqm')) cmds.add('[ -x /etc/init.d/sqm ] && /etc/init.d/sqm restart');
    if (pkgs.contains('dropbear')) cmds.add('/etc/init.d/dropbear reload');
    if (pkgs.contains('network') && !pkgs.contains('wireless')) {
      // wifi interfaces sit on networks; let them pick the change up
      cmds.add('wifi reload');
    }
    return cmds.isEmpty ? ':' : cmds.join('; ');
  }

  /// Commits the staged changes. For risky packages a router-side guard is started
  /// first: if the app does not confirm in time, the router restores the previous
  /// config files itself, so a bad change cannot lock the user out.
  Future<ApplyResult> applyPending({int guardSeconds = 90, bool? guard}) async {
    final changes = await pending();
    final pkgs = <String>[];
    for (final c in changes) {
      if (isSafeName(c.pkg) && !pkgs.contains(c.pkg)) pkgs.add(c.pkg);
    }
    if (pkgs.isEmpty) {
      return ApplyResult(const [], false, 0, DateTime.now());
    }
    final risky = pkgs.any(kRiskyPackages.contains);
    final useGuard = guard ?? risky;
    final reload = _reloadFor(changes, pkgs);

    final b = StringBuffer();
    if (useGuard) {
      final restore = <String>[
        'for f in $_bakDir/*; do [ -f "\$f" ] && cp "\$f" "/etc/config/\$(basename "\$f")"; done',
        reload,
        'rm -f $_guardPid',
      ];
      final guardLines = <String>['#!/bin/sh', 'sleep $guardSeconds', 'sh $_restoreSh'];
      b.write('mkdir -p $_bakDir && rm -f $_bakDir/* && ');
      for (final p in pkgs) {
        b.write('([ -f /etc/config/$p ] && cp /etc/config/$p $_bakDir/$p; true) && ');
      }
      b.write("printf '%s\\n' ${['#!/bin/sh', ...restore].map(shq).join(' ')} > $_restoreSh && ");
      b.write("printf '%s\\n' ${guardLines.map(shq).join(' ')} > $_guardSh && ");
      b.write('chmod +x $_restoreSh $_guardSh && ');
      b.write('(sh $_guardSh >/dev/null 2>&1 </dev/null & echo \$! > $_guardPid) && ');
    }
    b.write(pkgs.map((p) => 'uci commit $p').join(' && '));
    b.write(' && ((sleep 1; $reload) >/dev/null 2>&1 </dev/null &)');
    await ssh.run(b.toString());
    return ApplyResult(pkgs, useGuard, guardSeconds, DateTime.now());
  }

  /// True while the rollback guard is still armed on the router.
  Future<bool> guardActive() async {
    final out = await ssh.run(
        '[ -f $_guardPid ] && kill -0 \$(cat $_guardPid) 2>/dev/null && echo 1 || echo 0');
    return out.trim() == '1';
  }

  /// User confirmed the new config works: disarm the guard and drop the backup.
  Future<void> confirmGuard() => ssh.run(
      'kill \$(cat $_guardPid) 2>/dev/null; rm -f $_guardPid $_guardSh $_restoreSh; rm -rf $_bakDir; true');

  /// Roll back right now instead of waiting for the timer.
  Future<void> rollbackNow() => ssh.run(
      'kill \$(cat $_guardPid) 2>/dev/null; [ -f $_restoreSh ] && (sh $_restoreSh >/dev/null 2>&1 </dev/null &); true');

  Future<bool> reachable() async {
    try {
      final out = await ssh.run('echo ok', timeout: const Duration(seconds: 6));
      return out.trim() == 'ok';
    } catch (_) {
      return false;
    }
  }
}
