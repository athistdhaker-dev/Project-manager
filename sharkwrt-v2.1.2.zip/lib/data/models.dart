class RouterProfile {
  final String id;
  final String name;
  final String host;
  final int port;
  final String user;
  final bool useKey;

  const RouterProfile({
    required this.id,
    required this.name,
    required this.host,
    this.port = 22,
    this.user = 'root',
    this.useKey = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'host': host,
        'port': port,
        'user': user,
        'useKey': useKey,
      };

  factory RouterProfile.fromJson(Map<String, dynamic> j) => RouterProfile(
        id: j['id'] as String,
        name: j['name'] as String,
        host: j['host'] as String,
        port: (j['port'] as num?)?.toInt() ?? 22,
        user: (j['user'] as String?) ?? 'root',
        useKey: (j['useKey'] as bool?) ?? false,
      );
}
