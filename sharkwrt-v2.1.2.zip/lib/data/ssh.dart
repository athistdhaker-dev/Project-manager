import 'dart:async';
import 'dart:convert';

import 'package:dartssh2/dartssh2.dart';

import '../core/strings.dart';
import 'models.dart';
import 'store.dart';

class SshException implements Exception {
  final String message;
  SshException(this.message);
  @override
  String toString() => message;
}

class SshSession {
  final RouterProfile profile;
  final String? password;
  final String? privateKey;
  final Store store;
  SSHClient? _client;
  bool _hostKeyMismatch = false;

  SshSession({
    required this.profile,
    required this.password,
    required this.privateKey,
    required this.store,
  });

  bool get connected => _client != null;

  Future<void> connect() async {
    await close();
    _hostKeyMismatch = false;
    try {
      final socket = await SSHSocket.connect(
        profile.host,
        profile.port,
        timeout: const Duration(seconds: 8),
      );
      final client = SSHClient(
        socket,
        username: profile.user,
        onPasswordRequest: () => password ?? '',
        identities: (profile.useKey && privateKey != null)
            ? SSHKeyPair.fromPem(privateKey!)
            : null,
        onVerifyHostKey: (type, fingerprint) async {
          final fp = fingerprint
              .map((b) => b.toRadixString(16).padLeft(2, '0'))
              .join(':');
          final saved = store.fingerprint(profile.id);
          if (saved == null) {
            await store.setFingerprint(profile.id, fp);
            return true;
          }
          if (saved == fp) return true;
          _hostKeyMismatch = true;
          return false;
        },
        keepAliveInterval: const Duration(seconds: 10),
      );
      await client.authenticated;
      _client = client;
      unawaited(client.done.then((_) {
        if (identical(_client, client)) _client = null;
      }).catchError((Object _) {
        if (identical(_client, client)) _client = null;
      }));
    } catch (e) {
      if (_hostKeyMismatch) throw SshException(S.sshHostKeyChanged);
      final m = e.toString();
      if (m.contains('Auth') || m.contains('auth')) {
        throw SshException(S.sshAuthFailed);
      }
      if (e is TimeoutException || m.contains('Timeout')) {
        throw SshException(S.sshTimeout);
      }
      throw SshException('Could not connect: $m');
    }
  }

  Future<String> run(String cmd,
      {Duration timeout = const Duration(seconds: 25)}) async {
    if (_client == null) await connect();
    final c = _client;
    if (c == null) throw SshException(S.sshNotConnected);
    try {
      final bytes = await c.run(cmd).timeout(timeout);
      return utf8.decode(bytes, allowMalformed: true);
    } on TimeoutException {
      throw SshException(S.sshRouterSlow);
    } catch (e) {
      if (e is SshException) rethrow;
      _client = null;
      throw SshException('${S.sshDropped}: $e');
    }
  }

  /// Opens an interactive PTY shell (its own channel on the shared connection).
  Future<SSHSession> openShell(int cols, int rows) async {
    if (_client == null) await connect();
    final c = _client;
    if (c == null) throw SshException(S.sshNotConnected);
    return c.shell(
      pty: SSHPtyConfig(type: 'xterm-256color', width: cols, height: rows),
    );
  }

  Future<void> close() async {
    try {
      _client?.close();
    } catch (_) {}
    _client = null;
  }
}
