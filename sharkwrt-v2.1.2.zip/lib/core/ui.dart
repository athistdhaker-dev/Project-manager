import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import 'strings.dart';
import 'theme.dart';

// ======================================================================
// Backdrop and page frames
// ======================================================================

/// Solid base colour with one soft accent glow in the top-right corner.
class AppBackdrop extends StatelessWidget {
  final Widget child;
  const AppBackdrop({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    return Container(
      color: t.bg,
      child: Stack(
        children: [
          Positioned(
            top: -160,
            right: -120,
            child: IgnorePointer(
              child: Container(
                width: 460,
                height: 460,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      s.accent.withAlpha(t.dark ? 46 : 34),
                      s.accent.withAlpha(0),
                    ],
                  ),
                ),
              ),
            ),
          ),
          child,
        ],
      ),
    );
  }
}

/// Older name, kept so existing screens keep compiling.
class GlassBackground extends StatelessWidget {
  final Widget child;
  const GlassBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) => AppBackdrop(child: child);
}

class CircleBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final String? tooltip;
  final Color? color;
  const CircleBtn({
    super.key,
    required this.icon,
    required this.onTap,
    this.tooltip,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    final w = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: t.surface,
          shape: BoxShape.circle,
          border: Border.all(color: t.outline),
        ),
        child: Icon(icon, size: 20, color: color ?? t.text),
      ),
    );
    return tooltip == null ? w : Tooltip(message: tooltip!, child: w);
  }
}

/// A pushed page: circular back button, big title, optional actions.
class SubPage extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget body;
  final List<Widget>? actions;
  final Widget? fab;
  final bool canPop;
  const SubPage({
    super.key,
    required this.title,
    required this.body,
    this.subtitle,
    this.actions,
    this.fab,
    this.canPop = true,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    return AppBackdrop(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        floatingActionButton: fab,
        body: SafeArea(
          bottom: false,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
                child: Row(
                  children: [
                    if (canPop && Navigator.of(context).canPop())
                      Padding(
                        padding: const EdgeInsets.only(right: 12),
                        child: CircleBtn(
                          icon: Icons.arrow_back_rounded,
                          onTap: () => Navigator.of(context).maybePop(),
                        ),
                      ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -0.4,
                            ),
                          ),
                          if (subtitle != null)
                            Text(
                              subtitle!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: t.sub, fontSize: 12),
                            ),
                        ],
                      ),
                    ),
                    if (actions != null) ...actions!,
                  ],
                ),
              ),
              Expanded(child: body),
            ],
          ),
        ),
      ),
    );
  }
}

/// Older name for SubPage.
class GlassScaffold extends StatelessWidget {
  final String title;
  final Widget body;
  final List<Widget>? actions;
  final Widget? fab;
  const GlassScaffold({
    super.key,
    required this.title,
    required this.body,
    this.actions,
    this.fab,
  });

  @override
  Widget build(BuildContext context) =>
      SubPage(title: title, body: body, actions: actions, fab: fab);
}

/// Big heading used at the top of the main tabs (no app bar).
class TabHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final List<Widget>? actions;
  const TabHeader({super.key, required this.title, this.subtitle, this.actions});

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 16, 8),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.8,
                  ),
                ),
                if (subtitle != null)
                  Text(subtitle!, style: TextStyle(color: t.sub, fontSize: 13)),
              ],
            ),
          ),
          if (actions != null) ...actions!,
        ],
      ),
    );
  }
}

// ======================================================================
// Tiles
// ======================================================================

class Tile extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final bool accent;
  final Color? tint;
  final double radius;
  const Tile({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.onTap,
    this.onLongPress,
    this.accent = false,
    this.tint,
    this.radius = 26,
  });

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    final tintColor = tint ?? (accent ? s.accent : null);
    final fill = tintColor == null
        ? t.surface
        : Color.alphaBlend(tintColor.withAlpha(t.dark ? 30 : 36), t.surface);
    final line = tintColor == null ? t.outline : tintColor.withAlpha(110);
    final r = BorderRadius.circular(radius);
    return Material(
      color: fill,
      shape: RoundedRectangleBorder(borderRadius: r, side: BorderSide(color: line)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        child: Padding(padding: padding, child: child),
      ),
    );
  }
}

/// Older name: a tile with a bottom gap, used in vertical lists.
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: SizedBox(
        width: double.infinity,
        child: Tile(
          padding: padding,
          onTap: onTap,
          onLongPress: onLongPress,
          child: child,
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionTitle(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(6, 14, 6, 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              text.toUpperCase(),
              style: TextStyle(
                color: t.sub,
                fontSize: 11.5,
                letterSpacing: 1.4,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

class Pill extends StatelessWidget {
  final String label;
  final Color color;
  const Pill(this.label, this.color, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(
        color: color.withAlpha(40),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w800),
      ),
    );
  }
}

class StatusDot extends StatelessWidget {
  final bool up;
  const StatusDot({super.key, required this.up});

  @override
  Widget build(BuildContext context) {
    final c = up ? kGood : kBad;
    return Container(
      width: 9,
      height: 9,
      decoration: BoxDecoration(
        color: c,
        shape: BoxShape.circle,
        boxShadow: [BoxShadow(color: c.withAlpha(120), blurRadius: 8)],
      ),
    );
  }
}

class ErrorBox extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  const ErrorBox(this.message, {super.key, this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_rounded, size: 44, color: kBad),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            if (onRetry != null) ...[
              const SizedBox(height: 14),
              FilledButton.tonal(onPressed: onRetry, child: const Text(S.retry)),
            ],
          ],
        ),
      ),
    );
  }
}

/// Shown when a feature needs a package/tool the router does not have.
class NotAvailable extends StatelessWidget {
  final String what;
  final String? hint;
  const NotAvailable(this.what, {super.key, this.hint});

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.extension_off_outlined, size: 44, color: t.sub),
            const SizedBox(height: 12),
            Text(what,
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 6),
            Text(S.notAvailable, style: TextStyle(color: t.sub)),
            if (hint != null) ...[
              const SizedBox(height: 10),
              Text(hint!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontFamily: kMono, fontSize: 12)),
            ],
          ],
        ),
      ),
    );
  }
}

class Loading extends StatelessWidget {
  const Loading({super.key});
  @override
  Widget build(BuildContext context) =>
      const Center(child: CircularProgressIndicator());
}

// ======================================================================
// Numbers, gauges and charts
// ======================================================================

class BigNumber extends StatelessWidget {
  final String value;
  final String unit;
  final Color? color;
  final double size;
  const BigNumber(this.value, {super.key, this.unit = '', this.color, this.size = 30});

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(
            text: value,
            style: TextStyle(
              fontFamily: kMono,
              fontWeight: FontWeight.w700,
              fontSize: size,
              color: color ?? t.text,
              letterSpacing: -1,
            ),
          ),
          if (unit.isNotEmpty)
            TextSpan(
              text: ' $unit',
              style: TextStyle(
                fontFamily: kMono,
                fontSize: size * 0.4,
                color: t.sub,
                fontWeight: FontWeight.w600,
              ),
            ),
        ],
      ),
    );
  }
}

class Caption extends StatelessWidget {
  final String text;
  const Caption(this.text, {super.key});
  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    return Text(
      text.toUpperCase(),
      style: TextStyle(
        color: t.sub,
        fontSize: 10.5,
        letterSpacing: 1.2,
        fontWeight: FontWeight.w800,
      ),
    );
  }
}

/// 270 degree arc gauge with the value in the middle.
class Dial extends StatelessWidget {
  final double value; // 0..1
  final String center;
  final Color color;
  final double size;
  const Dial({
    super.key,
    required this.value,
    required this.center,
    required this.color,
    this.size = 84,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _DialPainter(value.clamp(0.0, 1.0).toDouble(), color, t.outline),
        child: Center(
          child: Text(
            center,
            style: TextStyle(
              fontFamily: kMono,
              fontWeight: FontWeight.w700,
              fontSize: size * 0.22,
            ),
          ),
        ),
      ),
    );
  }
}

class _DialPainter extends CustomPainter {
  final double v;
  final Color color;
  final Color track;
  _DialPainter(this.v, this.color, this.track);

  @override
  void paint(Canvas canvas, Size size) {
    final stroke = size.width * 0.11;
    final rect = Rect.fromLTWH(stroke / 2, stroke / 2, size.width - stroke,
        size.height - stroke);
    const start = math.pi * 0.75;
    const sweep = math.pi * 1.5;
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..color = track;
    canvas.drawArc(rect, start, sweep, false, base);
    if (v > 0.001) {
      final p = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = stroke
        ..strokeCap = StrokeCap.round
        ..color = color;
      canvas.drawArc(rect, start, sweep * v, false, p);
    }
  }

  @override
  bool shouldRepaint(covariant _DialPainter old) =>
      old.v != v || old.color != color || old.track != track;
}

/// Smooth filled line chart for one or two series sharing a scale.
class AreaChart extends StatelessWidget {
  final List<double> a;
  final List<double> b;
  final Color ca;
  final Color cb;
  final double height;
  final int cap;
  const AreaChart({
    super.key,
    required this.a,
    required this.ca,
    this.b = const <double>[],
    this.cb = kWarm,
    this.height = 110,
    this.cap = 60,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    return SizedBox(
      height: height,
      width: double.infinity,
      child: RepaintBoundary(
        child: CustomPaint(
          painter: _AreaPainter(List<double>.from(a), List<double>.from(b), ca, cb,
              cap, t.outline),
        ),
      ),
    );
  }
}

class _AreaPainter extends CustomPainter {
  final List<double> a;
  final List<double> b;
  final Color ca;
  final Color cb;
  final int cap;
  final Color grid;
  _AreaPainter(this.a, this.b, this.ca, this.cb, this.cap, this.grid);

  @override
  void paint(Canvas canvas, Size size) {
    double maxV = 1;
    for (final v in a) {
      if (v > maxV) maxV = v;
    }
    for (final v in b) {
      if (v > maxV) maxV = v;
    }
    maxV *= 1.15;

    final gp = Paint()
      ..color = grid
      ..strokeWidth = 1;
    for (var i = 1; i <= 3; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gp);
    }

    void series(List<double> d, Color c) {
      if (d.length < 2) return;
      final pts = <Offset>[];
      for (var i = 0; i < d.length; i++) {
        final x = size.width * (i + (cap - d.length)) / (cap - 1);
        final y = size.height - (d[i] / maxV) * (size.height - 6) - 3;
        pts.add(Offset(x, y));
      }
      final line = Path()..moveTo(pts.first.dx, pts.first.dy);
      for (var i = 1; i < pts.length; i++) {
        final mid = Offset((pts[i - 1].dx + pts[i].dx) / 2,
            (pts[i - 1].dy + pts[i].dy) / 2);
        line.quadraticBezierTo(pts[i - 1].dx, pts[i - 1].dy, mid.dx, mid.dy);
      }
      line.lineTo(pts.last.dx, pts.last.dy);
      final fill = Path.from(line)
        ..lineTo(pts.last.dx, size.height)
        ..lineTo(pts.first.dx, size.height)
        ..close();
      canvas.drawPath(
        fill,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [c.withAlpha(80), c.withAlpha(0)],
          ).createShader(Offset.zero & size),
      );
      canvas.drawPath(
        line,
        Paint()
          ..color = c
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4
          ..strokeJoin = StrokeJoin.round
          ..strokeCap = StrokeCap.round,
      );
    }

    series(b, cb);
    series(a, ca);
  }

  @override
  bool shouldRepaint(covariant _AreaPainter old) => true;
}

/// Row of vertical bars (for a few days of usage, etc).
class MiniBars extends StatelessWidget {
  final List<double> values;
  final List<String> labels;
  final Color color;
  final double height;
  const MiniBars({
    super.key,
    required this.values,
    required this.color,
    this.labels = const <String>[],
    this.height = 64,
  });

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    var maxV = 1.0;
    for (final v in values) {
      if (v > maxV) maxV = v;
    }
    return SizedBox(
      height: height + (labels.isEmpty ? 0 : 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (var i = 0; i < values.length; i++)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      height: math.max(3.0, values[i] / maxV * height),
                      decoration: BoxDecoration(
                        color: i == values.length - 1 ? color : color.withAlpha(110),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                    if (labels.length == values.length)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(labels[i],
                            style: TextStyle(color: t.sub, fontSize: 9.5)),
                      ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ======================================================================
// Toggle tile and grouped settings rows
// ======================================================================

class ToggleTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool>? onChanged;
  final Color? color;
  const ToggleTile({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final c = color ?? s.accent;
    return Tile(
      padding: const EdgeInsets.fromLTRB(16, 14, 10, 14),
      tint: value ? c : null,
      onTap: onChanged == null ? null : () => onChanged!(!value),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: value ? c : s.theme.sub),
              const Spacer(),
              Switch(value: value, onChanged: onChanged),
            ],
          ),
          const SizedBox(height: 6),
          Text(title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          Text(subtitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: s.theme.sub, fontSize: 12)),
        ],
      ),
    );
  }
}

/// A rounded group that holds SettingRow items separated by hairlines.
class InsetGroup extends StatelessWidget {
  final String? title;
  final List<Widget> children;
  const InsetGroup({super.key, this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    final rows = <Widget>[];
    for (var i = 0; i < children.length; i++) {
      rows.add(children[i]);
      if (i != children.length - 1) {
        rows.add(Divider(height: 1, indent: 64, color: t.outline));
      }
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (title != null) SectionTitle(title!),
        Container(
          decoration: BoxDecoration(
            color: t.surface,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: t.outline),
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(children: rows),
        ),
        const SizedBox(height: 8),
      ],
    );
  }
}

class SettingRow extends StatelessWidget {
  final IconData icon;
  final Color? color;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  const SettingRow({
    super.key,
    required this.icon,
    required this.title,
    this.color,
    this.subtitle,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final c = color ?? s.accent;
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: c.withAlpha(38),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, size: 20, color: c),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 15)),
                  if (subtitle != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 1),
                      child: Text(subtitle!,
                          style: TextStyle(color: s.theme.sub, fontSize: 12)),
                    ),
                ],
              ),
            ),
            if (trailing != null)
              trailing!
            else if (onTap != null)
              Icon(Icons.chevron_right_rounded, color: s.theme.sub),
          ],
        ),
      ),
    );
  }
}

// ======================================================================
// Hold button
// ======================================================================

class HoldButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onConfirmed;
  const HoldButton({
    super.key,
    required this.label,
    required this.icon,
    required this.color,
    required this.onConfirmed,
  });

  @override
  State<HoldButton> createState() => _HoldButtonState();
}

class _HoldButtonState extends State<HoldButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1400));
    _c.addStatusListener((st) {
      if (st == AnimationStatus.completed) {
        widget.onConfirmed();
        _c.value = 0;
      }
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _c.forward(),
      onTapUp: (_) => _c.reverse(),
      onTapCancel: () => _c.reverse(),
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          return Container(
            height: 54,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(27),
              border: Border.all(color: widget.color.withAlpha(150)),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(26),
              child: Stack(
                children: [
                  Positioned.fill(
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: _c.value,
                      child: Container(color: widget.color.withAlpha(120)),
                    ),
                  ),
                  Center(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(widget.icon, color: widget.color, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          widget.label,
                          style: TextStyle(
                            color: widget.color,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ======================================================================
// Helpers
// ======================================================================

void showMsg(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

Future<bool> confirmDialog(BuildContext context, String title, String message,
    {String ok = S.yes}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text(S.cancel)),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ok)),
      ],
    ),
  );
  return r ?? false;
}

Future<String?> askText(BuildContext context, String title,
    {String initial = '',
    String? hint,
    bool obscure = false,
    TextInputType? keyboard}) {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: c,
        autofocus: true,
        obscureText: obscure,
        keyboardType: keyboard,
        decoration: InputDecoration(hintText: hint),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: const Text(S.cancel)),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text(S.ok)),
      ],
    ),
  );
}

String fmtRate(double bytesPerSec) {
  final bits = bytesPerSec * 8;
  if (bits >= 1e9) return '${(bits / 1e9).toStringAsFixed(2)} Gbps';
  if (bits >= 1e6) return '${(bits / 1e6).toStringAsFixed(1)} Mbps';
  if (bits >= 1e3) return '${(bits / 1e3).toStringAsFixed(0)} Kbps';
  return '${bits.toStringAsFixed(0)} bps';
}

/// Splits a rate into number and unit for BigNumber.
(String, String) rateParts(double bytesPerSec) {
  final bits = bytesPerSec * 8;
  if (bits >= 1e9) return ((bits / 1e9).toStringAsFixed(2), 'Gbps');
  if (bits >= 1e6) return ((bits / 1e6).toStringAsFixed(1), 'Mbps');
  if (bits >= 1e3) return ((bits / 1e3).toStringAsFixed(0), 'Kbps');
  return (bits.toStringAsFixed(0), 'bps');
}

String fmtKb(int kb) {
  if (kb >= 1048576) return '${(kb / 1048576).toStringAsFixed(1)} GB';
  if (kb >= 1024) return '${(kb / 1024).toStringAsFixed(0)} MB';
  return '$kb kB';
}

String fmtBytes(num b) {
  if (b >= 1099511627776) return '${(b / 1099511627776).toStringAsFixed(2)} TB';
  if (b >= 1073741824) return '${(b / 1073741824).toStringAsFixed(2)} GB';
  if (b >= 1048576) return '${(b / 1048576).toStringAsFixed(1)} MB';
  if (b >= 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
  return '${b.toStringAsFixed(0)} B';
}

String fmtUptime(double secs) {
  final s = secs.toInt();
  final d = s ~/ 86400;
  final h = (s % 86400) ~/ 3600;
  final m = (s % 3600) ~/ 60;
  if (d > 0) return '${d}d ${h}h ${m}m';
  if (h > 0) return '${h}h ${m}m';
  return '${m}m';
}
