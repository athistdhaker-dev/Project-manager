/// Shell-quote a value for use inside a single-quoted ash string.
String shq(String s) => "'${s.replaceAll("'", "'\\''")}'";

class UciSection {
  final String name;
  final String type;
  final Map<String, String> opts = {};
  UciSection(this.name, this.type);
  String? o(String k) => opts[k];
}

class UciConfig {
  final Map<String, UciSection> sections = {};
  Iterable<UciSection> ofType(String t) =>
      sections.values.where((s) => s.type == t);
  UciSection? operator [](String n) => sections[n];
}

String _unquote(String v) {
  var s = v.trim();
  if (s.length >= 2 && s.startsWith("'") && s.endsWith("'")) {
    s = s.substring(1, s.length - 1);
    // list values look like: a' 'b
    return s.split("' '").map((e) => e.replaceAll("'\\''", "'")).join(' ');
  }
  return s;
}

/// Parses the output of `uci show <config>`.
UciConfig parseUciShow(String out) {
  final cfg = UciConfig();
  for (final raw in out.split('\n')) {
    final line = raw.trimRight();
    if (line.isEmpty) continue;
    final eq = line.indexOf('=');
    if (eq < 0) continue;
    final key = line.substring(0, eq);
    final val = line.substring(eq + 1);
    final parts = key.split('.');
    if (parts.length == 2) {
      cfg.sections[parts[1]] = UciSection(parts[1], _unquote(val));
    } else if (parts.length >= 3) {
      final sec = cfg.sections[parts[1]];
      if (sec == null) continue;
      sec.opts[parts.sublist(2).join('.')] = _unquote(val);
    }
  }
  return cfg;
}

final RegExp _safeName = RegExp(r'^[A-Za-z0-9_@\[\]\-]+$');
final RegExp _macRe = RegExp(r'^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$');

final RegExp _ipv4 = RegExp(r'^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$');

bool isIpv4(String s) {
  final m = _ipv4.firstMatch(s);
  if (m == null) return false;
  for (var i = 1; i <= 4; i++) {
    if (int.parse(m.group(i)!) > 255) return false;
  }
  return true;
}

/// Same as shq; the name used in the engineering notes.
String shQuote(String s) => shq(s);

bool isSafeName(String s) => _safeName.hasMatch(s);
bool isMac(String s) => _macRe.hasMatch(s);
