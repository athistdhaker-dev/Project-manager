/// Tiny vendor table. Most phones use randomized (private) MAC addresses, which are
/// detected from the "locally administered" bit; the table only covers common
/// hobby / IoT / virtual-machine makers, so many devices will show no vendor.
const Map<String, String> _oui = {
  'B8:27:EB': 'Raspberry Pi',
  'DC:A6:32': 'Raspberry Pi',
  'E4:5F:01': 'Raspberry Pi',
  '00:50:56': 'VMware',
  '00:0C:29': 'VMware',
  '00:05:69': 'VMware',
  '08:00:27': 'VirtualBox',
  '52:54:00': 'QEMU / KVM',
  '00:16:3E': 'Xen',
  '00:15:5D': 'Hyper-V',
  '00:15:6D': 'Ubiquiti',
  '00:27:22': 'Ubiquiti',
  '24:A4:3C': 'Ubiquiti',
  '44:D9:E7': 'Ubiquiti',
  '68:72:51': 'Ubiquiti',
  '78:8A:20': 'Ubiquiti',
  '80:2A:A8': 'Ubiquiti',
  'B4:FB:E4': 'Ubiquiti',
  'DC:9F:DB': 'Ubiquiti',
  'F0:9F:C2': 'Ubiquiti',
  'FC:EC:DA': 'Ubiquiti',
  '24:0A:C4': 'Espressif (ESP32/ESP8266)',
  '24:6F:28': 'Espressif (ESP32/ESP8266)',
  '30:AE:A4': 'Espressif (ESP32/ESP8266)',
  '3C:71:BF': 'Espressif (ESP32/ESP8266)',
  '5C:CF:7F': 'Espressif (ESP32/ESP8266)',
  '60:01:94': 'Espressif (ESP32/ESP8266)',
  '7C:9E:BD': 'Espressif (ESP32/ESP8266)',
  '84:0D:8E': 'Espressif (ESP32/ESP8266)',
  '84:F3:EB': 'Espressif (ESP32/ESP8266)',
  '8C:AA:B5': 'Espressif (ESP32/ESP8266)',
  '9C:9C:1F': 'Espressif (ESP32/ESP8266)',
  'A4:CF:12': 'Espressif (ESP32/ESP8266)',
  'AC:67:B2': 'Espressif (ESP32/ESP8266)',
  'B4:E6:2D': 'Espressif (ESP32/ESP8266)',
  'BC:DD:C2': 'Espressif (ESP32/ESP8266)',
  'C4:4F:33': 'Espressif (ESP32/ESP8266)',
  'CC:50:E3': 'Espressif (ESP32/ESP8266)',
  'DC:4F:22': 'Espressif (ESP32/ESP8266)',
  'E8:68:E7': 'Espressif (ESP32/ESP8266)',
  'E8:DB:84': 'Espressif (ESP32/ESP8266)',
  'EC:FA:BC': 'Espressif (ESP32/ESP8266)',
  'F4:CF:A2': 'Espressif (ESP32/ESP8266)',
  '50:C7:BF': 'TP-Link',
  '98:DA:C4': 'TP-Link',
  '14:CC:20': 'TP-Link',
  '60:E3:27': 'TP-Link',
  'EC:08:6B': 'TP-Link',
  'F4:F2:6D': 'TP-Link',
  'A4:2B:B0': 'TP-Link',
  '18:D6:C7': 'TP-Link',
  'C0:25:E9': 'TP-Link',
  '30:B5:C2': 'TP-Link',
  '54:C8:0F': 'TP-Link',
};

/// True when the address is locally administered, i.e. randomized by the phone.
bool isPrivateMac(String mac) {
  if (mac.length < 2) return false;
  final first = int.tryParse(mac.substring(0, 2), radix: 16);
  if (first == null) return false;
  return (first & 0x02) != 0;
}

/// Vendor name, 'Private address' for randomized MACs, or '' when unknown.
String vendorOf(String mac) {
  final m = mac.toUpperCase();
  if (m.length >= 8) {
    final v = _oui[m.substring(0, 8)];
    if (v != null) return v;
  }
  if (isPrivateMac(m)) return 'Private address';
  return '';
}
