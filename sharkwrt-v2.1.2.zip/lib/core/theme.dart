import 'package:flutter/material.dart';

/// Font used for big numerals and terminal-like text.
const String kMono = 'DejaVuSansMono';

class SharkTheme {
  final String name;
  final bool dark;
  final Color bg;
  final Color surface;
  final Color surface2;
  final Color outline;
  final Color text;
  final Color sub;
  const SharkTheme({
    required this.name,
    required this.dark,
    required this.bg,
    required this.surface,
    required this.surface2,
    required this.outline,
    required this.text,
    required this.sub,
  });

  // Names used by older screens.
  Color get panel => surface;
  Color get border => outline;
}

const List<SharkTheme> kThemes = [
  SharkTheme(
    name: 'Ink',
    dark: true,
    bg: Color(0xFF07080B),
    surface: Color(0xFF111318),
    surface2: Color(0xFF1A1D25),
    outline: Color(0xFF262A34),
    text: Color(0xFFF2F4F8),
    sub: Color(0xFF8B93A1),
  ),
  SharkTheme(
    name: 'Dusk',
    dark: true,
    bg: Color(0xFF0C0A1D),
    surface: Color(0xFF15122C),
    surface2: Color(0xFF1E1A3D),
    outline: Color(0xFF2E2959),
    text: Color(0xFFF0EEFF),
    sub: Color(0xFF9892C4),
  ),
  SharkTheme(
    name: 'Sand',
    dark: false,
    bg: Color(0xFFF3EEE4),
    surface: Color(0xFFFBF8F2),
    surface2: Color(0xFFEDE5D6),
    outline: Color(0xFFDDD3BF),
    text: Color(0xFF1E1A14),
    sub: Color(0xFF7A705F),
  ),
  SharkTheme(
    name: 'Mint',
    dark: false,
    bg: Color(0xFFE8F2F0),
    surface: Color(0xFFF7FCFB),
    surface2: Color(0xFFDAEAE6),
    outline: Color(0xFFC3D9D3),
    text: Color(0xFF0F2420),
    sub: Color(0xFF55766F),
  ),
];

const List<Color> kAccents = [
  Color(0xFF4D8DFF),
  Color(0xFF14C8B0),
  Color(0xFF8B7CFF),
  Color(0xFFFF6B5B),
  Color(0xFFFFB020),
  Color(0xFF8FD14F),
  Color(0xFFFF5FA2),
  Color(0xFF22C3EE),
];

const List<String> kAccentNames = [
  'Blue',
  'Teal',
  'Violet',
  'Coral',
  'Amber',
  'Lime',
  'Pink',
  'Cyan',
];

/// Secondary series colour used next to the accent (e.g. upload next to download).
const Color kWarm = Color(0xFFFFB020);
const Color kGood = Color(0xFF3DDC97);
const Color kBad = Color(0xFFFF5D6C);

ThemeData buildTheme(SharkTheme t, Color accent) {
  final brightness = t.dark ? Brightness.dark : Brightness.light;
  final scheme = ColorScheme.fromSeed(
    seedColor: accent,
    brightness: brightness,
  ).copyWith(
    primary: accent,
    surface: t.surface,
    onSurface: t.text,
    surfaceContainerHigh: t.surface2,
    surfaceContainerHighest: t.surface2,
    outline: t.outline,
    outlineVariant: t.outline,
  );
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    brightness: brightness,
  );
  return base.copyWith(
    scaffoldBackgroundColor: Colors.transparent,
    textTheme: base.textTheme.apply(bodyColor: t.text, displayColor: t.text),
    iconTheme: IconThemeData(color: t.text),
    dividerColor: t.outline,
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: t.surface2,
      surfaceTintColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: t.surface2,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: t.surface2,
      contentTextStyle: TextStyle(color: t.text),
    ),
  );
}
