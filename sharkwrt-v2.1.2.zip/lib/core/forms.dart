import 'package:flutter/material.dart';

class FField {
  final String label;
  final String initial;
  final bool obscure;
  final TextInputType? keyboard;
  const FField(this.label,
      [this.initial = '', this.obscure = false, this.keyboard]);
}

/// Simple multi-field dialog. Returns the trimmed values, or null on cancel.
Future<List<String>?> askForm(
  BuildContext context,
  String title,
  List<FField> fields, {
  String ok = 'Save',
  String? note,
}) {
  final cs = [for (final f in fields) TextEditingController(text: f.initial)];
  return showDialog<List<String>>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (note != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(note, style: const TextStyle(fontSize: 13)),
              ),
            for (var i = 0; i < fields.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: TextField(
                  controller: cs[i],
                  obscureText: fields[i].obscure,
                  keyboardType: fields[i].keyboard,
                  decoration: InputDecoration(labelText: fields[i].label),
                ),
              ),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, [for (final c in cs) c.text.trim()]),
          child: Text(ok),
        ),
      ],
    ),
  );
}

// ---------------------------------------------------------------------------
// Bottom-sheet form with text, dropdown and switch rows.
// ---------------------------------------------------------------------------

abstract class FItem {
  final String key;
  final String label;
  const FItem(this.key, this.label);
}

class FText extends FItem {
  final String initial;
  final String? hint;
  final bool obscure;
  final TextInputType? keyboard;
  final int lines;
  const FText(super.key, super.label,
      {this.initial = '', this.hint, this.obscure = false, this.keyboard, this.lines = 1});
}

class FPick extends FItem {
  final List<(String, String)> options; // (value, label)
  final String initial;
  const FPick(super.key, super.label, this.options, {this.initial = ''});
}

class FSwitch extends FItem {
  final bool initial;
  const FSwitch(super.key, super.label, {this.initial = false});
}

class FNote extends FItem {
  const FNote(String text) : super('', text);
}

extension FormValues on Map<String, Object> {
  String s(String k) => (this[k] as String?) ?? '';
  bool b(String k) => (this[k] as bool?) ?? false;
}

/// Returns the entered values keyed by FItem.key, or null when cancelled.
Future<Map<String, Object>?> showForm(
  BuildContext context,
  String title,
  List<FItem> items, {
  String ok = 'Save',
}) {
  return showModalBottomSheet<Map<String, Object>>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => _FormSheet(title: title, items: items, ok: ok),
  );
}

class _FormSheet extends StatefulWidget {
  final String title;
  final List<FItem> items;
  final String ok;
  const _FormSheet({required this.title, required this.items, required this.ok});

  @override
  State<_FormSheet> createState() => _FormSheetState();
}

class _FormSheetState extends State<_FormSheet> {
  final Map<String, TextEditingController> _c = {};
  final Map<String, Object> _v = {};

  @override
  void initState() {
    super.initState();
    for (final i in widget.items) {
      if (i is FText) {
        _c[i.key] = TextEditingController(text: i.initial);
      } else if (i is FPick) {
        _v[i.key] = i.options.any((o) => o.$1 == i.initial)
            ? i.initial
            : (i.options.isEmpty ? '' : i.options.first.$1);
      } else if (i is FSwitch) {
        _v[i.key] = i.initial;
      }
    }
  }

  @override
  void dispose() {
    for (final c in _c.values) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, 16 + bottom),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.title,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 14),
              for (final i in widget.items) _row(i),
              const SizedBox(height: 6),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel')),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: () {
                      final out = <String, Object>{..._v};
                      _c.forEach((k, c) => out[k] = c.text.trim());
                      Navigator.pop(context, out);
                    },
                    child: Text(widget.ok),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _row(FItem i) {
    if (i is FNote) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Text(i.label, style: const TextStyle(fontSize: 13)),
      );
    }
    if (i is FText) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: _c[i.key],
          obscureText: i.obscure,
          keyboardType: i.keyboard,
          minLines: i.lines,
          maxLines: i.obscure ? 1 : i.lines,
          decoration: InputDecoration(labelText: i.label, hintText: i.hint),
        ),
      );
    }
    if (i is FPick) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: DropdownButtonFormField<String>(
          value: _v[i.key] as String?, // ignore: deprecated_member_use
          isExpanded: true,
          decoration: InputDecoration(labelText: i.label),
          items: [
            for (final o in i.options)
              DropdownMenuItem(value: o.$1, child: Text(o.$2, overflow: TextOverflow.ellipsis)),
          ],
          onChanged: (v) => setState(() => _v[i.key] = v ?? ''),
        ),
      );
    }
    if (i is FSwitch) {
      return SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: Text(i.label),
        value: (_v[i.key] as bool?) ?? false,
        onChanged: (v) => setState(() => _v[i.key] = v),
      );
    }
    return const SizedBox.shrink();
  }
}
