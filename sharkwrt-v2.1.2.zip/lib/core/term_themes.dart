import 'package:flutter/material.dart';
import 'package:xterm/xterm.dart';

import 'theme.dart';

const List<String> kTermSchemes = [
  'Match app',
  'Classic',
  'Solarized Dark',
  'Dracula',
  'Light',
];

Color _c(int rgb) => Color(0xFF000000 | rgb);

TerminalTheme _build({
  required int bg,
  required int fg,
  required Color cursor,
  required Color selection,
  required List<int> ansi,
}) {
  return TerminalTheme(
    cursor: cursor,
    selection: selection,
    foreground: _c(fg),
    background: _c(bg),
    black: _c(ansi[0]),
    red: _c(ansi[1]),
    green: _c(ansi[2]),
    yellow: _c(ansi[3]),
    blue: _c(ansi[4]),
    magenta: _c(ansi[5]),
    cyan: _c(ansi[6]),
    white: _c(ansi[7]),
    brightBlack: _c(ansi[8]),
    brightRed: _c(ansi[9]),
    brightGreen: _c(ansi[10]),
    brightYellow: _c(ansi[11]),
    brightBlue: _c(ansi[12]),
    brightMagenta: _c(ansi[13]),
    brightCyan: _c(ansi[14]),
    brightWhite: _c(ansi[15]),
    searchHitBackground: const Color(0xFFFFFF2B),
    searchHitBackgroundCurrent: const Color(0xFF31FF26),
    searchHitForeground: const Color(0xFF000000),
  );
}

const List<int> _classic = [
  0x000000, 0xCD3131, 0x0DBC79, 0xE5E510, 0x2472C8, 0xBC3FBC, 0x11A8CD, 0xE5E5E5,
  0x666666, 0xF14C4C, 0x23D18B, 0xF5F543, 0x3B8EEA, 0xD670D6, 0x29B8DB, 0xFFFFFF,
];
const List<int> _solarized = [
  0x073642, 0xDC322F, 0x859900, 0xB58900, 0x268BD2, 0xD33682, 0x2AA198, 0xEEE8D5,
  0x002B36, 0xCB4B16, 0x586E75, 0x657B83, 0x839496, 0x6C71C4, 0x93A1A1, 0xFDF6E3,
];
const List<int> _dracula = [
  0x21222C, 0xFF5555, 0x50FA7B, 0xF1FA8C, 0xBD93F9, 0xFF79C6, 0x8BE9FD, 0xF8F8F2,
  0x6272A4, 0xFF6E6E, 0x69FF94, 0xFFFFA5, 0xD6ACFF, 0xFF92DF, 0xA4FFFF, 0xFFFFFF,
];
const List<int> _light = [
  0x383A42, 0xE45649, 0x50A14F, 0xC18401, 0x4078F2, 0xA626A4, 0x0184BC, 0xA0A1A7,
  0x4F525E, 0xDE3E35, 0x3F953A, 0xD2B67C, 0x4078F2, 0xA626A4, 0x0184BC, 0x696C77,
];

TerminalTheme buildTermTheme(int scheme, SharkTheme app, Color accent) {
  switch (scheme) {
    case 1:
      return _build(
        bg: 0x000000,
        fg: 0xE5E5E5,
        cursor: const Color(0xFFE5E5E5),
        selection: const Color(0x663B8EEA),
        ansi: _classic,
      );
    case 2:
      return _build(
        bg: 0x002B36,
        fg: 0x839496,
        cursor: const Color(0xFF93A1A1),
        selection: const Color(0x66268BD2),
        ansi: _solarized,
      );
    case 3:
      return _build(
        bg: 0x282A36,
        fg: 0xF8F8F2,
        cursor: const Color(0xFFF8F8F2),
        selection: const Color(0x66BD93F9),
        ansi: _dracula,
      );
    case 4:
      return _build(
        bg: 0xFAFAFA,
        fg: 0x383A42,
        cursor: const Color(0xFF383A42),
        selection: const Color(0x664078F2),
        ansi: _light,
      );
    default:
      if (app.dark) {
        return _build(
          bg: 0x060A12,
          fg: 0xE6EAF2,
          cursor: accent,
          selection: accent.withAlpha(90),
          ansi: _classic,
        );
      }
      return _build(
        bg: 0xFBFCFE,
        fg: 0x1F2430,
        cursor: accent,
        selection: accent.withAlpha(70),
        ansi: _light,
      );
  }
}
