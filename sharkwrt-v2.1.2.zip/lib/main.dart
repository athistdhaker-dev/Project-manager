import 'dart:async';

import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:provider/provider.dart';

import 'core/strings.dart';
import 'core/theme.dart';
import 'screens/router_list.dart';
import 'state/app_state.dart';

Future<void> main() async {
  runZonedGuarded(_boot, (e, st) => _showFatal(e, st));
}

Future<void> _boot() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Show errors on screen instead of a silent grey/blank screen.
  ErrorWidget.builder = (d) => Material(
        color: const Color(0xFF111111),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: SafeArea(
            child: Text('${d.exception}\n\n${d.stack}',
                style: const TextStyle(color: Colors.white70, fontSize: 11)),
          ),
        ),
      );
  final state = AppState();
  try {
    await state.init().timeout(const Duration(seconds: 10));
  } catch (e, st) {
    // Stored settings may be unreadable (e.g. after an update): start with defaults.
    debugPrint('init failed: $e\n$st');
  }
  runApp(ChangeNotifierProvider<AppState>.value(
    value: state,
    child: const SharkApp(),
  ));
}

void _showFatal(Object e, StackTrace st) {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      backgroundColor: const Color(0xFF111111),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Text('SharkWRT failed to start\n\n$e\n\n$st',
              style: const TextStyle(color: Colors.white70, fontSize: 11)),
        ),
      ),
    ),
  ));
}

class SharkApp extends StatelessWidget {
  const SharkApp({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return MaterialApp(
      title: 'SharkWRT',
      navigatorKey: s.navKey,
      debugShowCheckedModeBanner: false,
      theme: buildTheme(s.theme, s.accent),
      builder: (context, child) => LockGate(child: child ?? const SizedBox.shrink()),
      home: const RouterListScreen(),
    );
  }
}

/// Asks for biometrics / device PIN at launch and when returning from background.
class LockGate extends StatefulWidget {
  final Widget child;
  const LockGate({super.key, required this.child});

  @override
  State<LockGate> createState() => _LockGateState();
}

class _LockGateState extends State<LockGate> with WidgetsBindingObserver {
  bool _locked = false;
  bool _asking = false;
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final s = context.read<AppState>();
    if (s.bioLock) {
      _locked = true;
      WidgetsBinding.instance.addPostFrameCallback((_) => _unlock());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final s = context.read<AppState>();
    if (!s.bioLock) return;
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed && !_asking) {
      final p = _pausedAt;
      if (p != null && DateTime.now().difference(p).inSeconds > 20) {
        setState(() => _locked = true);
        _unlock();
      }
    }
  }

  Future<void> _unlock() async {
    if (_asking) return;
    _asking = true;
    try {
      final ok = await LocalAuthentication().authenticate(localizedReason: S.bioReason);
      if (ok && mounted) setState(() => _locked = false);
    } catch (_) {
      // sensors missing or an error: do not trap the user behind the lock
      if (mounted) setState(() => _locked = false);
    } finally {
      _asking = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_locked) return widget.child;
    final t = context.watch<AppState>().theme;
    // keep the app mounted underneath so navigation state survives the lock
    return Stack(
      children: [
        widget.child,
        Positioned.fill(
          child: Container(
            color: t.bg,
            alignment: Alignment.center,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.lock_rounded, size: 56),
                const SizedBox(height: 16),
                Material(
                  color: Colors.transparent,
                  child: FilledButton(onPressed: _unlock, child: const Text(S.unlock)),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
