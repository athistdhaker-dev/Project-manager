import '../core/strings.dart';
import '../core/uci.dart';
import 'api_models.dart';
import 'api_util.dart';
import 'router_api.dart';
import 'ssh.dart';

const List<String> kFwTargets = ['ACCEPT', 'REJECT', 'DROP'];
const List<String> kFwPolicies = ['ACCEPT', 'REJECT', 'DROP'];

class FwZone {
  final String section;
  final String name;
  final String input;
  final String output;
  final String forward;
  final bool masq;
  final bool mtuFix;
  final String networks;
  const FwZone(this.section, this.name, this.input, this.output, this.forward,
      this.masq, this.mtuFix, this.networks);
}

class FwRule {
  final String section;
  final String name;
  final String src;
  final String dest;
  final String proto;
  final String srcIp;
  final String destIp;
  final String destPort;
  final String target;
  final bool enabled;
  final bool mine; // created by this app
  const FwRule(this.section, this.name, this.src, this.dest, this.proto,
      this.srcIp, this.destIp, this.destPort, this.target, this.enabled, this.mine);
}

class FwRedirect {
  final String section;
  final String name;
  final String src;
  final String dest;
  final String proto;
  final String srcDport;
  final String destIp;
  final String destPort;
  final bool enabled;
  final bool isDmz;
  const FwRedirect(this.section, this.name, this.src, this.dest, this.proto,
      this.srcDport, this.destIp, this.destPort, this.enabled, this.isDmz);
}

class FwDefaults {
  final bool synFlood;
  final bool dropInvalid;
  final bool flowOffload;
  final bool flowOffloadHw;
  const FwDefaults(
      {this.synFlood = false,
      this.dropInvalid = false,
      this.flowOffload = false,
      this.flowOffloadHw = false});
}

class FwView {
  final List<FwZone> zones;
  final List<FwRule> rules;
  final List<FwRedirect> redirects;
  final FwDefaults defaults;
  const FwView(this.zones, this.rules, this.redirects, this.defaults);
}

FwView parseFirewall(UciConfig cfg) {
  final zones = <FwZone>[];
  for (final s in cfg.ofType('zone')) {
    zones.add(FwZone(
      s.name,
      s.o('name') ?? s.name,
      s.o('input') ?? 'REJECT',
      s.o('output') ?? 'ACCEPT',
      s.o('forward') ?? 'REJECT',
      s.o('masq') == '1',
      s.o('mtu_fix') == '1',
      s.o('network') ?? '',
    ));
  }
  final rules = <FwRule>[];
  for (final s in cfg.ofType('rule')) {
    rules.add(FwRule(
      s.name,
      s.o('name') ?? '',
      s.o('src') ?? '',
      s.o('dest') ?? '',
      s.o('proto') ?? '',
      s.o('src_ip') ?? '',
      s.o('dest_ip') ?? '',
      s.o('dest_port') ?? '',
      s.o('target') ?? 'ACCEPT',
      s.o('enabled') != '0',
      s.name.startsWith('swrule_') || s.name.startsWith('swblk_'),
    ));
  }
  final redirects = <FwRedirect>[];
  for (final s in cfg.ofType('redirect')) {
    redirects.add(FwRedirect(
      s.name,
      s.o('name') ?? '',
      s.o('src') ?? 'wan',
      s.o('dest') ?? 'lan',
      s.o('proto') ?? 'tcp udp',
      s.o('src_dport') ?? '',
      s.o('dest_ip') ?? '',
      s.o('dest_port') ?? '',
      s.o('enabled') != '0',
      s.name == 'swdmz',
    ));
  }
  var defs = const FwDefaults();
  for (final s in cfg.ofType('defaults')) {
    defs = FwDefaults(
      synFlood: s.o('synflood_protect') == '1' || s.o('syn_flood') == '1',
      dropInvalid: s.o('drop_invalid') == '1',
      flowOffload: s.o('flow_offloading') == '1',
      flowOffloadHw: s.o('flow_offloading_hw') == '1',
    );
    break;
  }
  return FwView(zones, rules, redirects, defs);
}

String _optSet(String path, String value) =>
    value.isEmpty ? uciDel(path) : uciSet(path, value);

String _needPolicy(String s) {
  if (!kFwPolicies.contains(s)) throw SshException(S.badName);
  return s;
}

String _needAddr(String s) {
  if (s.isEmpty) return s;
  if (!RegExp(r'^[0-9.]+(/\d{1,2})?$').hasMatch(s)) throw SshException(S.badIp);
  return s;
}

String _newName(String prefix) =>
    '$prefix${DateTime.now().millisecondsSinceEpoch.toRadixString(36)}';

extension FwApi on RouterApi {
  Future<FwView> loadFirewall() async {
    final out = await ssh.run('uci show firewall 2>/dev/null; true');
    return parseFirewall(parseUciShow(out));
  }

  Future<void> stageZone({
    required String section,
    required String input,
    required String output,
    required String forward,
    required bool masq,
    required bool mtuFix,
  }) async {
    final p = 'firewall.${needName(section)}';
    await runChain(ssh.run, [
      uciSet('$p.input', _needPolicy(input)),
      uciSet('$p.output', _needPolicy(output)),
      uciSet('$p.forward', _needPolicy(forward)),
      uciBool('$p.masq', masq),
      uciBool('$p.mtu_fix', mtuFix),
    ]);
  }

  /// Creates a rule when [section] is empty, otherwise edits that section.
  Future<void> stageRule({
    String section = '',
    required String name,
    required String src,
    String dest = '',
    String proto = 'tcp udp',
    String srcIp = '',
    String destIp = '',
    String destPort = '',
    String target = 'ACCEPT',
  }) async {
    if (!kFwTargets.contains(target)) throw SshException(S.badName);
    final sec = section.isEmpty ? _newName('swrule_') : needName(section);
    final p = 'firewall.$sec';
    if (destPort.isNotEmpty) needPort(destPort);
    if (src.isNotEmpty) needName(src);
    if (dest.isNotEmpty) needName(dest);
    await runChain(ssh.run, [
      if (section.isEmpty) uciNew('firewall', sec, 'rule'),
      uciSet('$p.name', name),
      _optSet('$p.src', src),
      _optSet('$p.dest', dest),
      uciSet('$p.proto', needProto(proto)),
      _optSet('$p.src_ip', _needAddr(srcIp)),
      _optSet('$p.dest_ip', _needAddr(destIp)),
      _optSet('$p.dest_port', destPort),
      uciSet('$p.target', target),
    ]);
  }

  Future<void> stageSectionEnabled(String section, bool enabled) async {
    final p = 'firewall.${needName(section)}';
    await runChain(
        ssh.run, [enabled ? uciDel('$p.enabled') : uciSet('$p.enabled', '0')]);
  }

  Future<void> stageDeleteSection(String section) =>
      runChain(ssh.run, [uciDel('firewall.${needName(section)}')]);

  Future<void> stagePortForward({
    String section = '',
    required String name,
    required String proto,
    required String srcDport,
    required String destIp,
    String destPort = '',
  }) async {
    final sec = section.isEmpty ? _newName('swpf_') : needName(section);
    final p = 'firewall.$sec';
    needPort(srcDport);
    needIp(destIp);
    if (destPort.isNotEmpty) needPort(destPort);
    await runChain(ssh.run, [
      if (section.isEmpty) uciNew('firewall', sec, 'redirect'),
      uciSet('$p.name', name),
      uciSet('$p.target', 'DNAT'),
      uciSet('$p.src', 'wan'),
      uciSet('$p.dest', 'lan'),
      uciSet('$p.proto', needProto(proto)),
      uciSet('$p.src_dport', srcDport),
      uciSet('$p.dest_ip', destIp),
      _optSet('$p.dest_port', destPort),
    ]);
  }

  /// DMZ: every inbound port that has no other rule goes to one LAN host.
  Future<void> stageDmz({required bool enabled, String ip = ''}) async {
    if (!enabled) {
      await runChain(ssh.run, [uciDel('firewall.swdmz')]);
      return;
    }
    needIp(ip);
    await runChain(ssh.run, [
      uciNew('firewall', 'swdmz', 'redirect'),
      uciSet('firewall.swdmz.name', 'SharkWRT DMZ'),
      uciSet('firewall.swdmz.target', 'DNAT'),
      uciSet('firewall.swdmz.src', 'wan'),
      uciSet('firewall.swdmz.dest', 'lan'),
      uciSet('firewall.swdmz.proto', 'tcp udp'),
      uciSet('firewall.swdmz.dest_ip', ip),
    ]);
  }

  Future<void> stageProtection({
    required bool synFlood,
    required bool dropInvalid,
  }) async {
    // fw4 names the option syn_flood, fw3 names it synflood_protect.
    final key = env.fw4 ? 'syn_flood' : 'synflood_protect';
    await runChain(ssh.run, [
      uciBool('firewall.@defaults[0].$key', synFlood),
      uciBool('firewall.@defaults[0].drop_invalid', dropInvalid),
    ]);
  }

  Future<void> stageFlowOffload({required bool software, required bool hardware}) async {
    await runChain(ssh.run, [
      uciBool('firewall.@defaults[0].flow_offloading', software || hardware),
      uciBool('firewall.@defaults[0].flow_offloading_hw', hardware),
    ]);
  }
}
