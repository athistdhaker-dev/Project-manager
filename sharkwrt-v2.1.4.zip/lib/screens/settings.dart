import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:provider/provider.dart';

import '../core/strings.dart';
import '../core/theme.dart';
import '../core/ui.dart';
import '../state/app_state.dart';
import 'term_sheets.dart';

class _Item {
  final String group;
  final IconData icon;
  final Color color;
  final String title;
  final String? subtitle;
  final String keywords;
  final VoidCallback? onTap;
  final Widget? trailing;
  const _Item({
    required this.group,
    required this.icon,
    required this.color,
    required this.title,
    this.subtitle,
    this.keywords = '',
    this.onTap,
    this.trailing,
  });

  bool matches(String q) {
    final s = q.toLowerCase();
    return title.toLowerCase().contains(s) ||
        (subtitle ?? '').toLowerCase().contains(s) ||
        keywords.toLowerCase().contains(s) ||
        group.toLowerCase().contains(s);
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _q = '';

  List<_Item> _items(AppState s) {
    return [
      _Item(
        group: S.grpAppearance,
        icon: Icons.palette_outlined,
        color: s.accent,
        title: S.theme,
        subtitle: s.theme.name,
        keywords: 'dark light ink dusk sand mint colors',
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute<void>(builder: (_) => const ThemeGalleryScreen()),
        ),
      ),
      _Item(
        group: S.grpAppearance,
        icon: Icons.color_lens_outlined,
        color: const Color(0xFFFF6B5B),
        title: S.accentColor,
        subtitle: kAccentNames[s.accentIndex.clamp(0, kAccentNames.length - 1)],
        keywords: 'accent highlight colour',
        onTap: () => _pickAccent(s),
      ),
      _Item(
        group: S.grpTerminal,
        icon: Icons.terminal_rounded,
        color: kGood,
        title: S.termSettings,
        subtitle: '${s.termFont.toStringAsFixed(0)} pt  •  ${S.termColorScheme}',
        keywords: 'font size scheme confirm startup shell ssh',
        onTap: () => showTermSettings(context),
      ),
      _Item(
        group: S.grpSecurity,
        icon: Icons.fingerprint_rounded,
        color: kGood,
        title: S.bioLock,
        subtitle: S.bioLockSub,
        keywords: 'biometric fingerprint face lock pin security',
        onTap: () => _toggleBio(s, !s.bioLock),
        trailing: Switch(value: s.bioLock, onChanged: (v) => _toggleBio(s, v)),
      ),
      _Item(
        group: S.grpAbout,
        icon: Icons.info_outline_rounded,
        color: const Color(0xFF8B7CFF),
        title: S.about,
        subtitle: 'SharkWRT 2.1.4',
        keywords: 'version licenses open source font',
        onTap: () => _about(),
      ),
    ];
  }

  Future<void> _toggleBio(AppState s, bool on) async {
    if (!on) {
      await s.setBioLock(false);
      return;
    }
    try {
      final auth = LocalAuthentication();
      final ok = await auth.isDeviceSupported() &&
          await auth.authenticate(localizedReason: S.bioReason);
      if (ok) {
        await s.setBioLock(true);
      } else if (mounted) {
        showMsg(context, S.bioUnavailable);
      }
    } catch (_) {
      if (mounted) showMsg(context, S.bioUnavailable);
    }
  }

  void _pickAccent(AppState s) {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => Consumer<AppState>(
        builder: (context, st, _) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(S.accentColor,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              Wrap(
                spacing: 16,
                runSpacing: 16,
                children: [
                  for (var i = 0; i < kAccents.length; i++)
                    GestureDetector(
                      onTap: () => st.setAccent(i),
                      child: Column(
                        children: [
                          Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: kAccents[i],
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: st.accentIndex == i
                                    ? st.theme.text
                                    : Colors.transparent,
                                width: 3,
                              ),
                            ),
                            child: st.accentIndex == i
                                ? const Icon(Icons.check_rounded,
                                    color: Colors.black87)
                                : null,
                          ),
                          const SizedBox(height: 4),
                          Text(kAccentNames[i],
                              style: TextStyle(fontSize: 11, color: st.theme.sub)),
                        ],
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _about() {
    showAboutDialog(
      context: context,
      applicationName: 'SharkWRT',
      applicationVersion: '2.0.0',
      applicationLegalese:
          'Controls OpenWrt routers over SSH. No cloud, no analytics. Credentials stay in this phone\'s Keystore.\n\n${S.fontCredit}',
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final all = _items(s);
    final list = _q.isEmpty ? all : all.where((e) => e.matches(_q)).toList();
    final groups = <String>[];
    for (final i in list) {
      if (!groups.contains(i.group)) groups.add(i.group);
    }
    return SubPage(
      title: S.settings,
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          TextField(
            onChanged: (v) => setState(() => _q = v.trim()),
            decoration: const InputDecoration(
              hintText: S.searchSettings,
              prefixIcon: Icon(Icons.search_rounded),
            ),
          ),
          const SizedBox(height: 8),
          if (list.isEmpty)
            Padding(
              padding: const EdgeInsets.all(32),
              child: Center(
                child: Text(S.noResults,
                    style: TextStyle(color: s.theme.sub)),
              ),
            ),
          for (final g in groups)
            InsetGroup(
              title: g,
              children: [
                for (final i in list.where((e) => e.group == g))
                  SettingRow(
                    icon: i.icon,
                    color: i.color,
                    title: i.title,
                    subtitle: i.subtitle,
                    trailing: i.trailing,
                    onTap: i.onTap,
                  ),
              ],
            ),
        ],
      ),
    );
  }
}

/// Theme picker: each card previews the theme with a tiny mock of the dashboard.
class ThemeGalleryScreen extends StatelessWidget {
  const ThemeGalleryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return SubPage(
      title: S.theme,
      body: GridView.count(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        crossAxisCount: 2,
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
        childAspectRatio: 0.78,
        children: [
          for (var i = 0; i < kThemes.length; i++)
            _ThemeCard(
              theme: kThemes[i],
              accent: s.accent,
              selected: s.themeIndex == i,
              onTap: () => s.setTheme(i),
            ),
        ],
      ),
    );
  }
}

class _ThemeCard extends StatelessWidget {
  final SharkTheme theme;
  final Color accent;
  final bool selected;
  final VoidCallback onTap;
  const _ThemeCard({
    required this.theme,
    required this.accent,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final t = theme;
    Widget block(double h, {Color? c}) => Container(
          height: h,
          decoration: BoxDecoration(
            color: c ?? t.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: t.outline),
          ),
        );
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: t.bg,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: selected ? accent : t.outline,
            width: selected ? 2.5 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                children: [
                  block(46, c: accent.withAlpha(60)),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Expanded(child: block(34)),
                      const SizedBox(width: 6),
                      Expanded(child: block(34)),
                      const SizedBox(width: 6),
                      Expanded(child: block(34)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  block(26),
                  const Spacer(),
                  Container(
                    height: 22,
                    decoration: BoxDecoration(
                      color: t.surface2,
                      borderRadius: BorderRadius.circular(11),
                      border: Border.all(color: t.outline),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Container(
                          width: 14,
                          height: 8,
                          decoration: BoxDecoration(
                            color: accent,
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                        Container(width: 8, height: 8, color: t.sub),
                        Container(width: 8, height: 8, color: t.sub),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: Text(t.name,
                      style: TextStyle(
                          color: t.text,
                          fontWeight: FontWeight.w800,
                          fontSize: 15)),
                ),
                if (selected) Icon(Icons.check_circle_rounded, color: accent),
              ],
            ),
            Text(t.dark ? 'Dark' : 'Light',
                style: TextStyle(color: t.sub, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
