import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// Small key/value store. Uses SharedPreferences when it works; if that plugin fails
/// on a phone it keeps everything in memory and mirrors it into the secure storage,
/// so the app still starts and can save routers.
class Prefs {
  SharedPreferences? _sp;
  final Map<String, Object> _mem = {};
  static const FlutterSecureStorage _sec = FlutterSecureStorage();
  static const String _mirrorKey = 'prefs_mirror_json';
  String? error;

  Future<void> init() async {
    try {
      _sp = await SharedPreferences.getInstance().timeout(const Duration(seconds: 5));
      return;
    } catch (e) {
      error = e.toString();
    }
    try {
      final raw = await _sec.read(key: _mirrorKey).timeout(const Duration(seconds: 5));
      if (raw != null) {
        final m = jsonDecode(raw);
        if (m is Map) {
          m.forEach((k, v) {
            if (v != null) _mem['$k'] = v as Object;
          });
        }
      }
    } catch (_) {}
  }

  Future<bool> _put(String k, Object? v) async {
    final sp = _sp;
    if (sp != null) {
      if (v == null) return sp.remove(k);
      if (v is int) return sp.setInt(k, v);
      if (v is bool) return sp.setBool(k, v);
      if (v is double) return sp.setDouble(k, v);
      if (v is String) return sp.setString(k, v);
      if (v is List<String>) return sp.setStringList(k, v);
      return false;
    }
    if (v == null) {
      _mem.remove(k);
    } else {
      _mem[k] = v;
    }
    try {
      await _sec.write(key: _mirrorKey, value: jsonEncode(_mem));
    } catch (_) {}
    return true;
  }

  T? _get<T>(String k) {
    final sp = _sp;
    try {
      if (sp != null) {
        final v = sp.get(k);
        return v is T ? v : null;
      }
      final v = _mem[k];
      return v is T ? v : null;
    } catch (_) {
      return null;
    }
  }

  int? getInt(String k) => _get<int>(k);
  bool? getBool(String k) => _get<bool>(k);
  double? getDouble(String k) {
    final v = _get<Object>(k);
    if (v is double) return v;
    if (v is int) return v.toDouble();
    return null;
  }

  String? getString(String k) => _get<String>(k);
  List<String>? getStringList(String k) {
    final sp = _sp;
    if (sp != null) return sp.getStringList(k);
    final v = _mem[k];
    return v is List ? v.map((e) => '$e').toList() : null;
  }

  Future<bool> setInt(String k, int v) => _put(k, v);
  Future<bool> setBool(String k, bool v) => _put(k, v);
  Future<bool> setDouble(String k, double v) => _put(k, v);
  Future<bool> setString(String k, String v) => _put(k, v);
  Future<bool> setStringList(String k, List<String> v) => _put(k, v);
  Future<bool> remove(String k) => _put(k, null);
}

class Store {
  static const FlutterSecureStorage _sec = FlutterSecureStorage();
  final Prefs prefs = Prefs();

  Future<void> init() => prefs.init();

  List<RouterProfile> loadProfiles() {
    final raw = prefs.getString('profiles');
    if (raw == null) return [];
    try {
      final l = jsonDecode(raw) as List;
      return l
          .map((e) => RouterProfile.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveProfiles(List<RouterProfile> l) => prefs.setString(
      'profiles', jsonEncode(l.map((e) => e.toJson()).toList()));

  Future<String?> secret(String id, String kind) async {
    try {
      return await _sec.read(key: '${kind}_$id');
    } catch (_) {
      return null;
    }
  }

  Future<void> setSecret(String id, String kind, String value) async {
    if (value.isEmpty) {
      await _sec.delete(key: '${kind}_$id');
    } else {
      await _sec.write(key: '${kind}_$id', value: value);
    }
  }

  Future<void> deleteSecrets(String id) async {
    try {
      await _sec.delete(key: 'pw_$id');
      await _sec.delete(key: 'key_$id');
    } catch (_) {}
  }

  String? fingerprint(String id) => prefs.getString('fp_$id');
  Future<void> setFingerprint(String id, String v) =>
      prefs.setString('fp_$id', v);
  Future<void> clearFingerprint(String id) => prefs.remove('fp_$id');

  // ---- terminal: snippets and command history
  String? snippetsRaw() => prefs.getString('snippets');
  Future<void> saveSnippetsRaw(String v) => prefs.setString('snippets', v);

  List<String> history() => prefs.getStringList('term_hist') ?? <String>[];

  Future<void> addHistory(String cmd) async {
    final l = history();
    if (l.isNotEmpty && l.last == cmd) return;
    l.add(cmd);
    while (l.length > 300) {
      l.removeAt(0);
    }
    await prefs.setStringList('term_hist', l);
  }

  Future<void> clearHistory() => prefs.remove('term_hist');

  Map<String, String> aliases(String id) {
    final raw = prefs.getString('alias_$id');
    if (raw == null) return {};
    try {
      return Map<String, String>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return {};
    }
  }

  Future<void> saveAliases(String id, Map<String, String> m) =>
      prefs.setString('alias_$id', jsonEncode(m));
}
