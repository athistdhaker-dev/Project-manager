#!/usr/bin/env python3
"""Patches the freshly generated Flutter android/ folder for SharkWRT.

Usage: python3 tool/patch_android.py <project_dir>
- manifest: INTERNET permission, app label, allowBackup=false, no cleartext
- biometric (local_auth) prerequisites
- launcher icons: copies tool/icons/mipmap-*/ic_launcher.png
Fails loudly if something expected is missing.
"""
import os
import re
import shutil
import sys

root = sys.argv[1] if len(sys.argv) > 1 else "."
manifest = os.path.join(root, "android", "app", "src", "main", "AndroidManifest.xml")
res_dir = os.path.join(root, "android", "app", "src", "main", "res")

if not os.path.isfile(manifest):
    sys.exit("AndroidManifest.xml not found: " + manifest)

with open(manifest, encoding="utf-8") as f:
    xml = f.read()

# 1) INTERNET permission
if "android.permission.INTERNET" not in xml:
    xml = re.sub(
        r"(<application\b)",
        '<uses-permission android:name="android.permission.INTERNET"/>\n    \\1',
        xml,
        count=1,
    )

# 2) application attributes
m = re.search(r"<application\b[^>]*>", xml, re.S)
if not m:
    sys.exit("<application> tag not found")
tag = m.group(0)
new_tag = tag
for attr in ("android:label", "android:allowBackup", "android:usesCleartextTraffic"):
    new_tag = re.sub(r'\s+' + re.escape(attr) + r'="[^"]*"', "", new_tag)
new_tag = new_tag.replace(
    "<application",
    '<application\n        android:label="SharkWRT"\n'
    '        android:allowBackup="false"\n'
    '        android:usesCleartextTraffic="false"',
    1,
)
xml = xml.replace(tag, new_tag, 1)

with open(manifest, "w", encoding="utf-8") as f:
    f.write(xml)

# 3) icons
icons_src = os.path.join(root, "tool", "icons")
copied = 0
for d in sorted(os.listdir(icons_src)):
    src = os.path.join(icons_src, d, "ic_launcher.png")
    if not os.path.isfile(src):
        continue
    dst_dir = os.path.join(res_dir, d)
    os.makedirs(dst_dir, exist_ok=True)
    shutil.copyfile(src, os.path.join(dst_dir, "ic_launcher.png"))
    copied += 1
if copied == 0:
    sys.exit("no icons copied")

# 3b) minSdk 24 (flutter_secure_storage / local_auth need >= 23)
gradle_done = False
for gname in ("build.gradle.kts", "build.gradle"):
    gpath = os.path.join(root, "android", "app", gname)
    if not os.path.isfile(gpath):
        continue
    with open(gpath, encoding="utf-8") as f:
        g = f.read()
    g2 = re.sub(r"minSdk\s*=\s*flutter\.minSdkVersion", "minSdk = 24", g)
    g2 = re.sub(r"minSdkVersion\s+flutter\.minSdkVersion", "minSdkVersion 24", g2)
    if g2 != g:
        with open(gpath, "w", encoding="utf-8") as f:
            f.write(g2)
        gradle_done = True
    elif re.search(r"minSdk(Version)?\s*(=\s*)?\d+", g2):
        gradle_done = True
if not gradle_done:
    print("WARNING: could not set minSdk; check android/app/build.gradle")


# 3c) biometric lock (local_auth): permission, FragmentActivity, AppCompat theme
xml2 = open(manifest, encoding="utf-8").read()
if "android.permission.USE_BIOMETRIC" not in xml2:
    xml2 = re.sub(
        r"(<application\b)",
        '<uses-permission android:name="android.permission.USE_BIOMETRIC"/>\n    \\1',
        xml2,
        count=1,
    )
    open(manifest, "w", encoding="utf-8").write(xml2)

main_patched = False
for dp, _dn, fns in os.walk(os.path.join(root, "android", "app", "src", "main")):
    for fn in fns:
        if fn in ("MainActivity.kt", "MainActivity.java"):
            fp = os.path.join(dp, fn)
            src = open(fp, encoding="utf-8").read()
            new = src.replace("io.flutter.embedding.android.FlutterActivity",
                              "io.flutter.embedding.android.FlutterFragmentActivity")
            new = re.sub(r"\bFlutterActivity\b", "FlutterFragmentActivity", new)
            if new != src:
                open(fp, "w", encoding="utf-8").write(new)
            main_patched = "FlutterFragmentActivity" in new
if not main_patched:
    print("WARNING: MainActivity not patched; biometric lock will be unavailable")

for vdir in ("values", "values-night"):
    sp = os.path.join(res_dir, vdir, "styles.xml")
    if not os.path.isfile(sp):
        continue
    st = open(sp, encoding="utf-8").read()
    st2 = re.sub(
        r'(<style name="NormalTheme" parent=")[^"]*(")',
        r"\1Theme.AppCompat.DayNight.NoActionBar\2",
        st,
    )
    if st2 != st:
        open(sp, "w", encoding="utf-8").write(st2)


# 3d) plugins compiled against an older compileSdk break with newer Flutter
# (flutter_plugin_android_lifecycle needs 36): force compileSdk 36 on every plugin.
KTS_BLOCK = """
subprojects {
    afterEvaluate {
        val androidExt = extensions.findByName("android")
        if (androidExt != null) {
            androidExt.withGroovyBuilder { "compileSdkVersion"(36) }
        }
    }
}
"""
GROOVY_BLOCK = """
subprojects {
    afterEvaluate { p ->
        if (p.hasProperty('android')) {
            p.android.compileSdkVersion 36
        }
    }
}
"""
root_done = False
for gname, block in (("build.gradle.kts", KTS_BLOCK), ("build.gradle", GROOVY_BLOCK)):
    gpath = os.path.join(root, "android", gname)
    if not os.path.isfile(gpath):
        continue
    g = open(gpath, encoding="utf-8").read()
    if "compileSdkVersion(36)" in g or "compileSdkVersion 36" in g:
        root_done = True
        break
    lines = g.split("\n")
    at = 0
    for i, ln in enumerate(lines):
        if ln.startswith("import "):
            at = i + 1
    lines.insert(at, block)
    open(gpath, "w", encoding="utf-8").write("\n".join(lines))
    root_done = True
    break
if not root_done:
    sys.exit("android/build.gradle(.kts) not found: cannot force compileSdk")


# 3e) Some phones never draw the first frame with Impeller (stuck on the splash logo).
xml3 = open(manifest, encoding="utf-8").read()
if "EnableImpeller" not in xml3:
    xml3 = xml3.replace(
        "</application>",
        '    <meta-data android:name="io.flutter.embedding.android.EnableImpeller" android:value="false"/>\n    </application>',
        1,
    )
    open(manifest, "w", encoding="utf-8").write(xml3)

# 4) verify
with open(manifest, encoding="utf-8") as f:
    out = f.read()
for needle in (
    "android.permission.INTERNET",
    'android:label="SharkWRT"',
    'android:allowBackup="false"',
    'android:usesCleartextTraffic="false"',
    "EnableImpeller",
):
    if needle not in out:
        sys.exit("patch verification failed: missing " + needle)

print("android patch ok; icons copied:", copied)
